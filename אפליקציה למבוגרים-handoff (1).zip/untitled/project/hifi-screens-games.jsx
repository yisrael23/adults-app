// Senior Brains — Room & Game Screens (D1, E2 Wheel, G1 Scrabble, I1 Jeopardy, L1 End)
// Requires hifi-tokens.js + hifi-components.jsx

// ─── D1: Room Lobby ─────────────────────────────────────────────
function ScreenHifiD1({ onStart, onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [muted, setMuted] = React.useState(false);

  const participants = [
    { name: 'Sarah', colorIdx: 0, state: 'speaking', self: true },
    { name: 'Mom',   colorIdx: 1, state: 'idle' },
    { name: 'Jake',  colorIdx: 2, state: 'muted' },
    { name: 'Aunt R',colorIdx: 3, state: 'idle' },
  ];

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar title="Family Room" onBack={onBack} action={
        <button onClick={onBack} style={{ background:color.error+'22', border:'none', borderRadius:radius.full, padding:'6px 12px', color:color.error, fontFamily:font.body, fontWeight:700, fontSize:12, cursor:'pointer' }}>Leave</button>
      }/>
      <div style={{ flex:1, background:grad.meadow, display:'flex', flexDirection:'column', overflow:'hidden' }}>
        {/* Participants area */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'24px 20px', gap:32 }}>
          {/* Main speaker highlight */}
          <div style={{ textAlign:'center' }}>
            <div style={{ fontFamily:font.body, fontSize:13, fontWeight:600, color:color.n500, marginBottom:16, letterSpacing:'0.05em', textTransform:'uppercase' }}>In the room</div>
            <div style={{ display:'flex', justifyContent:'center', gap:28, flexWrap:'wrap' }}>
              {participants.map((p,i) => (
                <SBOrb key={i} {...p} size={72}/>
              ))}
            </div>
          </div>

          {/* Invite card */}
          <div style={{ width:'100%', background:'rgba(255,255,255,0.85)', borderRadius:radius.xl, padding:20, backdropFilter:'blur(12px)', border:`1px solid rgba(255,255,255,0.9)`, boxShadow:shadow.md }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
              <div style={{ fontFamily:font.display, fontWeight:700, fontSize:15, color:color.n800 }}>Invite others</div>
              <span style={{ fontFamily:font.body, fontSize:11, color:color.n400 }}>Expires in 2h</span>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <div style={{ flex:1, background:color.n50, borderRadius:radius.md, padding:'12px 16px', fontFamily:font.mono, fontWeight:700, fontSize:24, color:color.n900, letterSpacing:'0.15em', textAlign:'center' }}>
                XK3-9P2
              </div>
              <button style={{ width:48, height:48, borderRadius:radius.md, background:color.primary500, border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', fontSize:20 }}>
                📋
              </button>
            </div>
            <div style={{ display:'flex', gap:10, marginTop:12 }}>
              <button style={{ flex:1, height:44, borderRadius:radius.md, background:'#25D366', border:'none', cursor:'pointer', fontFamily:font.body, fontWeight:700, fontSize:13, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                <span>📱</span> WhatsApp
              </button>
              <button style={{ flex:1, height:44, borderRadius:radius.md, background:color.n100, border:'none', cursor:'pointer', fontFamily:font.body, fontWeight:700, fontSize:13, color:color.n700, display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
                <span>💬</span> SMS
              </button>
            </div>
          </div>
        </div>

        {/* Ready status */}
        <div style={{ padding:'0 20px 16px', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ flex:1, display:'flex', gap:6 }}>
            {participants.map((p,i) => (
              <div key={i} style={{ width:8, height:8, borderRadius:'50%', background: i<2?color.success:color.n300 }}/>
            ))}
          </div>
          <span style={{ fontFamily:font.body, fontSize:12, color:color.n500 }}>2 of 4 ready</span>
        </div>

        <div style={{ padding:'0 20px 24px' }}>
          <SBButton label="Start Game →" fullWidth onClick={onStart}/>
        </div>
      </div>
      <BottomToolbar muted={muted} onMute={() => setMuted(m=>!m)}/>
    </PhoneShell>
  );
}

// ─── E2: Wheel of Fortune ───────────────────────────────────────
function ScreenHifiE2({ onGameSelect, onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [spinning, setSpinning] = React.useState(false);
  const [result, setResult]     = React.useState(null);
  const [rotation, setRotation] = React.useState(0);

  const slices = [
    { label:'Scrabble',  icon:'🔤', color:'#FFD3B0', dark:color.primary700 },
    { label:'Jeopardy',  icon:'❓', color:'#BFDBFE', dark:'#1e40af' },
    { label:'Checkers',  icon:'⬛', color:'#D6C7FE', dark:color.sec700 },
    { label:'Crossword', icon:'📝', color:'#BBF7D0', dark:'#166534' },
    { label:'Sudoku',    icon:'🔢', color:'#FDE68A', dark:'#92400e' },
    { label:'Trivia',    icon:'🧩', color:'#FCA5A5', dark:'#991b1b' },
  ];
  const n = slices.length;
  const sliceAngle = 360 / n;

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    setResult(null);
    const extra = 1440 + Math.floor(Math.random() * 360);
    const newRot = rotation + extra;
    setRotation(newRot);
    setTimeout(() => {
      const normalised = ((newRot % 360) + 360) % 360;
      // pointer is at bottom (270deg), find which slice it lands on
      const pointerAngle = (270 - normalised + 360) % 360;
      const idx = Math.floor(pointerAngle / sliceAngle) % n;
      setResult(slices[idx]);
      setSpinning(false);
    }, 2400);
  };

  // Draw SVG wheel
  const size = 280; const cx = size/2; const cy = size/2; const r = size/2 - 4;
  const polarToCart = (angle, radius) => {
    const rad = (angle - 90) * Math.PI / 180;
    return [cx + radius * Math.cos(rad), cy + radius * Math.sin(rad)];
  };

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar title="Choose a Game" onBack={onBack}/>
      <div style={{ flex:1, background:grad.meadow, display:'flex', flexDirection:'column', alignItems:'center', overflow:'hidden' }}>
        {/* Room participants strip */}
        <div style={{ display:'flex', gap:16, padding:'16px 24px 0', alignSelf:'stretch', justifyContent:'center' }}>
          {['Sarah','Mom','Jake'].map((n,i) => (
            <div key={n} style={{ display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ width:28, height:28, borderRadius:'50%', background:`linear-gradient(135deg, ${DS.pColor(i)+'88'}, ${DS.pColor(i)})`, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:font.display, fontWeight:800, fontSize:11, color:'#fff' }}>
                {n[0]}
              </div>
              <span style={{ fontFamily:font.body, fontSize:12, color:color.n600 }}>{n}</span>
            </div>
          ))}
        </div>

        {/* Wheel */}
        <div style={{ position:'relative', margin:'20px auto 0' }}>
          {/* Glow backdrop */}
          <div style={{ position:'absolute', inset:-20, borderRadius:'50%', background:`radial-gradient(circle, rgba(236,122,47,0.12), transparent 70%)`, pointerEvents:'none' }}/>
          <svg width={size} height={size} style={{ transform:`rotate(${rotation}deg)`, transition: spinning ? `transform 2.4s cubic-bezier(0.17,0.67,0.12,1)` : 'none', display:'block' }}>
            {slices.map((s, i) => {
              const startAngle = i * sliceAngle;
              const endAngle   = startAngle + sliceAngle;
              const [x1,y1] = polarToCart(startAngle, r);
              const [x2,y2] = polarToCart(endAngle, r);
              const largeArc = sliceAngle > 180 ? 1 : 0;
              const path = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2} Z`;
              const [tx,ty] = polarToCart(startAngle + sliceAngle/2, r*0.65);
              return (
                <g key={i}>
                  <path d={path} fill={s.color} stroke="#fff" strokeWidth="2"/>
                  <text x={tx} y={ty} textAnchor="middle" dominantBaseline="middle" fontSize="22">{s.icon}</text>
                  <text x={tx} y={ty+18} textAnchor="middle" dominantBaseline="middle" fontSize="10" fontWeight="700" fill={s.dark} fontFamily="'Nunito',sans-serif">{s.label}</text>
                </g>
              );
            })}
            {/* Center button */}
            <circle cx={cx} cy={cy} r={38} fill={spinning ? color.primary300 : color.primary500} stroke="#fff" strokeWidth="3"/>
            <text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle" fontSize="24">🎲</text>
          </svg>
          {/* Pointer — bottom */}
          <div style={{ position:'absolute', bottom:-10, left:'50%', transform:'translateX(-50%)', width:0, height:0, borderLeft:'10px solid transparent', borderRight:'10px solid transparent', borderBottom:`20px solid ${color.primary600}`, filter:`drop-shadow(0 2px 4px rgba(0,0,0,0.2))` }}/>
        </div>

        {/* Result card */}
        {result ? (
          <div style={{ margin:'20px 20px 0', background:'rgba(255,255,255,0.9)', borderRadius:radius.xl, padding:20, textAlign:'center', backdropFilter:'blur(12px)', border:`1.5px solid ${color.primary200}`, boxShadow:shadow.lg, width:'calc(100% - 40px)', animation:'fadeSlideUp 0.5s ease-out' }}>
            <div style={{ fontSize:36, marginBottom:6 }}>{result.icon}</div>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:22, color:color.n900 }}>{result.label}!</div>
            <div style={{ fontFamily:font.body, fontSize:14, color:color.n500, margin:'6px 0 16px' }}>The wheel has chosen</div>
            <SBButton label={`Play ${result.label} →`} fullWidth onClick={() => onGameSelect && onGameSelect(result.label.toLowerCase())}/>
          </div>
        ) : (
          <div style={{ margin:'20px 20px 0', width:'calc(100% - 40px)' }}>
            <SBButton label={spinning ? 'Spinning…' : 'Spin the Wheel!'} fullWidth onClick={spin} disabled={spinning} size="lg" icon={spinning ? undefined : '🎲'}/>
          </div>
        )}

        {/* Manual picks */}
        {!result && (
          <div style={{ display:'flex', gap:8, padding:'16px 20px 0', flexWrap:'wrap', justifyContent:'center' }}>
            {slices.map(s => (
              <button key={s.label} onClick={() => onGameSelect && onGameSelect(s.label.toLowerCase())} style={{
                background:s.color, border:'none', borderRadius:radius.full, padding:'8px 14px', cursor:'pointer',
                fontFamily:font.body, fontWeight:700, fontSize:13, color:s.dark,
                display:'flex', gap:6, alignItems:'center',
              }}>
                <span>{s.icon}</span>{s.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </PhoneShell>
  );
}

// ─── G1: Scrabble ──────────────────────────────────────────────
function ScreenHifiG1({ onBack }) {
  const { color, font, radius, shadow } = DS;
  const [muted, setMuted] = React.useState(false);
  const [selectedTile, setSelectedTile] = React.useState(null);
  const [placedTiles, setPlacedTiles] = React.useState({});

  // Board state: some pre-filled words
  const boardWords = {
    '7-7':'H','7-8':'E','7-9':'L','7-10':'L','7-11':'O',
    '8-9':'A','9-9':'T',
  };
  const merged = { ...boardWords, ...placedTiles };

  const bonuses = {
    '0-0':'TW','0-7':'TW','0-14':'TW','7-0':'TW','7-14':'TW','14-0':'TW','14-7':'TW','14-14':'TW',
    '1-1':'DW','2-2':'DW','3-3':'DW','4-4':'DW','13-1':'DW','12-2':'DW','11-3':'DW','10-4':'DW','1-13':'DW','2-12':'DW','3-11':'DW','4-10':'DW','13-13':'DW','12-12':'DW','11-11':'DW','10-10':'DW',
    '1-5':'TL','1-9':'TL','5-1':'TL','5-5':'TL','5-9':'TL','5-13':'TL','9-1':'TL','9-5':'TL','9-9':'TL','9-13':'TL','13-5':'TL','13-9':'TL',
  };
  const bonusColor = { TW:'#FECACA', DW:'#FED7AA', TL:'#BFDBFE', DL:'#BBF7D0' };

  const rack = ['A','B','R','I','D','G','E'];
  const tileValues = {A:1,B:3,C:3,D:2,E:1,F:4,G:2,H:4,I:1,J:8,K:5,L:1,M:3,N:1,O:1,P:3,Q:10,R:1,S:1,T:1,U:1,V:4,W:4,X:8,Y:4,Z:10};

  const cellSize = 24;
  const boardSize = 15 * cellSize;

  const playerScores = [
    { name:'Sarah', score:143, colorIdx:0, current:true },
    { name:'Mom',   score:98,  colorIdx:1 },
    { name:'Jake',  score:76,  colorIdx:2 },
  ];

  const TileCell = ({ letter, value, selected, onClick }) => (
    <div onClick={onClick} style={{
      width:36, height:36, borderRadius:8,
      background: selected
        ? `linear-gradient(135deg, ${color.primary400}, ${color.primary500})`
        : `linear-gradient(135deg, #FFF5E6, #FFE4C0)`,
      border:`1.5px solid ${selected ? color.primary600 : '#D4A96A'}`,
      display:'flex', alignItems:'center', justifyContent:'center',
      cursor:'pointer', position:'relative', flexShrink:0,
      boxShadow: selected ? shadow.glowPrimary : '0 2px 4px rgba(0,0,0,0.12)',
      transition:'all 150ms',
    }}>
      <span style={{ fontFamily:font.display, fontWeight:800, fontSize:18, color: selected?'#fff':color.n800 }}>{letter}</span>
      <span style={{ position:'absolute', bottom:2, right:3, fontSize:8, fontWeight:700, color: selected?'rgba(255,255,255,0.8)':color.n500 }}>{value}</span>
    </div>
  );

  return (
    <PhoneShell>
      <SBStatusBar/>
      {/* Scores bar */}
      <div style={{ background:color.n0, borderBottom:`1px solid ${color.n100}`, padding:'10px 16px', display:'flex', gap:12, alignItems:'center', flexShrink:0 }}>
        {playerScores.map((p,i) => (
          <div key={i} style={{
            display:'flex', alignItems:'center', gap:6, padding:'4px 10px',
            borderRadius:radius.full, background: p.current ? color.primary50 : 'transparent',
            border:`1.5px solid ${p.current ? color.primary500 : 'transparent'}`,
          }}>
            <div style={{ width:20, height:20, borderRadius:'50%', background:DS.pColor(p.colorIdx), display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:'#fff' }}>
              {p.name[0]}
            </div>
            <span style={{ fontFamily:font.mono, fontWeight:700, fontSize:15, color: p.current?color.primary600:color.n700 }}>{p.score}</span>
          </div>
        ))}
        <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:6 }}>
          <div style={{ width:28, height:28, borderRadius:'50%', background:`conic-gradient(${color.primary500} 240deg, ${color.n200} 240deg)`, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <div style={{ width:20, height:20, borderRadius:'50%', background:color.n0, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:font.mono, fontWeight:800, fontSize:10, color:color.primary600 }}>24</div>
          </div>
          <span style={{ fontFamily:font.body, fontSize:11, color:color.n500 }}>sec</span>
        </div>
      </div>

      {/* Board */}
      <div style={{ flex:1, overflowY:'auto', background:`linear-gradient(135deg, #F5EDD8, #EDE4C8)` }}>
        <div style={{ padding:8 }}>
          <div style={{
            display:'grid', gridTemplateColumns:`repeat(15, ${cellSize}px)`,
            gridTemplateRows:`repeat(15, ${cellSize}px)`,
            gap:1, background:'rgba(180,150,100,0.3)', borderRadius:8,
            padding:2, margin:'0 auto', width:'fit-content',
          }}>
            {Array.from({length:15}).map((_,row) =>
              Array.from({length:15}).map((_,col) => {
                const key = `${row}-${col}`;
                const letter = merged[key];
                const bonus  = bonuses[key];
                const isCenter = row===7 && col===7;
                const bg = letter ? `linear-gradient(135deg, #FFF5E6, #FFE4C0)` : bonus ? bonusColor[bonus] : isCenter ? color.primary100 : '#EDE4C8';
                return (
                  <div key={key} style={{
                    width:cellSize, height:cellSize, background:bg,
                    border:`0.5px solid rgba(180,150,100,0.4)`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    position:'relative', fontSize:bonus?7:14, fontWeight:letter?800:600,
                    color:letter?color.n800:bonus?color.n600:isCenter?color.primary500:'transparent',
                    fontFamily:letter?font.display:font.body,
                    boxShadow:letter?'0 1px 3px rgba(0,0,0,0.15)':undefined,
                    borderRadius:letter?3:0,
                  }}>
                    {letter || (bonus&&<span style={{lineHeight:1,textAlign:'center'}}>{bonus}</span>) || (isCenter&&'★')}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Tile rack */}
        <div style={{ padding:'12px 16px 8px' }}>
          <div style={{ fontFamily:font.body, fontSize:11, fontWeight:600, color:color.n500, marginBottom:8, letterSpacing:'0.05em', textTransform:'uppercase' }}>Your tiles</div>
          <div style={{ display:'flex', gap:8 }}>
            {rack.map((letter,i) => (
              <TileCell key={i} letter={letter} value={tileValues[letter]||0} selected={selectedTile===i} onClick={() => setSelectedTile(selectedTile===i?null:i)}/>
            ))}
          </div>
        </div>
      </div>

      <BottomToolbar muted={muted} onMute={() => setMuted(m=>!m)} onBack={onBack}/>
    </PhoneShell>
  );
}

// ─── I1: Jeopardy Board ─────────────────────────────────────────
function ScreenHifiI1({ onBack }) {
  const { color, font, radius, shadow } = DS;
  const [muted, setMuted] = React.useState(false);
  const [revealed, setRevealed] = React.useState({});
  const [activeQ, setActiveQ] = React.useState(null);

  const cats = ['History','Science','Movies','Sports','Music','Wordplay'];
  const vals = [200,400,600,800,1000];
  const questions = {
    'History-200': { q:'This 1969 event brought humans to the Moon for the first time.', a:'Apollo 11' },
    'Science-400': { q:'The powerhouse of the cell.', a:'Mitochondria' },
    'Movies-600':  { q:'Directed Schindler\'s List and ET.', a:'Steven Spielberg' },
  };
  const scores = [
    { name:'Sarah', score:1200, colorIdx:0, buzzing:false },
    { name:'Mom',   score:600,  colorIdx:1, buzzing:true  },
    { name:'Jake',  score:800,  colorIdx:2, buzzing:false },
  ];

  return (
    <PhoneShell dark>
      <SBStatusBar dark/>
      <SBTopBar title="Jeopardy!" onBack={onBack} dark action={
        <span style={{ fontFamily:font.mono, fontWeight:700, fontSize:14, color:color.darkAccent }}>Rd 1</span>
      }/>

      {/* Scores */}
      <div style={{ display:'flex', padding:'8px 12px', gap:8, flexShrink:0 }}>
        {scores.map((p,i) => (
          <div key={i} style={{
            flex:1, borderRadius:radius.md, padding:'8px 10px', textAlign:'center',
            background: p.buzzing ? `linear-gradient(135deg, ${color.primary500}, ${color.primary600})` : color.darkCard,
            border:`1px solid ${p.buzzing?color.primary400:'rgba(255,255,255,0.06)'}`,
            boxShadow: p.buzzing ? shadow.glowPrimary : 'none',
          }}>
            <div style={{ fontFamily:font.body, fontSize:11, color:p.buzzing?'#fff':color.darkText2 }}>{p.name}</div>
            <div style={{ fontFamily:font.mono, fontWeight:800, fontSize:18, color:p.buzzing?'#fff':color.darkAccent }}>${p.score}</div>
          </div>
        ))}
      </div>

      {/* Board grid */}
      <div style={{ flex:1, overflowY:'auto', padding:'0 8px 8px' }}>
        {/* Category headers */}
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${cats.length}, 1fr)`, gap:4, marginBottom:4 }}>
          {cats.map(c => (
            <div key={c} style={{
              background:`linear-gradient(160deg, #1a3a6e, #0d2147)`,
              border:`1px solid rgba(125,93,232,0.3)`,
              borderRadius:radius.sm, padding:'8px 4px', textAlign:'center',
              fontFamily:font.display, fontWeight:800, fontSize:10, color:'#fff',
              letterSpacing:'0.02em', lineHeight:1.2,
            }}>{c}</div>
          ))}
        </div>

        {/* Value cells */}
        {vals.map(v => (
          <div key={v} style={{ display:'grid', gridTemplateColumns:`repeat(${cats.length}, 1fr)`, gap:4, marginBottom:4 }}>
            {cats.map(c => {
              const key = `${c}-${v}`;
              const done = revealed[key];
              return (
                <button key={key} onClick={() => {
                  if (!done) setActiveQ({ key, cat:c, val:v, ...(questions[key]||{q:'Question?',a:'Answer!'}) });
                }} style={{
                  background: done ? 'rgba(26,24,20,0.5)' : `linear-gradient(160deg, #1c3e8a, #0f2660)`,
                  border:`1px solid ${done?'rgba(255,255,255,0.04)':'rgba(90,143,175,0.3)'}`,
                  borderRadius:radius.sm, padding:'10px 4px', cursor:done?'default':'pointer',
                  fontFamily:font.mono, fontWeight:800, fontSize:v>=600?16:18,
                  color: done?'transparent':color.darkAccent,
                  textShadow: done?'none':`0 0 12px rgba(253,183,132,0.4)`,
                  transition:'all 200ms',
                }}>
                  {done ? '' : ('$' + v)}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Active question overlay */}
      {activeQ && (
        <div style={{ position:'absolute', inset:0, background:'rgba(26,24,20,0.95)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:32, zIndex:50 }} onClick={() => { setRevealed(r=>({...r,[activeQ.key]:true})); setActiveQ(null); }}>
          <div style={{ fontFamily:font.body, fontSize:13, fontWeight:700, color:color.sec300, marginBottom:8, letterSpacing:'0.1em', textTransform:'uppercase' }}>{activeQ.cat}</div>
          <div style={{ fontFamily:font.mono, fontWeight:800, fontSize:32, color:color.darkAccent, marginBottom:24 }}>${activeQ.val}</div>
          <div style={{ fontFamily:font.display, fontWeight:700, fontSize:20, color:'#fff', textAlign:'center', lineHeight:1.5, marginBottom:32 }}>{activeQ.q}</div>
          <div style={{ fontFamily:font.body, fontSize:12, color:color.darkText2 }}>Tap to reveal answer</div>
        </div>
      )}

      <BottomToolbar muted={muted} onMute={() => setMuted(m=>!m)} dark/>
    </PhoneShell>
  );
}

// ─── L1: Session End ────────────────────────────────────────────
function ScreenHifiL1({ onHome, onPlayAgain }) {
  const { color, font, radius, shadow, grad } = DS;

  const players = [
    { name:'Sarah', score:312, colorIdx:0, rank:1, delta:'+42' },
    { name:'Mom',   score:248, colorIdx:1, rank:2, delta:'+31' },
    { name:'Jake',  score:198, colorIdx:2, rank:3, delta:'+19' },
  ];

  return (
    <PhoneShell>
      <SBStatusBar/>
      <div style={{ flex:1, background:grad.sunrise, display:'flex', flexDirection:'column', alignItems:'center', overflow:'auto' }}>
        {/* Confetti header */}
        <div style={{ width:'100%', padding:'40px 24px 24px', textAlign:'center', position:'relative' }}>
          <div style={{ fontSize:52, marginBottom:12, animation:'breatheLogo 1.5s ease-in-out infinite' }}>🎉</div>
          <div style={{ fontFamily:font.display, fontWeight:800, fontSize:30, color:color.n900, letterSpacing:'-0.03em', marginBottom:8 }}>Game Over!</div>
          <div style={{ fontFamily:font.body, fontSize:16, color:color.n600 }}>Great game, everyone!</div>
          {/* Decorative dots */}
          {['#FF6B6B','#FFD93D','#6BCB77','#4D96FF','#C77DFF'].map((c,i) => (
            <div key={i} style={{ position:'absolute', width:10, height:10, borderRadius:'50%', background:c, top: 20+Math.sin(i*1.3)*30+'%', left: 10+i*18+'%', animation:`breatheLogo ${1+i*0.2}s ease-in-out infinite` }}/>
          ))}
        </div>

        {/* Podium results */}
        <div style={{ padding:'0 24px', width:'100%', display:'flex', flexDirection:'column', gap:10, marginBottom:24 }}>
          {players.map((p,i) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap:14, padding:'14px 18px',
              background: i===0 ? `linear-gradient(135deg, ${color.primary50}, ${color.primary100})` : 'rgba(255,255,255,0.75)',
              borderRadius:radius.lg,
              border:`1.5px solid ${i===0?color.primary300:color.n100}`,
              boxShadow: i===0 ? shadow.md : shadow.xs,
              backdropFilter:'blur(8px)',
            }}>
              <div style={{ width:36, height:36, borderRadius:'50%', background: i===0?`linear-gradient(135deg, #FFD700, #FFA500)`:i===1?`linear-gradient(135deg, #C0C0C0, #A0A0A0)`:`linear-gradient(135deg, #CD7F32, #A05A20)`, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:font.display, fontWeight:800, fontSize:18, color:'#fff', flexShrink:0, boxShadow:shadow.sm }}>
                {p.rank}
              </div>
              <SBOrb name={p.name} colorIdx={p.colorIdx} size={44}/>
              <div style={{ flex:1, marginLeft:4 }}>
                <div style={{ fontFamily:font.display, fontWeight:800, fontSize:16, color:color.n900 }}>{p.name}</div>
                <div style={{ fontFamily:font.body, fontSize:12, color:color.n500 }}>Scrabble</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontFamily:font.mono, fontWeight:800, fontSize:20, color:i===0?color.primary600:color.n700 }}>{p.score}</div>
                <div style={{ fontFamily:font.body, fontSize:11, color:color.success, fontWeight:600 }}>{p.delta}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Duration badge */}
        <div style={{ display:'flex', gap:16, marginBottom:28 }}>
          {[['⏱','32 min','Duration'],['🔤','8 words','Best: BRIDGE'],['🏆','3','Streak']].map(([ic,val,lbl],i) => (
            <div key={i} style={{ textAlign:'center', padding:'12px 16px', background:'rgba(255,255,255,0.7)', borderRadius:radius.md, backdropFilter:'blur(8px)' }}>
              <div style={{ fontSize:22 }}>{ic}</div>
              <div style={{ fontFamily:font.mono, fontWeight:800, fontSize:15, color:color.n900 }}>{val}</div>
              <div style={{ fontFamily:font.body, fontSize:10, color:color.n500 }}>{lbl}</div>
            </div>
          ))}
        </div>

        <div style={{ padding:'0 24px 40px', width:'100%', display:'flex', flexDirection:'column', gap:12 }}>
          <SBButton label="Play Again 🎲" fullWidth onClick={onPlayAgain}/>
          <SBButton label="Back to Home" fullWidth variant="ghost" onClick={onHome}/>
        </div>
      </div>
    </PhoneShell>
  );
}

// ─── Settings Screen ────────────────────────────────────────────
function ScreenHifiM1({ onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [darkMode, setDarkMode] = React.useState(false);
  const [largerMode, setLargerMode] = React.useState(false);
  const [notifs, setNotifs]   = React.useState(true);

  const SwitchRow = ({ label, subtitle, value, onChange, icon }) => (
    <div style={{ display:'flex', alignItems:'center', gap:14, padding:'16px 0', borderBottom:`1px solid ${color.n100}` }}>
      <div style={{ width:40, height:40, borderRadius:12, background:color.primary50, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>{icon}</div>
      <div style={{ flex:1 }}>
        <div style={{ fontFamily:font.display, fontWeight:700, fontSize:15, color:color.n900 }}>{label}</div>
        {subtitle && <div style={{ fontFamily:font.body, fontSize:12, color:color.n500, marginTop:2 }}>{subtitle}</div>}
      </div>
      <div onClick={() => onChange(!value)} style={{
        width:51, height:31, borderRadius:radius.full, cursor:'pointer',
        background: value ? color.primary500 : color.n200,
        position:'relative', transition:'background 250ms',
        flexShrink:0,
      }}>
        <div style={{
          width:27, height:27, borderRadius:'50%', background:'#fff',
          position:'absolute', top:2, left: value ? 22 : 2,
          boxShadow:shadow.sm, transition:'left 250ms',
        }}/>
      </div>
    </div>
  );

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar title="Settings" onBack={onBack}/>
      <div style={{ flex:1, background:color.n0, overflowY:'auto' }}>
        {/* Profile section */}
        <div style={{ padding:'20px 24px', background:grad.sunrise, display:'flex', alignItems:'center', gap:16 }}>
          <SBOrb name="Sarah" colorIdx={0} size={64} self/>
          <div>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:20, color:color.n900 }}>Sarah</div>
            <div style={{ fontFamily:font.body, fontSize:13, color:color.n500 }}>Member since 2024</div>
          </div>
          <button style={{ marginLeft:'auto', height:36, borderRadius:radius.full, padding:'0 16px', background:color.primary100, border:'none', cursor:'pointer', fontFamily:font.body, fontWeight:700, fontSize:13, color:color.primary700 }}>Edit</button>
        </div>

        <div style={{ padding:'16px 24px' }}>
          <div style={{ fontFamily:font.body, fontSize:12, fontWeight:700, color:color.n400, letterSpacing:'0.08em', textTransform:'uppercase', marginBottom:8 }}>Display</div>
          <SwitchRow icon="🌙" label="Dark Mode" subtitle="Easy on the eyes at night" value={darkMode} onChange={setDarkMode}/>
          <SwitchRow icon="🔤" label="Larger & Calmer" subtitle="Bigger text and spacing" value={largerMode} onChange={setLargerMode}/>

          <div style={{ fontFamily:font.body, fontSize:12, fontWeight:700, color:color.n400, letterSpacing:'0.08em', textTransform:'uppercase', marginBottom:8, marginTop:24 }}>Notifications</div>
          <SwitchRow icon="🔔" label="Game Reminders" subtitle="When it's your turn" value={notifs} onChange={setNotifs}/>

          <div style={{ fontFamily:font.body, fontSize:12, fontWeight:700, color:color.n400, letterSpacing:'0.08em', textTransform:'uppercase', marginBottom:8, marginTop:24 }}>Language</div>
          {[['🇺🇸','English','Active'],['🇮🇱','עברית',''],['🇷🇺','Русский','']].map(([flag,lang,active]) => (
            <div key={lang} style={{ display:'flex', alignItems:'center', gap:14, padding:'14px 0', borderBottom:`1px solid ${color.n100}` }}>
              <span style={{ fontSize:24 }}>{flag}</span>
              <span style={{ fontFamily:font.display, fontWeight:700, fontSize:16, color:color.n900, flex:1 }}>{lang}</span>
              {active && <span style={{ fontFamily:font.body, fontSize:12, fontWeight:700, color:color.primary500 }}>✓ Active</span>}
              {!active && <span style={{ fontFamily:font.body, fontSize:12, color:color.n400 }}>Select →</span>}
            </div>
          ))}

          <div style={{ marginTop:32, display:'flex', flexDirection:'column', gap:12 }}>
            <button style={{ height:52, borderRadius:radius['2xl'], background:color.n100, border:'none', cursor:'pointer', fontFamily:font.display, fontWeight:700, fontSize:15, color:color.n700 }}>Help & Support</button>
            <button style={{ height:52, borderRadius:radius['2xl'], background:'rgba(212,106,106,0.1)', border:'none', cursor:'pointer', fontFamily:font.display, fontWeight:700, fontSize:15, color:color.error }}>Sign Out</button>
          </div>
        </div>
      </div>
    </PhoneShell>
  );
}

Object.assign(window, {
  ScreenHifiD1, ScreenHifiE2, ScreenHifiG1, ScreenHifiI1,
  ScreenHifiL1, ScreenHifiM1,
});
