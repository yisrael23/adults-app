
// Senior Brains Wireframes — Flows E, F, G, H
// Requires wf-primitives.jsx loaded first

// ═══════════════════════════════════════════
// FLOW E: ACTIVITY SELECTION (5 screens)
// ═══════════════════════════════════════════

const ScreenE1 = () => (
  <WireScreen number="E1" title="Wheel of Fortune — Idle" annotations={[
    {title:'Host only', body:'Spin button active only for Host. Non-host sees greyed button + "Waiting for [Host] to spin."'},
    {title:'Wheel segments', body:'5 segments = 5 launch games. Labels: Scrabble, Checkers, Jeopardy, Crossword, Sudoku.'},
    {title:'Sync', body:'Wheel state broadcast to all via Supabase Realtime. All see same wheel position.'},
    {title:'Adaptive', body:'Spin button 44px → 56px. Wheel scales proportionally.'},
  ]}>
    <StatusBar/>
    <TopBar title="Pick an Activity" back={true} action="Browse all"/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <ParticipantsRow y={0} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
      {/* Wheel placeholder */}
      <Circle x={70} y={96} size={250} fill={WC.g1} stroke={WC.g3}>
        {/* 5 segment lines */}
        {[0,72,144,216,288].map((deg,i)=>(
          <div key={i} style={{
            position:'absolute',top:'50%',left:'50%',width:'50%',height:1.5,
            background:WC.g3,transformOrigin:'left center',
            transform:`rotate(${deg}deg)`
          }}/>
        ))}
        {/* Labels */}
        {[['Scrabble',36],['Checkers',108],['Jeopardy',180],['Crossword',252],['Sudoku',324]].map(([label,deg])=>(
          <div key={label} style={{
            position:'absolute',top:'50%',left:'50%',
            transform:`rotate(${deg}deg) translateX(65px) rotate(-${deg}deg)`,
            fontSize:9,fontWeight:600,color:WC.g5,marginTop:-5,marginLeft:-24,
          }}>{label}</div>
        ))}
        {/* Center pin */}
        <Circle x={110} y={110} size={30} fill={WC.g3} stroke={WC.g4}/>
      </Circle>
      {/* Pointer */}
      <div style={{position:'absolute',left:192,top:88,width:0,height:0,borderLeft:'8px solid transparent',borderRight:'8px solid transparent',borderBottom:`20px solid ${WC.black}`}}/>
      <Btn x={115} y={366} w={160} h={52} label="Spin!" fill={WC.g2} stroke={WC.g3} bold={true} textSize={16}/>
      <Txt x={50} y={428} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Host only — others see: "Waiting for You to spin…"</Txt>
    </Box>
  </WireScreen>
);

const ScreenE2 = () => (
  <WireScreen number="E2" title="Wheel — Spinning" annotations={[
    {title:'Animation', body:'CSS spin animation, eases out over ~3s. Broadcast to all devices simultaneously.'},
    {title:'Non-host', body:'Non-host sees identical animation but no spin control. Annotated: "Spin animation broadcast to all devices. Non-host sees identical animation, no spin control."'},
    {title:'Reduced motion', body:'If OS reduced motion → wheel snaps to result after short fade.'},
    {title:'Server', body:'Result pre-determined server-side before spin starts. Animation is cosmetic.'},
  ]}>
    <StatusBar/>
    <TopBar title="Pick an Activity" back={false} action="Browse all"/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <ParticipantsRow y={0} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'}]}/>
      <Circle x={70} y={96} size={250} fill={WC.g1} stroke={WC.g3} style={{animation:'spin 0.5s linear infinite'}}>
        {[0,72,144,216,288].map((deg,i)=>(
          <div key={i} style={{position:'absolute',top:'50%',left:'50%',width:'50%',height:1.5,background:WC.g3,transformOrigin:'left center',transform:`rotate(${deg}deg)`}}/>
        ))}
        {[['Scrabble',36],['Checkers',108],['Jeopardy',180],['Crossword',252],['Sudoku',324]].map(([label,deg])=>(
          <div key={label} style={{position:'absolute',top:'50%',left:'50%',transform:`rotate(${deg}deg) translateX(65px) rotate(-${deg}deg)`,fontSize:9,fontWeight:600,color:WC.g5,marginTop:-5,marginLeft:-24}}>{label}</div>
        ))}
        <Circle x={110} y={110} size={30} fill={WC.g3} stroke={WC.g4}/>
      </Circle>
      <div style={{position:'absolute',left:192,top:88,width:0,height:0,borderLeft:'8px solid transparent',borderRight:'8px solid transparent',borderBottom:`20px solid ${WC.black}`}}/>
      <Box x={60} y={368} w={270} h={44} r={10} fill={WC.g1} stroke={WC.g3}>
        <Txt x={0} y={14} size={11} color={WC.g4} style={{position:'static'}}>Spinning… ⟳</Txt>
      </Box>
      <Txt x={50} y={424} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>⚡ Spin synced to all devices via Supabase Realtime</Txt>
    </Box>
  </WireScreen>
);

const ScreenE3 = () => (
  <WireScreen number="E3" title="Wheel — Result Revealed" annotations={[
    {title:'Result', body:'Wheel lands on result. Confetti burst (reduced motion: skip). Activity name shown large.'},
    {title:'Auto-navigate', body:'After 2s, all participants auto-navigate to that activity\'s setup screen simultaneously. Server-push event triggers navigation.'},
    {title:'Override', body:'Host can tap a different activity if they want to override. 3s countdown shown.'},
  ]}>
    <StatusBar/>
    <TopBar title="Pick an Activity" back={false}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <ParticipantsRow y={0} participants={[{name:'You',state:'muted'},{name:'Mom',state:'muted'}]}/>
      <Circle x={70} y={96} size={250} fill={WC.g1} stroke={WC.g3}>
        {[0,72,144,216,288].map((deg,i)=>(<div key={i} style={{position:'absolute',top:'50%',left:'50%',width:'50%',height:1.5,background:WC.g3,transformOrigin:'left center',transform:`rotate(${deg}deg)`}}/>))}
        <Circle x={110} y={110} size={30} fill={WC.g3} stroke={WC.g4}/>
      </Circle>
      <div style={{position:'absolute',left:192,top:88,width:0,height:0,borderLeft:'8px solid transparent',borderRight:'8px solid transparent',borderBottom:`20px solid ${WC.black}`}}/>
      {/* Result reveal */}
      <Box x={30} y={360} w={330} h={80} r={14} fill={WC.g2} stroke={WC.g3}>
        <Txt x={60} y={14} size={22} weight={700} color={WC.black} style={{position:'static'}}>🎲 Scrabble!</Txt>
        <Txt x={60} y={42} size={10} color={WC.g4} style={{position:'static'}}>Everyone navigating in 3s…</Txt>
      </Box>
      <Btn x={30} y={454} w={330} h={44} label="Go now →" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Btn x={30} y={506} w={330} h={36} label="Choose a different activity" fill={WC.bg} stroke={WC.g3} textSize={10}/>
    </Box>
  </WireScreen>
);

const ScreenE4 = () => (
  <WireScreen number="E4" title="Browse All Activities" annotations={[
    {title:'Grid', body:'2-column card grid. Each card shows game name, player count, estimated time, solo/multi badge.'},
    {title:'Filter', body:'Filter chips: All / Turn-based / Trivia / Puzzle. Default: All.'},
    {title:'Adaptive', body:'Cards taller in Larger & Calmer (80→100px). Font 12→16px.'},
  ]}>
    <StatusBar/>
    <TopBar title="All Activities" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      {/* Filter chips */}
      <div style={{position:'absolute',left:16,top:12,display:'flex',gap:8}}>
        {['All','Turn-based','Trivia','Puzzle'].map((f,i)=>(
          <Box key={f} x={0} y={0} w={i===0?36:i===3?52:74} h={28} r={14} fill={i===0?WC.g3:WC.g1} stroke={WC.g3} style={{position:'relative'}}>
            <span style={{fontSize:10,fontWeight:i===0?600:400}}>{f}</span>
          </Box>
        ))}
      </div>
      {/* Activity cards 2-col */}
      {[
        ['Scrabble','2-4 players · Turn-based','15-45 min'],
        ['Checkers','2 players · Turn-based','10-20 min'],
        ['Jeopardy','2-4 players · Trivia','20-40 min'],
        ['Crossword','2-4 collab · Puzzle','15-30 min'],
        ['Sudoku','2-4 collab · Puzzle','10-25 min'],
      ].map(([name,desc,time],i)=>(
        <Box key={i} x={16+(i%2)*186} y={56+(Math.floor(i/2))*92} w={170} h={80} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Box x={12} y={10} w={40} h={40} r={8} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={60} y={10} size={11} weight={600}>{name}</Txt>
          <Txt x={60} y={28} size={8} color={WC.g4} w={96}>{desc}</Txt>
          <Txt x={60} y={50} size={8} color={WC.g4}>{time}</Txt>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenE5 = () => (
  <WireScreen number="E5" title="Activity Detail Preview" annotations={[
    {title:'Rules', body:'Scrollable rules summary — 3-5 bullet points. Link to full rules page.'},
    {title:'Preview', body:'Static illustration of game board (placeholder box).'},
    {title:'Start', body:'"Start Game" auto-navigates all participants to setup screen. Host only.'},
    {title:'Non-host', body:'Non-host sees "Suggest to Host" button instead of Start.'},
  ]}>
    <StatusBar/>
    <TopBar title="Scrabble" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Box x={20} y={10} w={350} h={180} r={14} fill={WC.g1} stroke={WC.g2} style={{borderStyle:'dashed'}}>
        <Txt x={120} y={80} size={10} color={WC.g4}>[ Board Preview ]</Txt>
      </Box>
      <Txt x={20} y={204} size={16} weight={700}>Scrabble</Txt>
      <div style={{position:'absolute',left:20,top:228,display:'flex',gap:6}}>
        <Tag x={0} y={0} label="2-4 players" fill={WC.g2}/>
        <Tag x={80} y={0} label="Turn-based" fill={WC.g2}/>
        <Tag x={166} y={0} label="15-45 min" fill={WC.g2}/>
      </div>
      <Txt x={20} y={260} size={11} color={WC.g5} w={350}>Build words on the board using your 7 letter tiles. Score points by placing tiles on bonus squares. The player with the highest score wins.</Txt>
      <Txt x={20} y={316} size={10} weight={600} color={WC.g5}>HOW TO PLAY</Txt>
      {['Each player draws 7 tiles.','Take turns placing words on the board.','Words must connect to existing tiles.','Double/Triple word & letter squares give bonus points.','Game ends when tiles run out.'].map((rule,i)=>(
        <Txt key={i} x={20} y={334+i*18} size={10} color={WC.g5} w={350}>• {rule}</Txt>
      ))}
      <Btn x={20} y={440} w={350} h={52} label="Start Scrabble" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={20} y={502} w={350} h={40} label="Suggest to Host" fill={WC.g1} stroke={WC.g3} textSize={11}/>
      <Txt x={50} y={552} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Only the Host can start the game for all players</Txt>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW F: ACTIVITY SHELL (2 screens)
// ═══════════════════════════════════════════

const ScreenF1 = () => (
  <WireScreen number="F1" title="Activity Shell — Base Layout" annotations={[
    {title:'Top bar', body:'Game title + turn indicator + pause/exit. Same across all games.'},
    {title:'Participants row', body:'Always visible below top bar. Orbs show speaking/muted/disconnected states.'},
    {title:'Content area', body:'Game-specific content fills this zone. Scrollable if needed.'},
    {title:'Bottom toolbar', body:'Context-sensitive: Pointer mode toggle, Submit (Scrabble), Pass, Hint. Always 44px tall (56px Larger & Calmer).'},
    {title:'Tablet', body:'On iPad: participants shown in a side column, not top row.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 16px'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}>
        <Txt x={0} y={7} size={10} style={{position:'static'}}>Your turn · 02:34</Txt>
      </Box>
      <Txt x={360} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    {/* Content area */}
    <Box x={0} y={168} w={390} h={570} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderStyle:'dashed'}}>
      <Txt x={110} y={268} size={11} color={WC.g4}>[Game content area]</Txt>
      <Txt x={80} y={288} size={9} color={WC.g4}>Fills full width. Game-specific.</Txt>
    </Box>
    {/* Bottom toolbar */}
    <Box x={0} y={738} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none',display:'flex',gap:0}}>
      {['👆 Pointer','💡 Hint','⏭ Pass','✓ Submit'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={i===3?WC.g3:WC.g2} stroke={WC.g3} style={{borderRadius:0}}>
          <span style={{fontSize:10,fontWeight:i===3?600:400}}>{label}</span>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenF2 = () => (
  <WireScreen number="F2" title="Pointer Mode Active" annotations={[
    {title:'Activation', body:'Tap "👆 Pointer" in bottom toolbar to enter pointer mode. Tap again to exit.'},
    {title:'Own pointer', body:'Solid crosshair (State A). Labeled "You". Follows finger drag.'},
    {title:'Remote pointer', body:'Dashed crosshair bloom (State B). Labeled "Other player\'s pointer". Positioned from server data.'},
    {title:'Latency', body:'"Pointer position is broadcast via Supabase Realtime at ~60ms latency. Each user sees all active pointers simultaneously."'},
    {title:'Multi-pointer', body:'Up to 3 simultaneous pointers (one per remote participant). Each has unique label.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Your turn</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'}]}/>
    {/* Game content with pointers overlaid */}
    <Box x={0} y={168} w={390} h={570} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',position:'relative'}}>
      <Txt x={110} y={50} size={10} color={WC.g4}>[Game board behind pointers]</Txt>

      {/* State A: Own pointer — solid crosshair */}
      <div style={{position:'absolute',left:150,top:160}}>
        {/* horizontal */}
        <div style={{position:'absolute',top:10,left:0,width:24,height:2,background:WC.black}}/>
        <div style={{position:'absolute',top:10,left:16,width:24,height:2,background:WC.black}}/>
        {/* vertical */}
        <div style={{position:'absolute',top:0,left:11,width:2,height:12,background:WC.black}}/>
        <div style={{position:'absolute',top:12,left:11,width:2,height:12,background:WC.black}}/>
        <Box x={-8} y={24} w={42} h={16} r={4} fill={WC.g5} stroke="none">
          <Txt x={0} y={3} size={9} color='#fff' style={{position:'static'}}>You</Txt>
        </Box>
      </div>

      {/* State B: Remote pointer — dashed bloom */}
      <div style={{position:'absolute',left:240,top:260}}>
        {/* outer bloom ring */}
        <div style={{position:'absolute',top:-12,left:-12,width:48,height:48,borderRadius:'50%',border:`2px dashed ${WC.g4}`}}/>
        {/* crosshair dashed */}
        <div style={{position:'absolute',top:10,left:0,width:10,height:2,background:WC.g4,borderRadius:1}}/>
        <div style={{position:'absolute',top:10,left:14,width:10,height:2,background:WC.g4,borderRadius:1}}/>
        <div style={{position:'absolute',top:0,left:11,width:2,height:10,background:WC.g4,borderRadius:1}}/>
        <div style={{position:'absolute',top:14,left:11,width:2,height:10,background:WC.g4,borderRadius:1}}/>
        <Box x={-20} y={24} w={64} h={20} r={4} fill={WC.g3} stroke={WC.g4}>
          <Txt x={0} y={4} size={8} color={WC.g5} style={{position:'static'}}>Mom's pointer</Txt>
        </Box>
        <Txt x={-30} y={48} size={8} color={WC.g4} w={100}>synced ~60ms</Txt>
      </div>

      {/* Pointer mode indicator banner */}
      <Box x={60} y={510} w={270} h={32} r={10} fill={WC.g3} stroke={WC.g4}>
        <Txt x={0} y={9} size={10} weight={600} style={{position:'static'}}>👆 Pointer Mode — drag to point</Txt>
      </Box>
    </Box>
    <Box x={0} y={738} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer ✓','💡 Hint','⏭ Pass','✓ Submit'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={i===0?WC.g4:WC.g2} stroke={WC.g3} style={{borderRadius:0}}>
          <span style={{fontSize:10,fontWeight:i===0?700:400}}>{label}</span>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW G: SCRABBLE (8 screens)
// ═══════════════════════════════════════════

const BOARD_SIZE = 15;
const boardCell = (x,y,letter='',bonus='') => (
  <div key={`${x}-${y}`} style={{
    width:20,height:20,border:`0.5px solid ${WC.g3}`,
    background:bonus==='DW'?WC.g3:bonus==='TW'?WC.g4:bonus==='DL'?WC.g2:WC.bg,
    display:'flex',alignItems:'center',justifyContent:'center',
    fontSize:7,fontWeight:letter?600:400,color:letter?WC.black:WC.g3,
  }}>{letter||bonus.substring(0,2)}</div>
);

const ScrabbleBoard = ({x=20,y=20,placedWord=null}) => (
  <div style={{position:'absolute',left:x,top:y,display:'grid',gridTemplateColumns:'repeat(15,20px)',gridTemplateRows:'repeat(15,20px)',gap:0,border:`1px solid ${WC.g3}`}}>
    {Array.from({length:225}).map((_,i)=>{
      const col=i%15, row=Math.floor(i/15);
      // place word horizontally at row 7
      const wordLetters=placedWord?[...'BRAIN']:[];
      const letter=placedWord&&row===7&&col>=5&&col<5+wordLetters.length?wordLetters[col-5]:'';
      const bonus=(row===0&&col===0)||(row===7&&col===7)?'★':(row===0&&col===7)||(row===7&&col===0)?'TW':(row===1&&col===1)?'DW':'';
      return boardCell(col,row,letter,bonus);
    })}
  </div>
);

const ScreenG1 = () => (
  <WireScreen number="G1" title="Scrabble — Game Setup" annotations={[
    {title:'Language', body:'Dictionary language separate from UI language. Validates words against chosen dictionary.'},
    {title:'Assumption', body:'15×15 standard board only at launch (no size variant). Annotated as assumption.'},
    {title:'Host only', body:'Setup screen shown to Host who configures. Others see "Waiting for host to set up…"'},
  ]}>
    <StatusBar/>
    <TopBar title="Scrabble Setup" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Txt x={30} y={20} size={11} weight={600} color={WC.g5}>DICTIONARY LANGUAGE</Txt>
      {['English (TWL)','English (SOWPODS)','Hebrew','Russian'].map((lang,i)=>(
        <Box key={i} x={30} y={38+i*52} w={330} h={44} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3} dash={i!==0}>
          <Txt x={16} y={13} size={12}>{lang}</Txt>
          {i===0&&<Tag x={250} y={12} label="Selected" fill={WC.g3}/>}
        </Box>
      ))}
      <Txt x={30} y={258} size={11} weight={600} color={WC.g5}>BOARD</Txt>
      <Box x={30} y={276} w={330} h={44} r={10} fill={WC.g2} stroke={WC.g3}>
        <Txt x={16} y={13} size={12}>Standard 15×15</Txt>
        <Tag x={240} y={12} label="Only option" fill={WC.g3}/>
      </Box>
      <Txt x={30} y={330} size={9} color={WC.g4} style={{fontStyle:'italic'}}>* Assumption: one board size at launch</Txt>
      <Btn x={30} y={370} w={330} h={52} label="Start Scrabble" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
    </Box>
  </WireScreen>
);

const ScreenG2 = () => (
  <WireScreen number="G2" title="Scrabble — Board (Your Turn)" annotations={[
    {title:'PointerOverlay', body:'State A (You, solid crosshair) + State B (remote dashed bloom) both visible when pointer mode active. See F2 for detail.'},
    {title:'Rack', body:'Your 7 tiles always visible at bottom. Others cannot see your rack.'},
    {title:'Board', body:'15×15 grid. DW/TW/DL/TL bonus squares marked. Placed tiles shown in bold.'},
    {title:'Turn', body:'Top bar shows "Your turn" + timer. Opponent\'s turn shows "Mom\'s turn".'},
    {title:'Adaptive', body:'Tile rack font 14→18px. Tiles 28×28→36×36px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn · 01:45</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={436} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10} placedWord="BRAIN"/>
      {/* Scores overlay */}
      <Box x={320} y={10} w={60} h={70} r={8} fill={WC.g1} stroke={WC.g2}>
        <Txt x={6} y={4} size={8} color={WC.g5}>You: 42</Txt>
        <Txt x={6} y={18} size={8} color={WC.g5}>Mom: 38</Txt>
        <Txt x={6} y={32} size={8} color={WC.g5}>Jake: 21</Txt>
      </Box>
    </Box>
    {/* Tile rack */}
    <Box x={0} y={604} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={16} y={8} size={9} color={WC.g5}>YOUR TILES</Txt>
      <div style={{position:'absolute',left:20,top:22,display:'flex',gap:6}}>
        {['A','R','T','I','S','E','N'].map(l=>(
          <Box key={l} x={0} y={0} w={34} h={34} r={6} fill={WC.g2} stroke={WC.g4} style={{position:'relative'}}>
            <span style={{fontSize:14,fontWeight:700}}>{l}</span>
            <span style={{position:'absolute',bottom:2,right:3,fontSize:7,color:WC.g5}}>1</span>
          </Box>
        ))}
      </div>
    </Box>
    <Box x={0} y={668} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','🔀 Shuffle','✗ Recall','✓ Submit'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={i===3?WC.g3:WC.g2} stroke={WC.g3} style={{borderRadius:0}}>
          <span style={{fontSize:9,fontWeight:i===3?700:400}}>{label}</span>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenG3 = () => (
  <WireScreen number="G3" title="Scrabble — Watching (Other's Turn)" annotations={[
    {title:'Watching state', body:'Your rack hidden (or dimmed). Board shows other player\'s tile being placed in real-time.'},
    {title:'Pointer', body:'Pointer mode still available. You can point and discuss via voice.'},
    {title:'Real-time', body:'Opponent\'s tile placements appear on your board as they drag (ghost tile).'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Mom's turn · 00:58</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'muted'},{name:'Mom',state:'speaking'},{name:'Jake',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={436} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10} placedWord="BRAIN"/>
      {/* Ghost tile being placed */}
      <Box x={180} y={160} w={20} h={20} r={3} fill={WC.g3} stroke={WC.g4} style={{opacity:0.6}}>
        <Txt x={4} y={4} size={9} weight={700} color={WC.g5}>S</Txt>
      </Box>
      <Box x={150} y={185} w={80} h={16} r={4} fill={WC.g3} stroke="none">
        <Txt x={0} y={2} size={8} style={{position:'static'}}>Mom placing…</Txt>
      </Box>
    </Box>
    {/* Rack hidden */}
    <Box x={0} y={604} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',opacity:0.4}}>
      <Txt x={130} y={22} size={10} color={WC.g4}>Your rack (hidden)</Txt>
    </Box>
    <Box x={0} y={668} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','—','—','—'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0,opacity:i>0?0.3:1}}>
          <span style={{fontSize:9}}>{label}</span>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenG4 = () => (
  <WireScreen number="G4" title="Scrabble — Dragging Tile" annotations={[
    {title:'Drag', body:'Long-press tile in rack → lifts tile (scale 1.1×, shadow). Drag to board cell. Cell highlights on hover.'},
    {title:'Snap', body:'Tile snaps to board grid. Invalid cells (occupied) reject the tile.'},
    {title:'Ghost', body:'Ghost tile remains in rack position while dragging.'},
    {title:'Haptics', body:'Haptic feedback on successful snap. iOS: medium impact. Android: CLICK.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn · 01:12</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={436} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10}/>
      {/* Highlighted target cell */}
      <div style={{position:'absolute',left:200,top:152,width:20,height:20,background:WC.g3,border:`2px solid ${WC.g5}`}}/>
      {/* Dragged tile (floating) */}
      <Box x={190} y={130} w={26} h={26} r={5} fill={WC.g3} stroke={WC.g4} style={{boxShadow:'0 4px 12px rgba(0,0,0,0.15)',transform:'scale(1.1)'}}>
        <Txt x={6} y={4} size={12} weight={700}>T</Txt>
      </Box>
      <Txt x={155} y={165} size={8} color={WC.g4}>Dragging "T" → board cell</Txt>
    </Box>
    <Box x={0} y={604} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      <div style={{position:'absolute',left:20,top:22,display:'flex',gap:6}}>
        {['A','R','_','I','S','E','N'].map((l,i)=>(
          <Box key={i} x={0} y={0} w={34} h={34} r={6} fill={l==='_'?WC.g1:WC.g2} stroke={l==='_'?WC.g3:WC.g4} style={{position:'relative',opacity:l==='_'?0.3:1}}>
            {l!=='_'&&<span style={{fontSize:14,fontWeight:700}}>{l}</span>}
          </Box>
        ))}
      </div>
    </Box>
    <Box x={0} y={668} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','🔀 Shuffle','✗ Recall','✓ Submit'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={i===3?WC.g3:WC.g2} stroke={WC.g3} style={{borderRadius:0}}>
          <span style={{fontSize:9,fontWeight:i===3?700:400}}>{label}</span>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenG5 = () => (
  <WireScreen number="G5" title="Scrabble — Submit Confirmation" annotations={[
    {title:'Preview', body:'Word highlighted on board + score preview shown before submit.'},
    {title:'Submit', body:'Server validates word against dictionary. If valid → scores added, next turn.'},
    {title:'Challenge', body:'Other players can challenge word within 5s of placement (voice agreement, no UI challenge at launch). Annotated as assumption.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn — confirm?</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={376} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10} placedWord="BRAIN"/>
      {/* Highlight placed word */}
      <div style={{position:'absolute',left:120,top:148,width:100,height:20,background:WC.g3,opacity:0.4,borderRadius:2}}/>
      <Txt x={120} y={175} size={8} color={WC.g4}>"BRAIN" highlighted</Txt>
    </Box>
    {/* Score preview */}
    <Box x={30} y={554} w={330} h={60} r={12} fill={WC.g1} stroke={WC.g2}>
      <Txt x={16} y={10} size={12} weight={600}>BRAIN</Txt>
      <Txt x={16} y={28} size={10} color={WC.g4}>Preview score: +18 pts (DW bonus)</Txt>
    </Box>
    <div style={{position:'absolute',left:30,top:624,display:'flex',gap:12}}>
      <Btn x={0} y={0} w={156} h={48} label="✗ Recall tiles" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={168} y={0} w={162} h={48} label="✓ Submit word" fill={WC.g3} stroke={WC.g4} bold={true} textSize={13}/>
    </div>
  </WireScreen>
);

const ScreenG6 = () => (
  <WireScreen number="G6" title="Scrabble — Invalid Word Error" annotations={[
    {title:'Error', body:'Red-toned banner (grayscale: dark gray) shows at bottom. Tiles returned to rack.'},
    {title:'Recovery', body:'Player can try again. Timer continues from pause point.'},
    {title:'Voice', body:'Voice channel stays open. Players can discuss via voice.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Scrabble</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn · 00:47</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={376} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10}/>
    </Box>
    {/* Error banner */}
    <Box x={0} y={544} w={390} h={56} r={0} fill={WC.g4} stroke={WC.g5} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={20} y={10} size={12} weight={700} color={WC.bg}>"BRAINT" is not a valid word</Txt>
      <Txt x={20} y={28} size={10} color={WC.bg}>English (SOWPODS) dictionary · Try again</Txt>
    </Box>
    <Box x={0} y={600} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={16} y={8} size={9} color={WC.g5}>YOUR TILES (returned)</Txt>
      <div style={{position:'absolute',left:20,top:22,display:'flex',gap:6}}>
        {['A','R','T','I','S','E','N'].map(l=>(<Box key={l} x={0} y={0} w={34} h={34} r={6} fill={WC.g2} stroke={WC.g4} style={{position:'relative'}}><span style={{fontSize:14,fontWeight:700}}>{l}</span></Box>))}
      </div>
    </Box>
    <Box x={0} y={664} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','🔀 Shuffle','✗ Recall','✓ Submit'].map((label,i)=>(<Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0}}><span style={{fontSize:9}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenG7 = () => (
  <WireScreen number="G7" title="Scrabble — End of Game" annotations={[
    {title:'Trigger', body:'Game ends when tile bag empty and one player uses all tiles, or all players pass consecutively.'},
    {title:'Final scores', body:'Ranked list with winner highlighted. Final tiles deducted.'},
    {title:'Actions', body:'"Play again" restarts same players. "New activity" → Wheel.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={80} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={120} y={14} size={18} weight={700} color={WC.black}>Game Over!</Txt>
        <Txt x={140} y={40} size={11} color={WC.g4}>Final Scores</Txt>
      </Box>
      {[['🥇 You','142 pts','Winner!'],['🥈 Mom','118 pts',''],['🥉 Jake','94 pts','']].map(([name,score,badge],i)=>(
        <Box key={i} x={30} y={96+i*70} w={330} h={60} r={12} fill={i===0?WC.g3:WC.g1} stroke={WC.g3}>
          <Txt x={16} y={10} size={14} weight={600}>{name}</Txt>
          <Txt x={16} y={30} size={20} weight={700}>{score}</Txt>
          {badge&&<Tag x={240} y={18} label={badge} fill={WC.g4}/>}
        </Box>
      ))}
      <Btn x={30} y={310} w={330} h={52} label="Play Scrabble Again" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={372} w={330} h={44} label="🎡  Spin for Next Activity" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={426} w={330} h={44} label="Back to Lobby" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const ScreenG8 = () => (
  <WireScreen number="G8" title="Scrabble — Pause / Exit" annotations={[
    {title:'Pause', body:'Game timer pauses for all players simultaneously. Board locked.'},
    {title:'Exit warning', body:'"Leave game" warns that the game will end for everyone if host leaves.'},
    {title:'Resume', body:'"Resume" returns all players to game state.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none" style={{opacity:0.35}}>
      <Txt x={140} y={380} size={12} color={WC.g4}>Paused game behind sheet</Txt>
    </Box>
    {/* Pause sheet */}
    <Box x={0} y={280} w={390} h={564} r={0} fill={WC.bg} stroke={WC.g2} style={{borderTopLeftRadius:20,borderTopRightRadius:20,borderBottom:'none',borderLeft:'none',borderRight:'none'}}>
      <div style={{position:'absolute',top:8,left:175,width:40,height:4,borderRadius:2,background:WC.g3}}/>
      <Txt x={150} y={28} size={14} weight={700}>Game Paused</Txt>
      <Txt x={80} y={52} size={10} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>All players see this pause. Timer stopped.</Txt>
      <Btn x={30} y={90} w={330} h={52} label="▶  Resume Game" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={154} w={330} h={44} label="Save & Continue Later" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Divider x={30} y={210} w={330}/>
      <Box x={30} y={224} w={330} h={72} r={12} fill={WC.g1} stroke={WC.g3} style={{borderStyle:'dashed'}}>
        <Txt x={16} y={10} size={11} weight={600} color={WC.g5}>Leave game?</Txt>
        <Txt x={16} y={28} size={9} color={WC.g4} w={295}>As Host, leaving will end the game for everyone.</Txt>
        <Btn x={16} y={46} w={140} h={18} label="Leave anyway" fill={WC.bg} stroke={WC.g3} textSize={9}/>
      </Box>
    </Box>
  </WireScreen>
);

// RTL Scrabble board
const ScreenG2_RTL = () => (
  <WireScreen number="G2-RTL" title="Scrabble Board — Hebrew (RTL)" rtl={true} annotations={[
    {title:'RTL ⇄', body:'Tile rack reads right-to-left. Board itself does NOT mirror (board is symmetric). UI chrome mirrors.'},
    {title:'Hebrew tiles', body:'Hebrew letters on tiles. Score values per Hebrew Scrabble rules.'},
    {title:'Dictionary', body:'Hebrew dictionary selected in G1 setup.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',direction:'rtl'}}>
      <Txt x={16} y={16} size={13} weight={600} style={{position:'absolute',right:16}}>סקרבל</Txt>
      <Box x={110} y={12} w={170} h={28} r={8} fill={WC.g3} stroke={WC.g4} style={{position:'absolute',left:'50%',transform:'translateX(-50%)'}}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>התור שלך · 01:45</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={376} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <ScrabbleBoard x={20} y={10}/>
    </Box>
    <Box x={0} y={544} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',direction:'rtl'}}>
      <Txt x={16} y={8} size={9} color={WC.g5} style={{position:'absolute',right:16}}>האריחים שלך</Txt>
      <div style={{position:'absolute',right:20,top:22,display:'flex',gap:6}}>
        {['א','ב','ג','ד','ה','ו','ז'].map(l=>(<Box key={l} x={0} y={0} w={34} h={34} r={6} fill={WC.g2} stroke={WC.g4} style={{position:'relative'}}><span style={{fontSize:14,fontWeight:700}}>{l}</span></Box>))}
      </div>
    </Box>
    <Box x={0} y={608} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none',direction:'rtl'}}>
      {['✓ שלח','✗ החזר','🔀 ערבב','👆 הצבע'].map((label,i)=>(
        <Box key={i} x={i*97} y={0} w={97} h={50} r={0} fill={i===0?WC.g3:WC.g2} stroke={WC.g3} style={{borderRadius:0}}><span style={{fontSize:9,fontWeight:i===0?700:400}}>{label}</span></Box>
      ))}
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW H: CHECKERS (5 screens)
// ═══════════════════════════════════════════

const CheckersBoard = ({selectedPiece=null,validMoves=[]}) => {
  const cells=[];
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const dark=(r+c)%2===1;
      const isSelected=selectedPiece&&selectedPiece[0]===r&&selectedPiece[1]===c;
      const isValid=validMoves.some(([mr,mc])=>mr===r&&mc===c);
      const hasPiece=dark&&r<3;
      const hasOpponent=dark&&r>4;
      cells.push(
        <div key={`${r}-${c}`} style={{
          width:40,height:40,
          background:isSelected?WC.g4:isValid?WC.g3:dark?WC.g2:WC.bg,
          border:`0.5px solid ${WC.g3}`,
          display:'flex',alignItems:'center',justifyContent:'center',
          position:'relative',
        }}>
          {hasPiece&&<div style={{width:30,height:30,borderRadius:'50%',background:WC.g5,border:`2px solid ${WC.g4}`}}/>}
          {hasOpponent&&<div style={{width:30,height:30,borderRadius:'50%',background:WC.bg,border:`2px solid ${WC.g4}`}}/>}
          {isValid&&<div style={{width:16,height:16,borderRadius:'50%',border:`2px dashed ${WC.g5}`}}/>}
        </div>
      );
    }
  }
  return <div style={{position:'absolute',left:15,top:10,display:'grid',gridTemplateColumns:'repeat(8,40px)',gridTemplateRows:'repeat(8,40px)',gap:0,border:`1px solid ${WC.g3}`}}>{cells}</div>;
};

const ScreenH1 = () => (
  <WireScreen number="H1" title="Checkers — Setup" annotations={[
    {title:'Color choice', body:'Host picks dark or light pieces. Guest gets remaining color.'},
    {title:'2 players only', body:'Checkers is always 2-player. Room must have exactly 2 participants.'},
    {title:'Assumption', body:'Standard 8×8 board, standard rules. No variants at launch.'},
  ]}>
    <StatusBar/>
    <TopBar title="Checkers Setup" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Txt x={30} y={30} size={17} weight={700} w={330} style={{textAlign:'center',position:'absolute'}}>Choose your piece colour</Txt>
      <Txt x={50} y={60} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Your opponent gets the other colour.</Txt>
      <div style={{position:'absolute',left:30,top:100,display:'flex',gap:20}}>
        {[['Dark','●','Dark pieces move first'],['Light','○','You move second']].map(([name,icon,desc],i)=>(
          <Box key={i} x={0} y={0} w={160} h={180} r={14} fill={i===0?WC.g3:WC.g1} stroke={i===0?WC.g4:WC.g3} dash={i!==0} style={{position:'relative',display:'flex',flexDirection:'column',alignItems:'center',paddingTop:20}}>
            <div style={{width:60,height:60,borderRadius:'50%',background:i===0?WC.g5:WC.bg,border:`3px solid ${WC.g4}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:28}}>{icon}</div>
            <div style={{marginTop:12,fontWeight:600,fontSize:12}}>{name}</div>
            <div style={{marginTop:6,fontSize:9,color:WC.g5,textAlign:'center',padding:'0 12px'}}>{desc}</div>
          </Box>
        ))}
      </div>
      <Btn x={30} y={306} w={330} h={52} label="Start Checkers" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
    </Box>
  </WireScreen>
);

const ScreenH2 = () => (
  <WireScreen number="H2" title="Checkers — Board" annotations={[
    {title:'Board', body:'Standard 8×8. Dark squares only. Your pieces = filled. Opponent = hollow.'},
    {title:'Turn', body:'Top bar shows whose turn. Timer optional (off by default).'},
    {title:'Kings', body:'Promoted piece shows crown inside circle.'},
    {title:'Adaptive', body:'Board cells scale: 40px → 50px on tablet. Labels + turn indicator grow.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Checkers</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn (Dark)</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You (Dark)',state:'speaking'},{name:'Mom (Light)',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={470} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CheckersBoard/>
    </Box>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','💡 Hint','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0,opacity:i===2?0.3:1}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenH3 = () => (
  <WireScreen number="H3" title="Checkers — Piece Selected" annotations={[
    {title:'Selection', body:'Tap piece → highlights in dark gray. Valid move cells shown with dashed ring.'},
    {title:'Tap to move', body:'Tap a valid move cell to execute move. Or tap another piece to reselect.'},
    {title:'Forced jump', body:'If a jump is available, only jump moves are shown (annotated: standard checkers rule).'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Checkers</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Your turn — tap a move</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={470} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CheckersBoard selectedPiece={[2,1]} validMoves={[[3,0],[3,2]]}/>
    </Box>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','✗ Deselect','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenH4 = () => (
  <WireScreen number="H4" title="Checkers — Opponent's Turn" annotations={[
    {title:'Watching', body:'Board locked for interaction. Opponent\'s pieces can still be seen moving in real-time.'},
    {title:'Move animation', body:'Piece slides from old to new cell (200ms). Reduced motion: instant.'},
    {title:'Pointer', body:'Pointer mode available during opponent\'s turn.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Checkers</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Mom's turn (Light)</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You (Dark)',state:'muted'},{name:'Mom (Light)',state:'speaking'}]}/>
    <Box x={0} y={168} w={390} h={470} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden',opacity:0.85}}>
      <CheckersBoard/>
      <Txt x={100} y={240} size={9} color={WC.g4}>Mom is thinking… (watching state)</Txt>
    </Box>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','—','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0,opacity:i>0?0.3:1}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenH5 = () => (
  <WireScreen number="H5" title="Checkers — Win / Draw Screen" annotations={[
    {title:'Win condition', body:'All opponent pieces captured, or opponent cannot move.'},
    {title:'Draw', body:'Agreed draw shown with different message.'},
    {title:'Actions', body:'Rematch / New activity / Back to lobby.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Circle x={145} y={100} size={100} fill={WC.g2} stroke={WC.g3}>
        <Txt x={26} y={32} size={36}>🏆</Txt>
      </Circle>
      <Txt x={80} y={224} size={22} weight={700} color={WC.black} w={230} style={{textAlign:'center',position:'absolute'}}>You Win!</Txt>
      <Txt x={60} y={256} size={12} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>All of Mom's pieces captured. Great game!</Txt>
      <Box x={30} y={300} w={330} h={60} r={12} fill={WC.g1} stroke={WC.g2}>
        <Txt x={16} y={10} size={11} weight={600}>Final tally</Txt>
        <Txt x={16} y={28} size={10} color={WC.g4}>You: 12 pieces remaining · Mom: 0 pieces</Txt>
      </Box>
      <Btn x={30} y={380} w={330} h={52} label="Rematch" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={442} w={330} h={44} label="🎡  Next Activity" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={496} w={330} h={44} label="Back to Lobby" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const FlowEFGH = () => (
  <div style={{display:'flex',flexDirection:'column',gap:40}}>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW E — ACTIVITY SELECTION (5 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenE1/><ScreenE2/><ScreenE3/><ScreenE4/><ScreenE5/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW F — ACTIVITY SHELL + POINTER OVERLAY</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenF1/><ScreenF2/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW G — SCRABBLE (8 screens) + RTL variant</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenG1/><ScreenG2/><ScreenG3/><ScreenG4/></div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,marginTop:24}}><ScreenG5/><ScreenG6/><ScreenG7/><ScreenG8/></div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,marginTop:24}}><ScreenG2_RTL/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW H — CHECKERS (5 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenH1/><ScreenH2/><ScreenH3/><ScreenH4/><ScreenH5/></div>
    </div>
  </div>
);

Object.assign(window, {FlowEFGH});
