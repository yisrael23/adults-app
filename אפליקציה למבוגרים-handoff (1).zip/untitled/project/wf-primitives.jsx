
// Senior Brains Wireframe Primitives
// All components exported to window for cross-file use

const WC = {
  bg:    '#ffffff',
  g1:    '#f4f4f4',
  g2:    '#e2e2e2',
  g3:    '#c8c8c8',
  g4:    '#9a9a9a',
  g5:    '#555555',
  black: '#1a1a1a',
};

// ─── Base primitives ───────────────────────────────────────────
const Box = ({ x=0,y=0,w=100,h=40,r=0,fill=WC.g1,stroke=WC.g3,dash=false,style={},children }) => (
  <div style={{
    position:'absolute', left:x, top:y, width:w, height:h,
    borderRadius:r, background:fill,
    border:`1.5px ${dash?'dashed':'solid'} ${stroke}`,
    boxSizing:'border-box', overflow:'hidden',
    display:'flex', alignItems:'center', justifyContent:'center',
    ...style
  }}>{children}</div>
);

const Circle = ({x=0,y=0,size=40,fill=WC.g2,stroke=WC.g3,dash=false,children,style={}}) => (
  <div style={{
    position:'absolute', left:x, top:y, width:size, height:size,
    borderRadius:'50%', background:fill,
    border:`1.5px ${dash?'dashed':'solid'} ${stroke}`,
    boxSizing:'border-box', overflow:'hidden',
    display:'flex', alignItems:'center', justifyContent:'center',
    fontSize:10, color:WC.g5, ...style
  }}>{children}</div>
);

const Txt = ({x=0,y=0,size=11,color=WC.black,weight=400,align='left',w,children,style={}}) => (
  <div style={{
    position:'absolute', left:x, top:y,
    fontSize:size, color, fontWeight:weight, textAlign:align,
    width:w, lineHeight:1.35, ...style
  }}>{children}</div>
);

const Btn = ({x=0,y=0,w=160,h=44,label='Button',fill=WC.g2,stroke=WC.g3,dash=false,textSize=12,bold=false}) => (
  <Box x={x} y={y} w={w} h={h} r={12} fill={fill} stroke={stroke} dash={dash}>
    <span style={{fontSize:textSize,fontWeight:bold?600:400,color:WC.black}}>{label}</span>
  </Box>
);

const Input = ({x=0,y=0,w=330,h=44,placeholder='',icon=false}) => (
  <Box x={x} y={y} w={w} h={h} r={10} fill={WC.g1} stroke={WC.g3}>
    <span style={{fontSize:11,color:WC.g4,position:'absolute',left:14}}>{placeholder}</span>
    {icon && <div style={{position:'absolute',right:14,width:16,height:16,background:WC.g3,borderRadius:'50%'}}/>}
  </Box>
);

const Divider = ({x=0,y=0,w=390}) => (
  <div style={{position:'absolute',left:x,top:y,width:w,height:1,background:WC.g2}}/>
);

const Tag = ({x=0,y=0,label='Tag',fill=WC.g2}) => (
  <div style={{position:'absolute',left:x,top:y,background:fill,border:`1px solid ${WC.g3}`,borderRadius:20,padding:'3px 10px',fontSize:9,color:WC.g5}}>{label}</div>
);

// ─── TopBar ────────────────────────────────────────────────────
const TopBar = ({title='',back=true,action=null,y=44}) => (
  <>
    <Box x={0} y={y} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      {back && <div style={{position:'absolute',left:16,fontSize:12,color:WC.black}}>‹ Back</div>}
      <span style={{fontSize:13,fontWeight:600,color:WC.black}}>{title}</span>
      {action && <div style={{position:'absolute',right:16,fontSize:11,color:WC.g5}}>{action}</div>}
    </Box>
  </>
);

// ─── StatusBar ─────────────────────────────────────────────────
const StatusBar = () => (
  <Box x={0} y={0} w={390} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
    <Txt x={20} y={14} size={11} weight={600}>9:41</Txt>
    <div style={{position:'absolute',right:16,top:14,display:'flex',gap:6,alignItems:'center'}}>
      <div style={{width:12,height:8,border:`1px solid ${WC.black}`,borderRadius:2,position:'relative'}}>
        <div style={{position:'absolute',left:1,top:1,width:8,height:6,background:WC.black,borderRadius:1}}/>
      </div>
    </div>
  </Box>
);

// ─── BottomBar ──────────────────────────────────────────────────
const BottomBar = ({tabs=['Home','Rooms','Settings'],active=0}) => (
  <Box x={0} y={788} w={390} h={56} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
    {tabs.map((t,i)=>(
      <div key={i} style={{
        flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        position:'absolute', left: (390/tabs.length)*i, width:390/tabs.length, top:0, height:56,
      }}>
        <Circle x={(390/tabs.length)*i + (390/tabs.length)/2 - 12} y={8} size={24} fill={i===active?WC.g3:WC.g2} stroke={i===active?WC.g4:WC.g3}/>
        <div style={{position:'absolute',bottom:6,fontSize:9,color:i===active?WC.black:WC.g4,fontWeight:i===active?600:400}}>{t}</div>
      </div>
    ))}
  </Box>
);

// ─── PhoneFrame ────────────────────────────────────────────────
const PhoneFrame = ({children, style={}}) => (
  <div style={{
    width:390, height:844,
    border:`2.5px solid ${WC.black}`,
    borderRadius:44, overflow:'hidden',
    background:'#fff', position:'relative',
    flexShrink:0, ...style
  }}>
    {children}
  </div>
);

// ─── Annotation ────────────────────────────────────────────────
const Annotation = ({notes=[], rtl=false}) => (
  <div style={{
    width:190, paddingLeft:rtl?0:16, paddingRight:rtl?16:0,
    display:'flex', flexDirection:'column', gap:8, paddingTop:8
  }}>
    {notes.map((n,i)=>(
      <div key={i} style={{
        background:WC.g1, border:`1px solid ${WC.g2}`,
        borderRadius:6, padding:'6px 8px',
        fontSize:9, color:WC.g5, lineHeight:1.5,
      }}>
        <span style={{fontWeight:600,color:WC.black,display:'block',marginBottom:2}}>{n.title||''}</span>
        {n.body}
      </div>
    ))}
  </div>
);

// ─── WireScreen container ──────────────────────────────────────
// Wraps phone + annotations in a flex row
const WireScreen = ({number='', title='', annotations=[], rtl=false, children}) => (
  <div style={{display:'flex', flexDirection:'row', gap:0, alignItems:'flex-start', fontFamily:'system-ui,sans-serif'}}>
    {rtl && <Annotation notes={annotations} rtl={true}/>}
    <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:0}}>
      <div style={{
        width:390, background:WC.g5,
        color:'#fff', fontSize:10, fontWeight:600,
        padding:'4px 12px', display:'flex', justifyContent:'space-between'
      }}>
        <span>{number}</span>
        <span style={{fontWeight:400}}>{title}</span>
        {rtl && <span style={{fontSize:9,background:'#888',padding:'1px 6px',borderRadius:10}}>RTL ⇄</span>}
      </div>
      <PhoneFrame>{children}</PhoneFrame>
    </div>
    {!rtl && <Annotation notes={annotations}/>}
  </div>
);

// ─── ParticipantOrb ────────────────────────────────────────────
const ParticipantOrb = ({x=0,y=0,name='User',state='muted',size=52}) => {
  const rings = state==='speaking';
  const dim   = state==='disconnected';
  return (
    <div style={{position:'absolute',left:x,top:y,display:'flex',flexDirection:'column',alignItems:'center',gap:3}}>
      {rings && (
        <div style={{
          position:'absolute', top:-6, left:-6,
          width:size+12, height:size+12, borderRadius:'50%',
          border:`2px dashed ${WC.g3}`, animation:'pulse 0.8s infinite'
        }}/>
      )}
      <div style={{
        width:size, height:size, borderRadius:'50%',
        background:dim?WC.g2:WC.g3,
        border:`2px solid ${dim?WC.g3:WC.g4}`,
        display:'flex', alignItems:'center', justifyContent:'center',
        opacity:dim?0.45:1, fontSize:11, color:WC.g5,
        position:'relative'
      }}>
        {state==='muted' && <span style={{fontSize:14}}>🎤̶</span>}
        {state==='speaking' && <span style={{fontSize:10,color:WC.black,fontWeight:600}}>LIVE</span>}
        {state==='disconnected' && <span style={{fontSize:12}}>⚠</span>}
      </div>
      <div style={{fontSize:9,color:WC.g5,maxWidth:52,textAlign:'center',lineHeight:1.2}}>{name}</div>
    </div>
  );
};

// ─── ParticipantsRow ────────────────────────────────────────────
const ParticipantsRow = ({y=96, participants=[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}) => (
  <Box x={0} y={y} w={390} h={72} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',display:'flex',flexDirection:'row',gap:0,justifyContent:'center',alignItems:'center'}}>
    {participants.map((p,i)=>(
      <div key={i} style={{display:'flex',flexDirection:'column',alignItems:'center',width:80,gap:2}}>
        <Circle x={0} y={0} size={36} fill={p.state==='speaking'?WC.g3:WC.g2} stroke={p.state==='speaking'?WC.g4:WC.g3}
          style={{position:'relative',left:0,top:0}}>
          {p.state==='speaking'&&<span style={{fontSize:8,fontWeight:600}}>LIVE</span>}
          {p.state==='muted'&&<span style={{fontSize:10}}>✕</span>}
        </Circle>
        <div style={{fontSize:9,color:WC.g5}}>{p.name}</div>
      </div>
    ))}
  </Box>
);

// ─── Export to window ───────────────────────────────────────────
Object.assign(window, {
  WC, Box, Circle, Txt, Btn, Input, Divider, Tag,
  TopBar, StatusBar, BottomBar, PhoneFrame,
  Annotation, WireScreen, ParticipantOrb, ParticipantsRow
});
