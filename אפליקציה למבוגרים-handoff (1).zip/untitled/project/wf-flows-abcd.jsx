
// Senior Brains Wireframes — Flows A, B, C, D
// Requires wf-primitives.jsx loaded first

// ═══════════════════════════════════════════
// FLOW A: FIRST-TIME USER (8 screens)
// ═══════════════════════════════════════════

const ScreenA1 = () => (
  <WireScreen number="A1" title="Splash / Launch" annotations={[
    {title:'Adaptive', body:'Logo scales 1.25× in Larger & Calmer mode. Animation reduced if iOS Reduce Motion on.'},
    {title:'Behavior', body:'Auto-advances to A2 after 2.5s, or on tap.'},
    {title:'Platform', body:'Native splash screen on iOS (LaunchScreen.storyboard). This view shown briefly on top.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none">
      <Box x={145} y={280} w={100} h={100} r={20} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={38} size={10} color={WC.g5}>LOGO</Txt>
      </Box>
      <Txt x={130} y={400} size={18} weight={700} color={WC.black}>Senior Brains</Txt>
      <Txt x={155} y={428} size={11} color={WC.g4}>Connect & Play</Txt>
      <Txt x={165} y={740} size={9} color={WC.g4}>v1.0.0</Txt>
      {/* animated ring hint */}
      <div style={{position:'absolute',left:133,top:267,width:124,height:124,borderRadius:'50%',border:`1.5px dashed ${WC.g3}`}}/>
      <Txt x={110} y={460} size={9} color={WC.g4} style={{position:'absolute'}}>⟳ Animated logo pulse — 2s loop</Txt>
    </Box>
  </WireScreen>
);

const ScreenA2 = () => (
  <WireScreen number="A2" title="Welcome + Language Picker" annotations={[
    {title:'Languages', body:'EN / HE (RTL) / RU. Selection sets app locale immediately. Persisted to device storage.'},
    {title:'RTL', body:'Selecting Hebrew flips all layouts to RTL before next screen loads.'},
    {title:'Adaptive', body:'Language cards: 56px tall in Larger & Calmer (vs 44px). Text 20px vs 16px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={145} y={70} w={100} h={70} r={16} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={28} size={9} color={WC.g5}>LOGO</Txt>
      </Box>
      <Txt x={80} y={160} size={20} weight={700} color={WC.black} w={230} style={{textAlign:'center',position:'absolute'}}>Welcome to Senior Brains</Txt>
      <Txt x={60} y={194} size={11} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>Connect with family across any distance. Choose your language to get started.</Txt>

      <Txt x={30} y={244} size={10} weight={600} color={WC.g5}>SELECT YOUR LANGUAGE</Txt>
      {[['English','EN',264],['עברית (Hebrew)','HE',316],['Русский (Russian)','RU',368]].map(([label,code,y])=>(
        <Box key={code} x={30} y={y} w={330} h={44} r={10} fill={WC.g1} stroke={WC.g3} dash={true}>
          <Txt x={16} y={14} size={12}>{label}</Txt>
          <Tag x={270} y={12} label={code} fill={WC.g2}/>
        </Box>
      ))}

      <Btn x={30} y={450} w={330} h={48} label="Continue →" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Txt x={80} y={510} size={9} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>You can change this at any time in Settings</Txt>
    </Box>
  </WireScreen>
);

const ScreenA3 = () => (
  <WireScreen number="A3" title="Name Input" annotations={[
    {title:'Validation', body:'Min 2 chars, max 20. Emoji allowed. Auto-capitalised.'},
    {title:'Keyboard', body:'Soft keyboard appears immediately (autofocus). Screen scrolls up.'},
    {title:'Adaptive', body:'Input height 44→56px. Font 16→20px.'},
  ]}>
    <StatusBar/>
    <TopBar title="About You" back={false}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none">
      <Txt x={30} y={40} size={18} weight={700} color={WC.black} w={330} style={{textAlign:'center',position:'absolute'}}>What's your name?</Txt>
      <Txt x={30} y={70} size={11} color={WC.g4} w={330} style={{textAlign:'center',position:'absolute'}}>This is what other players will see.</Txt>
      <Input x={30} y={110} w={330} h={48} placeholder="Your name…"/>
      <Txt x={30} y={168} size={9} color={WC.g4}>Others in your room will see this name</Txt>
      <Btn x={30} y={220} w={330} h={48} label="Next →" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>

      {/* Progress dots */}
      <div style={{position:'absolute',left:165,top:680,display:'flex',gap:6}}>
        {[0,1,2,3,4].map(i=>(
          <div key={i} style={{width:i===1?20:8,height:8,borderRadius:4,background:i===1?WC.g5:WC.g3}}/>
        ))}
      </div>
    </Box>
  </WireScreen>
);

const ScreenA4 = () => (
  <WireScreen number="A4" title="UI Mode Choice" annotations={[
    {title:'Modes', body:'Standard (default) vs Larger & Calmer. Never called "Senior mode".'},
    {title:'Preview', body:'Each card shows a mini mock of the app in that mode (static illustration).'},
    {title:'Adaptive', body:'The preview cards themselves DO NOT change — only the actual UI after selection does.'},
    {title:'Persist', body:'Stored to AsyncStorage. Can be changed anytime in Settings → Display.'},
  ]}>
    <StatusBar/>
    <TopBar title="Display Mode" back={true}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none">
      <Txt x={30} y={30} size={17} weight={700} color={WC.black} w={330} style={{textAlign:'center',position:'absolute'}}>How do you like your display?</Txt>
      <Txt x={50} y={58} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>You can change this any time.</Txt>

      {/* Standard card */}
      <Box x={20} y={100} w={165} h={240} r={14} fill={WC.g1} stroke={WC.g3} dash={true}>
        <Txt x={12} y={12} size={11} weight={600}>Standard</Txt>
        {/* mini mock */}
        <Box x={12} y={32} w={141} h={90} r={6} fill={WC.g2} stroke={WC.g3}><Txt x={8} y={8} size={8} color={WC.g5}>Mini app preview</Txt></Box>
        <Txt x={12} y={134} size={9} color={WC.g5}>• 16px base font</Txt>
        <Txt x={12} y={148} size={9} color={WC.g5}>• 44px tap targets</Txt>
        <Txt x={12} y={162} size={9} color={WC.g5}>• Compact spacing</Txt>
        <Txt x={12} y={176} size={9} color={WC.g5}>• Standard motion</Txt>
        <Box x={20} y={208} w={124} h={22} r={6} fill={WC.g3} stroke={WC.g4}>
          <Txt x={0} y={4} size={9} weight={600} style={{position:'static'}}>Select Standard</Txt>
        </Box>
      </Box>

      {/* Larger & Calmer card */}
      <Box x={205} y={100} w={165} h={240} r={14} fill={WC.g1} stroke={WC.g4} dash={true}>
        <Txt x={12} y={12} size={11} weight={600}>Larger & Calmer</Txt>
        <Box x={12} y={32} w={141} h={90} r={6} fill={WC.g2} stroke={WC.g3}><Txt x={8} y={8} size={8} color={WC.g5}>Mini app preview (larger text)</Txt></Box>
        <Txt x={12} y={134} size={9} color={WC.g5}>• 20px base font</Txt>
        <Txt x={12} y={148} size={9} color={WC.g5}>• 56px tap targets</Txt>
        <Txt x={12} y={162} size={9} color={WC.g5}>• Generous spacing</Txt>
        <Txt x={12} y={176} size={9} color={WC.g5}>• Slower transitions</Txt>
        <Box x={20} y={208} w={124} h={22} r={6} fill={WC.g3} stroke={WC.g4}>
          <Txt x={0} y={4} size={9} weight={600} style={{position:'static'}}>Select Larger</Txt>
        </Box>
      </Box>

      <Txt x={30} y={360} size={10} color={WC.g4} w={330} style={{textAlign:'center',position:'absolute'}}>Both modes work for everyone. Pick what feels right.</Txt>
      <div style={{position:'absolute',left:165,top:680,display:'flex',gap:6}}>
        {[0,1,2,3,4].map(i=>(
          <div key={i} style={{width:i===2?20:8,height:8,borderRadius:4,background:i===2?WC.g5:WC.g3}}/>
        ))}
      </div>
    </Box>
  </WireScreen>
);

const ScreenA5 = () => (
  <WireScreen number="A5" title="Microphone Permission" annotations={[
    {title:'iOS', body:'Native iOS permission dialog appears ON TOP of this screen after tapping Allow. This screen is the pre-prompt.'},
    {title:'Deny path', body:'If denied → goes to O2 (mic denied recovery). Can retry from Settings.'},
    {title:'Adaptive', body:'Icon 80px → 100px. Button height 44→56px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Circle x={155} y={180} size={80} fill={WC.g2} stroke={WC.g3}>
        <Txt x={24} y={28} size={22}>🎤</Txt>
      </Circle>
      <Txt x={60} y={286} size={19} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Enable your microphone</Txt>
      <Txt x={40} y={318} size={11} color={WC.g4} w={310} style={{textAlign:'center',position:'absolute'}}>Senior Brains is voice-first. You'll talk with family while playing games — no typing needed.</Txt>
      <Btn x={30} y={410} w={330} h={48} label="Allow Microphone" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Btn x={30} y={468} w={330} h={40} label="Not now" fill={WC.bg} stroke={WC.g3} textSize={11}/>
      <Txt x={50} y={524} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>You can enable this later in iOS Settings → Senior Brains</Txt>
    </Box>
  </WireScreen>
);

const ScreenA6 = () => (
  <WireScreen number="A6" title="Push Notification Permission" annotations={[
    {title:'Optional', body:'Tapping "Maybe later" skips without penalty. App fully usable without push.'},
    {title:'Use cases', body:'Notifies when family starts a room, invites you, or it\'s your turn.'},
    {title:'iOS', body:'System dialog shown on top after Allow tap.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Circle x={155} y={180} size={80} fill={WC.g2} stroke={WC.g3}>
        <Txt x={24} y={28} size={22}>🔔</Txt>
      </Circle>
      <Txt x={60} y={286} size={17} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Stay in the loop</Txt>
      <Txt x={40} y={316} size={11} color={WC.g4} w={310} style={{textAlign:'center',position:'absolute'}}>Get notified when your family starts a game, sends an invite, or it's your turn to play.</Txt>
      <Btn x={30} y={390} w={330} h={48} label="Turn on Notifications" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Btn x={30} y={448} w={330} h={40} label="Maybe later" fill={WC.bg} stroke={WC.g3} textSize={11}/>
    </Box>
  </WireScreen>
);

const ScreenA7 = () => (
  <WireScreen number="A7" title="First Choice: Join vs Start" annotations={[
    {title:'Branch', body:'Start → A8 (room setup). Join → prompts for room code or link.'},
    {title:'Solo', body:'"Play solo" option below — opens B1 Home filtered to solo activities.'},
    {title:'Deep link', body:'If user arrived via invite link, this screen is skipped entirely → C2.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={145} y={60} w={100} h={70} r={14} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={26} size={9} color={WC.g5}>LOGO</Txt>
      </Box>
      <Txt x={40} y={150} size={19} weight={700} color={WC.black} w={310} style={{textAlign:'center',position:'absolute'}}>Ready to play?</Txt>
      <Txt x={50} y={180} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Start a room and invite family, or join one they've already set up.</Txt>

      {/* Start card */}
      <Box x={20} y={230} w={350} h={100} r={14} fill={WC.g1} stroke={WC.g3} dash={true}>
        <Circle x={16} y={28} size={44} fill={WC.g2} stroke={WC.g3}><Txt x={14} y={14} size={16}>★</Txt></Circle>
        <Txt x={76} y={20} size={13} weight={600}>Start a Room</Txt>
        <Txt x={76} y={40} size={10} color={WC.g4} w={240}>You choose the name, wallpaper, and invite people. You'll be the Host.</Txt>
      </Box>

      {/* Join card */}
      <Box x={20} y={344} w={350} h={100} r={14} fill={WC.g1} stroke={WC.g3} dash={true}>
        <Circle x={16} y={28} size={44} fill={WC.g2} stroke={WC.g3}><Txt x={14} y={14} size={16}>→</Txt></Circle>
        <Txt x={76} y={20} size={13} weight={600}>Join a Room</Txt>
        <Txt x={76} y={40} size={10} color={WC.g4} w={240}>Enter a code or tap a link someone sent you.</Txt>
      </Box>

      <Divider x={20} y={460} w={350}/>
      <Btn x={20} y={474} w={350} h={40} label="Play solo for now" fill={WC.bg} stroke={WC.g3} textSize={11}/>
    </Box>
  </WireScreen>
);

const ScreenA8 = () => (
  <WireScreen number="A8" title="Room Setup (Host)" annotations={[
    {title:'Wallpaper', body:'Grid of 8 preset patterns (grayscale tiles). Custom upload in v2.'},
    {title:'Language', body:'Default room language for shared UI elements. Each user can still set own language.'},
    {title:'Host badge', body:'Host sees crown icon in room permanently. Host controls Wheel of Fortune spin.'},
    {title:'Adaptive', body:'All inputs 44→56px tall. Labels 16→20px.'},
  ]}>
    <StatusBar/>
    <TopBar title="Create a Room" back={true}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Txt x={30} y={16} size={11} weight={600} color={WC.g5}>ROOM NAME</Txt>
      <Input x={30} y={34} w={330} h={44} placeholder="e.g. Family Game Night"/>

      <Txt x={30} y={94} size={11} weight={600} color={WC.g5}>ROOM WALLPAPER</Txt>
      <div style={{position:'absolute',left:30,top:112,display:'flex',gap:8,flexWrap:'wrap',width:330}}>
        {[0,1,2,3,4,5,6,7].map(i=>(
          <Box key={i} x={0} y={0} w={72} h={72} r={10} fill={i===0?WC.g3:WC.g1} stroke={i===0?WC.g4:WC.g3} style={{position:'relative'}}>
            <Txt x={6} y={28} size={8} color={WC.g5}>Pattern {i+1}</Txt>
          </Box>
        ))}
      </div>

      <Txt x={30} y={298} size={11} weight={600} color={WC.g5}>DEFAULT LANGUAGE</Txt>
      {['English','עברית','Русский'].map((lang,i)=>(
        <Box key={i} x={30} y={316+i*50} w={330} h={44} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3}>
          <Txt x={16} y={14} size={12}>{lang}</Txt>
          {i===0 && <Tag x={270} y={12} label="Selected" fill={WC.g3}/>}
        </Box>
      ))}

      <Btn x={30} y={488} w={330} h={48} label="Create Room & Invite People" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW B: RETURNING USER (3 screens)
// ═══════════════════════════════════════════

const ScreenB1 = () => (
  <WireScreen number="B1" title="Home / Dashboard" annotations={[
    {title:'Recent rooms', body:'Shows last 3 rooms joined. Tap to re-join if still active, else shows summary.'},
    {title:'Quick start', body:'"Start New Room" CTA is always visible above fold.'},
    {title:'Solo', body:'Solo activities section below — Sudoku, Crossword without multiplayer.'},
    {title:'Syncs', body:'Room status badges ("2 in room", "Active") sync via Supabase Realtime.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 20px'}}>
      <Txt x={20} y={16} size={14} weight={700}>Senior Brains</Txt>
      <Circle x={330} y={10} size={32} fill={WC.g2} stroke={WC.g3}><Txt x={8} y={8} size={14}>👤</Txt></Circle>
    </Box>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Btn x={20} y={16} w={350} h={52} label="+ Start New Room" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>

      <Txt x={20} y={84} size={10} weight={600} color={WC.g5}>RECENT ROOMS</Txt>
      {[['Family Game Night','2 in room','Active'],['Sunday Trivia','—','Ended'],['Crossword Crew','—','Ended']].map(([name,status,state],i)=>(
        <Box key={i} x={20} y={100+i*68} w={350} h={60} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Circle x={12} y={12} size={36} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={60} y={10} size={12} weight={600}>{name}</Txt>
          <Txt x={60} y={28} size={10} color={WC.g4}>{status} · {state}</Txt>
          <Btn x={264} y={18} w={72} h={26} label={state==='Active'?'Rejoin':'View'} fill={WC.g3} stroke={WC.g4} textSize={9}/>
        </Box>
      ))}

      <Txt x={20} y={310} size={10} weight={600} color={WC.g5}>SOLO ACTIVITIES</Txt>
      <div style={{position:'absolute',left:20,top:328,display:'flex',gap:10}}>
        {['Crossword','Sudoku'].map(g=>(
          <Box key={g} x={0} y={0} w={158} h={80} r={12} fill={WC.g1} stroke={WC.g2} dash={true} style={{position:'relative'}}>
            <Txt x={12} y={12} size={12} weight={600}>{g}</Txt>
            <Txt x={12} y={32} size={9} color={WC.g4}>Play solo</Txt>
          </Box>
        ))}
      </div>
    </Box>
    <BottomBar tabs={['Home','Rooms','Settings']} active={0}/>
  </WireScreen>
);

const ScreenB2 = () => (
  <WireScreen number="B2" title="Home — Empty State" annotations={[
    {title:'Empty state', body:'Shown for brand-new users with no room history. Friendly illustration placeholder.'},
    {title:'CTA', body:'Single strong CTA: Start your first room. No clutter.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={20} y={16} size={14} weight={700}>Senior Brains</Txt>
    </Box>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      {/* Illustration placeholder */}
      <Box x={95} y={120} w={200} h={150} r={16} fill={WC.g1} stroke={WC.g3} style={{borderStyle:'dashed'}}>
        <Txt x={40} y={62} size={10} color={WC.g4}>[ Illustration ]</Txt>
      </Box>
      <Txt x={40} y={296} size={18} weight={700} color={WC.black} w={310} style={{textAlign:'center',position:'absolute'}}>No rooms yet</Txt>
      <Txt x={50} y={326} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Start a room and invite family to play together. It only takes 30 seconds.</Txt>
      <Btn x={30} y={390} w={330} h={52} label="Start Your First Room" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={452} w={330} h={44} label="Join with a code or link" fill={WC.bg} stroke={WC.g3} textSize={12}/>
    </Box>
    <BottomBar tabs={['Home','Rooms','Settings']} active={0}/>
  </WireScreen>
);

const ScreenB3 = () => (
  <WireScreen number="B3" title="Home — Offline State" annotations={[
    {title:'Detection', body:'Network state monitored via NetInfo. Banner appears within ~1s of disconnection.'},
    {title:'Degraded', body:'Solo activities remain accessible (cached puzzles). Room features disabled.'},
    {title:'Auto-retry', body:'Banner auto-dismisses when connection restores.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={20} y={16} size={14} weight={700}>Senior Brains</Txt>
    </Box>
    {/* Offline banner */}
    <Box x={0} y={96} w={390} h={40} r={0} fill={WC.g3} stroke={WC.g4} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={20} y={12} size={10} weight={600} color={WC.black}>⚠ No internet connection — rooms unavailable</Txt>
    </Box>
    <Box x={0} y={136} w={390} h={652} r={0} fill={WC.bg} stroke="none" style={{opacity:0.5}}>
      <Btn x={20} y={16} w={350} h={52} label="+ Start New Room" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Txt x={95} y={80} size={10} color={WC.g4} w={200} style={{textAlign:'center',position:'absolute'}}>Rooms unavailable while offline</Txt>
      <Txt x={20} y={120} size={10} weight={600} color={WC.g5}>SOLO ACTIVITIES (available offline)</Txt>
      <Box x={20} y={140} w={350} h={60} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
        <Txt x={16} y={20} size={12} weight={600}>Crossword — Daily</Txt>
        <Txt x={16} y={38} size={9} color={WC.g4}>Cached · Play solo</Txt>
      </Box>
    </Box>
    <BottomBar tabs={['Home','Rooms','Settings']} active={0}/>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW C: JOINING VIA INVITE (3 screens)
// ═══════════════════════════════════════════

const ScreenC1 = () => (
  <WireScreen number="C1" title="Invite Landing (Web)" annotations={[
    {title:'URL', body:'seniorbrains.app/join/[code] — mobile web view, or deep link opens app directly.'},
    {title:'Participants', body:'Shows who is already waiting. Updates in real-time.'},
    {title:'CTA', body:'"Open in App" → app deep link. "Download App" → App Store if not installed.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none">
      {/* Browser chrome hint */}
      <Box x={0} y={0} w={390} h={36} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:'0'}}>
        <Txt x={50} y={10} size={10} color={WC.g5}>seniorbrains.app/join/ABC123</Txt>
      </Box>
      <Box x={30} y={56} w={330} h={360} r={16} fill={WC.bg} stroke={WC.g2}>
        <Box x={115} y={16} w={100} h={70} r={12} fill={WC.g2} stroke={WC.g3}><Txt x={28} y={26} size={9} color={WC.g5}>LOGO</Txt></Box>
        <Txt x={30} y={100} size={16} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Family Game Night</Txt>
        <Txt x={40} y={124} size={11} color={WC.g4} w={250} style={{textAlign:'center',position:'absolute'}}>Mom invited you to join a room</Txt>
        <Txt x={40} y={154} size={10} weight={600} color={WC.g5} style={{position:'absolute'}}>WAITING IN ROOM</Txt>
        <div style={{position:'absolute',left:40,top:174,display:'flex',gap:12}}>
          {['Mom','Dad'].map(n=>(
            <div key={n} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
              <div style={{width:40,height:40,borderRadius:'50%',background:WC.g2,border:`1.5px solid ${WC.g3}`}}/>
              <div style={{fontSize:9,color:WC.g5}}>{n}</div>
            </div>
          ))}
        </div>
        <Btn x={20} y={268} w={290} h={48} label="Open in Senior Brains App" fill={WC.g2} stroke={WC.g3} bold={true} textSize={12}/>
        <Btn x={20} y={322} w={290} h={32} label="Download the app" fill={WC.bg} stroke={WC.g3} textSize={10}/>
      </Box>
    </Box>
  </WireScreen>
);

const ScreenC2 = () => (
  <WireScreen number="C2" title="Quick Onboarding (via Invite)" annotations={[
    {title:'Abbreviated', body:'Only asks name + mic permission (skips language/mode — uses defaults). 2 steps max.'},
    {title:'Context', body:'Shows room name + inviter at top so user knows why they\'re here.'},
    {title:'Returning users', body:'If app detects existing account, skips onboarding entirely → C3.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={64} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={20} y={10} size={10} color={WC.g4}>Joining:</Txt>
        <Txt x={20} y={26} size={13} weight={600} color={WC.black}>Family Game Night · invited by Mom</Txt>
      </Box>
      <Txt x={40} y={90} size={18} weight={700} color={WC.black} w={310} style={{textAlign:'center',position:'absolute'}}>Quick setup — 30 seconds</Txt>
      <Txt x={50} y={120} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Enter your name so Mom knows it's you.</Txt>
      <Input x={30} y={168} w={330} h={48} placeholder="Your name…"/>
      <Btn x={30} y={234} w={330} h={48} label="Join the Room →" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Txt x={50} y={300} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Microphone permission will be requested next</Txt>
    </Box>
  </WireScreen>
);

const ScreenC3 = () => (
  <WireScreen number="C3" title="Loading → Room" annotations={[
    {title:'Transition', body:'Supabase channel joined, voice channel initialised. Typically 1-3s.'},
    {title:'Timeout', body:'If >10s → shows error with retry. Network issue → O1 banner.'},
    {title:'Animation', body:'Pulsing logo + "Connecting…" text. Reduced motion: static logo + spinner only.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none">
      <Box x={145} y={280} w={100} h={100} r={20} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={38} size={10} color={WC.g5}>LOGO</Txt>
      </Box>
      {/* Pulsing ring */}
      <div style={{position:'absolute',left:129,top:264,width:132,height:132,borderRadius:'50%',border:`1.5px dashed ${WC.g3}`}}/>
      <Txt x={100} y={408} size={14} weight={600} color={WC.black} w={190} style={{textAlign:'center',position:'absolute'}}>Joining Family Game Night…</Txt>
      <Txt x={120} y={432} size={10} color={WC.g4} w={150} style={{textAlign:'center',position:'absolute'}}>Connecting voice · Setting up room</Txt>
      {/* Spinner */}
      <Box x={180} y={470} w={30} h={30} r={15} fill="none" stroke={WC.g4} style={{borderTopColor:WC.black,animation:'spin 1s linear infinite'}}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW D: ROOM LOBBY (4 screens)
// ═══════════════════════════════════════════

const ScreenD1 = () => (
  <WireScreen number="D1" title="Lobby — Solo Waiting" annotations={[
    {title:'Solo state', body:'Only host present. Invite sheet prominent. Wheel of Fortune greyed out until 2+ players.'},
    {title:'Host indicator', body:'Crown icon next to host\'s name. Persists through entire session.'},
    {title:'Voice', body:'Mic button visible but shows "waiting for others" tooltip on tap.'},
    {title:'Real-time', body:'Participant list updates live via Supabase Realtime when others join.'},
  ]}>
    <StatusBar/>
    <TopBar title="Family Game Night" back={false} action="⚙"/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      {/* Wallpaper hint */}
      <Box x={0} y={0} w={390} h={120} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={140} y={50} size={10} color={WC.g4}>Room wallpaper preview</Txt>
      </Box>
      {/* Participant orb — just you */}
      <Txt x={80} y={140} size={11} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>Waiting for others to join…</Txt>
      <Circle x={170} y={164} size={60} fill={WC.g2} stroke={WC.g3}>
        <Txt x={12} y={20} size={10} weight={600}>You 👑</Txt>
      </Circle>
      {/* Add player ghost slots */}
      {[1,2,3].map(i=>(
        <Circle key={i} x={70+i*80} y={248} size={44} fill="none" stroke={WC.g3} dash={true}>
          <Txt x={11} y={13} size={18} color={WC.g3}>+</Txt>
        </Circle>
      ))}
      <Txt x={80} y={302} size={9} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>2–4 players (invite more below)</Txt>
      <Btn x={30} y={330} w={330} h={52} label="Invite People" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={392} w={330} h={44} label="🎡  Spin Wheel of Fortune" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Txt x={60} y={446} size={9} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>Wheel disabled until at least 2 players join</Txt>
    </Box>
    <BottomBar tabs={['🎤 Mute','Invite','Leave']} active={-1}/>
  </WireScreen>
);

const ScreenD2 = () => (
  <WireScreen number="D2" title="Lobby — 3 Participants" annotations={[
    {title:'Voice rings', body:'Speaking participant orb shows pulsing dashed ring (800ms loop, 1.2× scale). Annotated: "live" label.'},
    {title:'Host controls', body:'Host sees active Spin button. Others see "Waiting for [Host] to spin."'},
    {title:'Real-time', body:'All participant states sync via Supabase Realtime at ~60ms.'},
    {title:'Tablet', body:'On iPad, orbs arranged in 2×2 grid. Chat sidebar appears.'},
  ]}>
    <StatusBar/>
    <TopBar title="Family Game Night" back={false} action="⚙"/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={80} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={140} y={34} size={10} color={WC.g4}>Room wallpaper</Txt>
      </Box>
      {/* 3 Participant orbs */}
      {[
        {name:'You 👑',state:'speaking',x:60,y:90},
        {name:'Mom',state:'muted',x:170,y:90},
        {name:'Jake',state:'muted',x:280,y:90},
      ].map(p=>(
        <div key={p.name} style={{position:'absolute',left:p.x,top:p.y,display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
          {p.state==='speaking' && (
            <div style={{position:'absolute',top:-8,left:-8,width:76,height:76,borderRadius:'50%',border:`2px dashed ${WC.g3}`}}/>
          )}
          <Circle x={0} y={0} size={60} fill={p.state==='speaking'?WC.g3:WC.g2} stroke={p.state==='speaking'?WC.g4:WC.g3} style={{position:'relative'}}>
            {p.state==='speaking'&&<Txt x={10} y={22} size={8} weight={600}>LIVE</Txt>}
            {p.state==='muted'&&<Txt x={18} y={20} size={14}>✕</Txt>}
          </Circle>
          <div style={{fontSize:9,color:WC.g5,marginTop:4,textAlign:'center'}}>{p.name}</div>
        </div>
      ))}
      <Txt x={50} y={200} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>⟳ Pulsing ring = speaking  ·  ✕ = muted  (synced live)</Txt>
      <Btn x={30} y={228} w={330} h={52} label="🎡  Spin Wheel of Fortune" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Txt x={50} y={288} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Host-only: others see "Waiting for You to spin…"</Txt>
      <Btn x={30} y={312} w={330} h={44} label="+ Invite More People" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Divider x={30} y={368} w={330}/>
      <Btn x={30} y={380} w={330} h={44} label="Browse All Activities" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
    <BottomBar tabs={['🎤 Mute','Invite','Leave']} active={-1}/>
  </WireScreen>
);

const ScreenD3 = () => (
  <WireScreen number="D3" title="Share Invite — Bottom Sheet" annotations={[
    {title:'Bottom sheet', body:'Slides up from bottom on tap of Invite. Dismissable via swipe-down or backdrop tap.'},
    {title:'QR code', body:'Generated locally from room code. Scannable by any camera app.'},
    {title:'Share options', body:'Native Share Sheet also accessible via "More…" option.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none" style={{opacity:0.4}}>
      <Txt x={140} y={380} size={12} color={WC.g4}>Room behind sheet</Txt>
    </Box>
    {/* Bottom sheet */}
    <Box x={0} y={320} w={390} h={524} r={0} fill={WC.bg} stroke={WC.g2} style={{borderTopLeftRadius:20,borderTopRightRadius:20,borderBottom:'none',borderLeft:'none',borderRight:'none',boxShadow:'0 -4px 16px rgba(0,0,0,0.08)'}}>
      <div style={{position:'absolute',top:8,left:175,width:40,height:4,borderRadius:2,background:WC.g3}}/>
      <Txt x={120} y={28} size={14} weight={700}>Invite to Room</Txt>
      {/* Room code */}
      <Box x={30} y={60} w={330} h={60} r={12} fill={WC.g1} stroke={WC.g2}>
        <Txt x={80} y={8} size={11} color={WC.g4}>Room code</Txt>
        <Txt x={100} y={26} size={22} weight={700} color={WC.black}>ABC 123</Txt>
      </Box>
      {/* Share targets */}
      {[['WhatsApp','share via WhatsApp'],['SMS','send text message'],['Copy Link','copy to clipboard']].map(([label,desc],i)=>(
        <Box key={i} x={30} y={136+i*58} w={330} h={50} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Circle x={12} y={7} size={36} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={60} y={10} size={12} weight={600}>{label}</Txt>
          <Txt x={60} y={28} size={9} color={WC.g4}>{desc}</Txt>
        </Box>
      ))}
      {/* QR code placeholder */}
      <Box x={130} y={316} w={130} h={130} r={8} fill={WC.g1} stroke={WC.g3}>
        <Txt x={22} y={56} size={9} color={WC.g4}>QR Code</Txt>
      </Box>
      <Txt x={140} y={454} size={9} color={WC.g4} w={110} style={{textAlign:'center',position:'absolute'}}>Scan to join</Txt>
    </Box>
  </WireScreen>
);

const ScreenD4 = () => (
  <WireScreen number="D4" title="Lobby Settings Menu" annotations={[
    {title:'Host only', body:'Room name, wallpaper, and kick controls only visible to Host.'},
    {title:'All users', body:'Mic settings, display mode, and leave room available to all.'},
    {title:'Bottom sheet', body:'Slides up from ⚙ icon in TopBar.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none" style={{opacity:0.4}}>
      <Txt x={140} y={380} size={12} color={WC.g4}>Lobby behind sheet</Txt>
    </Box>
    <Box x={0} y={260} w={390} h={584} r={0} fill={WC.bg} stroke={WC.g2} style={{borderTopLeftRadius:20,borderTopRightRadius:20,borderBottom:'none',borderLeft:'none',borderRight:'none'}}>
      <div style={{position:'absolute',top:8,left:175,width:40,height:4,borderRadius:2,background:WC.g3}}/>
      <Txt x={140} y={28} size={14} weight={700}>Room Settings</Txt>
      <Txt x={30} y={60} size={10} weight={600} color={WC.g5}>HOST CONTROLS</Txt>
      {['Edit Room Name','Change Wallpaper','Remove a Participant'].map((item,i)=>(
        <Box key={i} x={30} y={78+i*52} w={330} h={44} r={10} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Txt x={14} y={13} size={12}>{item}</Txt>
          <Txt x={300} y={13} size={12} color={WC.g4}>›</Txt>
        </Box>
      ))}
      <Txt x={30} y={236} size={10} weight={600} color={WC.g5}>YOUR SETTINGS</Txt>
      {['Microphone & Audio','Display Mode','Notifications'].map((item,i)=>(
        <Box key={i} x={30} y={254+i*52} w={330} h={44} r={10} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Txt x={14} y={13} size={12}>{item}</Txt>
          <Txt x={300} y={13} size={12} color={WC.g4}>›</Txt>
        </Box>
      ))}
      <Btn x={30} y={428} w={330} h={44} label="Leave Room" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// RTL VARIANTS — 5 key screens
// ═══════════════════════════════════════════

const ScreenA1_RTL = () => (
  <WireScreen number="A1-RTL" title="Splash — Hebrew (RTL)" rtl={true} annotations={[
    {title:'RTL ⇄', body:'All horizontal layouts mirrored. Logo centred — no change. Text right-aligned.'},
    {title:'Note', body:'Locale set to Hebrew before this screen renders, so OS-level RTL is active.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.g1} stroke="none">
      <Box x={145} y={280} w={100} h={100} r={20} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={38} size={10} color={WC.g5}>לוגו</Txt>
      </Box>
      <Txt x={110} y={400} size={18} weight={700} color={WC.black}>סניור ברינס</Txt>
      <Txt x={130} y={428} size={11} color={WC.g4}>התחבר ושחק</Txt>
      <div style={{position:'absolute',left:133,top:267,width:124,height:124,borderRadius:'50%',border:`1.5px dashed ${WC.g3}`}}/>
    </Box>
  </WireScreen>
);

const ScreenB1_RTL = () => (
  <WireScreen number="B1-RTL" title="Home — Hebrew (RTL)" rtl={true} annotations={[
    {title:'RTL ⇄', body:'Back arrows point right. Layout mirrors. Text right-aligned. Tab icons same, labels mirrored.'},
    {title:'Hebrew', body:'All strings translated. Room name displayed in Hebrew.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Circle x={28} y={10} size={32} fill={WC.g2} stroke={WC.g3}/>
      <Txt x={200} y={16} size={14} weight={700} style={{direction:'rtl',width:160,textAlign:'right',position:'absolute',right:20}}>סניור ברינס</Txt>
    </Box>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none" style={{direction:'rtl'}}>
      <Btn x={20} y={16} w={350} h={52} label="+ הקם חדר חדש" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Txt x={20} y={84} size={10} weight={600} color={WC.g5} style={{position:'absolute',right:20}}>חדרים אחרונים</Txt>
      {['ליל משחקי משפחה','טריוויה של יום ראשון'].map((name,i)=>(
        <Box key={i} x={20} y={100+i*68} w={350} h={60} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Circle x={298} y={12} size={36} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={14} y={10} size={11} weight={600} style={{direction:'rtl',position:'absolute',right:66,left:'auto'}}>{name}</Txt>
        </Box>
      ))}
    </Box>
    <BottomBar tabs={['בית','חדרים','הגדרות']} active={0}/>
  </WireScreen>
);

const ScreenD2_RTL = () => (
  <WireScreen number="D2-RTL" title="Lobby — Hebrew (RTL)" rtl={true} annotations={[
    {title:'RTL ⇄', body:'TopBar back arrow → right. Participant orbs same positions (centred, no change). Buttons text RTL.'},
    {title:'Host label', body:'Crown still appears, label in Hebrew.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={180} y={16} size={13} weight={600} style={{position:'absolute',right:0,left:0,textAlign:'center',direction:'rtl'}}>ליל משחקי משפחה</Txt>
      <Txt x={344} y={18} size={12}>⚙</Txt>
    </Box>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none" style={{direction:'rtl'}}>
      <Box x={0} y={0} w={390} h={80} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}/>
      {[{name:'את 👑',x:60,y:90,sp:true},{name:'אמא',x:170,y:90},{name:'יעקב',x:280,y:90}].map(p=>(
        <div key={p.name} style={{position:'absolute',left:p.x,top:p.y,display:'flex',flexDirection:'column',alignItems:'center',gap:4}}>
          {p.sp&&<div style={{position:'absolute',top:-8,left:-8,width:76,height:76,borderRadius:'50%',border:`2px dashed ${WC.g3}`}}/>}
          <Circle x={0} y={0} size={60} fill={p.sp?WC.g3:WC.g2} stroke={p.sp?WC.g4:WC.g3} style={{position:'relative'}}>
            {p.sp&&<Txt x={8} y={22} size={8} weight={600}>שידור</Txt>}
          </Circle>
          <div style={{fontSize:9,color:WC.g5,marginTop:4}}>{p.name}</div>
        </div>
      ))}
      <Btn x={30} y={228} w={330} h={52} label="🎡  סובב גלגל המזל" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={290} w={330} h={44} label="+ הזמן עוד אנשים" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const FlowABCD = () => (
  <div style={{display:'flex',flexDirection:'column',gap:40}}>
    {/* Flow A */}
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW A — FIRST-TIME USER ONBOARDING</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ScreenA1/><ScreenA2/><ScreenA3/><ScreenA4/>
      </div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,marginTop:24}}>
        <ScreenA5/><ScreenA6/><ScreenA7/><ScreenA8/>
      </div>
    </div>
    {/* Flow B */}
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW B — RETURNING USER / HOME</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ScreenB1/><ScreenB2/><ScreenB3/>
      </div>
    </div>
    {/* Flow C */}
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW C — JOINING VIA INVITE</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ScreenC1/><ScreenC2/><ScreenC3/>
      </div>
    </div>
    {/* Flow D */}
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW D — ROOM LOBBY</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ScreenD1/><ScreenD2/><ScreenD3/><ScreenD4/>
      </div>
    </div>
    {/* RTL variants */}
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>RTL VARIANTS — Hebrew (5 screens shown here + Scrabble in Flow G)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}>
        <ScreenA1_RTL/><ScreenB1_RTL/><ScreenD2_RTL/>
      </div>
    </div>
  </div>
);

Object.assign(window, {FlowABCD});
