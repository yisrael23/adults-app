
// Senior Brains Wireframes — Flows I, J, K, L
// Requires wf-primitives.jsx loaded first

// ═══════════════════════════════════════════
// FLOW I: JEOPARDY (7 screens)
// ═══════════════════════════════════════════

const JEOPARDY_CATS = ['History','Science','Pop Culture','Sports','Food'];
const JEOPARDY_VALS = [200,400,600,800,1000];

const JeopardyBoard = ({answered=[]}) => (
  <div style={{position:'absolute',left:10,top:10,display:'flex',flexDirection:'column',gap:1}}>
    {/* Header row */}
    <div style={{display:'flex',gap:1}}>
      {JEOPARDY_CATS.map(cat=>(
        <Box key={cat} x={0} y={0} w={70} h={36} r={4} fill={WC.g3} stroke={WC.g4} style={{position:'relative',fontSize:8,fontWeight:600,textAlign:'center',padding:'0 2px'}}>{cat}</Box>
      ))}
    </div>
    {/* Value rows */}
    {JEOPARDY_VALS.map((val,ri)=>(
      <div key={val} style={{display:'flex',gap:1}}>
        {JEOPARDY_CATS.map((cat,ci)=>{
          const isAnswered=answered.includes(`${ri}-${ci}`);
          return (
            <Box key={ci} x={0} y={0} w={70} h={36} r={4} fill={isAnswered?WC.g1:WC.g2} stroke={WC.g3} dash={!isAnswered} style={{position:'relative'}}>
              {!isAnswered&&<span style={{fontSize:12,fontWeight:700,color:WC.g5}}>${val}</span>}
            </Box>
          );
        })}
      </div>
    ))}
  </div>
);

const ScreenI1 = () => (
  <WireScreen number="I1" title="Jeopardy — Category Board" annotations={[
    {title:'Board', body:'5 categories × 5 values ($200–$1000). Answered cells go blank/dimmed.'},
    {title:'Selection', body:'Current player selects a cell. Others cannot select (only active player\'s turn).'},
    {title:'Turn order', body:'Round-robin: player who answered last goes again if correct; otherwise next player clockwise.'},
    {title:'Scores', body:'Live scores shown below board. Update in real-time.'},
    {title:'Sync', body:'Board state synced to all devices. All see same answered/available cells.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Jake's pick</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'muted'},{name:'Mom',state:'muted'},{name:'Jake',state:'speaking'}]}/>
    <Box x={0} y={168} w={390} h={340} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <JeopardyBoard answered={['0-0','0-2','1-1','2-3']}/>
    </Box>
    {/* Scores */}
    <Box x={10} y={516} w={370} h={52} r={10} fill={WC.g1} stroke={WC.g2}>
      <div style={{position:'absolute',left:10,top:10,display:'flex',gap:20}}>
        {[['You','$1,400'],['Mom','$800'],['Jake','$2,200']].map(([name,score])=>(
          <div key={name} style={{display:'flex',flexDirection:'column',gap:2}}>
            <div style={{fontSize:9,color:WC.g4}}>{name}</div>
            <div style={{fontSize:13,fontWeight:700,color:WC.black}}>{score}</div>
          </div>
        ))}
      </div>
    </Box>
    <Txt x={50} y={578} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Jake is choosing — tap to select when it's your turn</Txt>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','🏁 Final J','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenI2 = () => (
  <WireScreen number="I2" title="Jeopardy — Question Revealed" annotations={[
    {title:'Question text', body:'Large text, easy to read aloud. Host reads via voice; text also shown for all.'},
    {title:'Category + value', body:'Shown at top of question card for context.'},
    {title:'Reading state', body:'Buzzer not active yet — short delay (configurable, default 2s) before buzz-in opens.'},
    {title:'Adaptive', body:'Question text: 18→22px. Card padding doubles in Larger & Calmer.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Science · $600</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'muted'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    <Box x={20} y={182} w={350} h={260} r={16} fill={WC.g1} stroke={WC.g3}>
      <Tag x={20} y={16} label="SCIENCE" fill={WC.g3}/>
      <Tag x={92} y={16} label="$600" fill={WC.g2}/>
      <Txt x={20} y={46} size={17} weight={700} color={WC.black} w={310}>This element has the atomic number 79 and is prized for its conductivity and malleability.</Txt>
      <Txt x={20} y={180} size={11} color={WC.g4}>Answer in the form of a question.</Txt>
      <Box x={20} y={210} w={310} h={32} r={8} fill={WC.g2} stroke={WC.g3}>
        <Txt x={0} y={8} size={10} style={{position:'static'}}>Buzzer opens in 2s…</Txt>
      </Box>
    </Box>
    <Box x={10} y={456} w={370} h={52} r={10} fill={WC.g1} stroke={WC.g2}>
      <div style={{position:'absolute',left:10,top:10,display:'flex',gap:20}}>
        {[['You','$1,400'],['Mom','$800'],['Jake','$2,200']].map(([name,score])=>(<div key={name} style={{display:'flex',flexDirection:'column',gap:2}}><div style={{fontSize:9,color:WC.g4}}>{name}</div><div style={{fontSize:13,fontWeight:700}}>{score}</div></div>))}
      </div>
    </Box>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','🔔 Buzz In (2s)','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0,opacity:i===1?0.4:1}}><span style={{fontSize:9}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenI3 = () => (
  <WireScreen number="I3" title="Jeopardy — Buzzer Ready" annotations={[
    {title:'Countdown', body:'Circular countdown (configurable, default 10s). All players see same timer.'},
    {title:'Buzz in', body:'Large tap target button (full-width, minimum 56px tall). First to buzz locks out others.'},
    {title:'Lock-out', body:'After one player buzzes, button dims for others — "Jake buzzed in!"'},
    {title:'No buzz', body:'If nobody buzzes in time, question marked as skipped.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Science · $600</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    <Box x={20} y={182} w={350} h={180} r={16} fill={WC.g1} stroke={WC.g3}>
      <Txt x={20} y={16} size={15} weight={700} color={WC.black} w={310}>This element has the atomic number 79 and is prized for its conductivity…</Txt>
      <Txt x={20} y={100} size={11} color={WC.g4}>Answer in the form of a question.</Txt>
    </Box>
    {/* Countdown circle */}
    <Circle x={170} y={374} size={50} fill={WC.g2} stroke={WC.g4} style={{border:`3px solid ${WC.g5}`}}>
      <Txt x={12} y={14} size={18} weight={700} color={WC.black}>7</Txt>
    </Circle>
    {/* Big buzz button */}
    <Btn x={20} y={444} w={350} h={64} label="🔔  BUZZ IN!" fill={WC.g3} stroke={WC.g4} bold={true} textSize={18}/>
    <Txt x={80} y={518} size={9} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>First to tap wins the right to answer</Txt>
    <Box x={0} y={638} w={390} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {['👆 Pointer','—','—'].map((label,i)=>(<Box key={i} x={i*130} y={0} w={130} h={50} r={0} fill={WC.g2} stroke={WC.g3} style={{borderRadius:0,opacity:i>0?0.3:1}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
  </WireScreen>
);

const ScreenI4 = () => (
  <WireScreen number="I4" title="Jeopardy — Player Answered" annotations={[
    {title:'Answer state', body:'Player who buzzed states answer via voice. Others hear via voice channel.'},
    {title:'Judgment', body:'Host (or whoever manages — see assumption note) taps Correct or Wrong.'},
    {title:'Assumption', body:'At launch: any player can judge. No automatic answer detection. Annotated.'},
    {title:'Timer', body:'Optional answer timer (10s default) — host can extend.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
      <Box x={120} y={12} w={150} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>You're answering!</Txt></Box>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    <Box x={20} y={182} w={350} h={140} r={16} fill={WC.g1} stroke={WC.g3}>
      <Txt x={20} y={14} size={13} weight={600}>Science · $600</Txt>
      <Txt x={20} y={36} size={14} color={WC.black} w={310}>This element has the atomic number 79…</Txt>
    </Box>
    <Box x={20} y={336} w={350} h={60} r={12} fill={WC.g2} stroke={WC.g3}>
      <Txt x={16} y={8} size={11} weight={600} color={WC.black}>You buzzed in first!</Txt>
      <Txt x={16} y={28} size={10} color={WC.g4}>State your answer out loud now. Others are listening.</Txt>
    </Box>
    {/* Answer timer */}
    <Box x={145} y={410} w={100} h={32} r={10} fill={WC.g1} stroke={WC.g3}>
      <Txt x={0} y={7} size={12} weight={700} style={{position:'static'}}>⏱ 8s left</Txt>
    </Box>
    {/* Judgment buttons */}
    <Txt x={30} y={456} size={11} weight={600} color={WC.g5}>WAS THE ANSWER CORRECT?</Txt>
    <div style={{position:'absolute',left:20,top:476,display:'flex',gap:12}}>
      <Btn x={0} y={0} w={168} h={52} label="✓  Correct" fill={WC.g3} stroke={WC.g4} bold={true} textSize={14}/>
      <Btn x={180} y={0} w={168} h={52} label="✗  Wrong" fill={WC.g1} stroke={WC.g3} textSize={14}/>
    </div>
    <Txt x={30} y={540} size={9} color={WC.g4} w={330} style={{fontStyle:'italic'}}>* Assumption: any player can judge at launch. Auto-detection planned for v2.</Txt>
  </WireScreen>
);

const ScreenI5 = () => (
  <WireScreen number="I5" title="Jeopardy — Judgment Result" annotations={[
    {title:'Correct', body:'Score added with animation. Player gets next pick. Brief celebration overlay.'},
    {title:'Wrong', body:'Score deducted. Other players can buzz in for same question, or question skipped.'},
    {title:'Auto-advance', body:'Advances back to board after 2.5s, or on tap.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
    </Box>
    <ParticipantsRow y={96}/>
    {/* Correct result */}
    <Box x={20} y={182} w={350} h={280} r={16} fill={WC.g2} stroke={WC.g3}>
      <Txt x={100} y={30} size={36}>✓</Txt>
      <Txt x={60} y={90} size={20} weight={700} color={WC.black} w={230} style={{textAlign:'center',position:'absolute'}}>Correct!</Txt>
      <Txt x={40} y={120} size={13} color={WC.g5} w={270} style={{textAlign:'center',position:'absolute'}}>What is Gold?</Txt>
      <Box x={60} y={162} w={230} h={48} r={10} fill={WC.g3} stroke={WC.g4}>
        <Txt x={0} y={14} size={14} weight={700} style={{position:'static'}}>You +$600 → $2,000</Txt>
      </Box>
      <Txt x={60} y={230} size={10} color={WC.g4} w={230} style={{textAlign:'center',position:'absolute'}}>Your pick next ·  returning to board in 2s…</Txt>
    </Box>
    <Box x={10} y={474} w={370} h={52} r={10} fill={WC.g1} stroke={WC.g2}>
      <div style={{position:'absolute',left:10,top:10,display:'flex',gap:20}}>
        {[['You','$2,000'],['Mom','$800'],['Jake','$2,200']].map(([name,score])=>(<div key={name} style={{display:'flex',flexDirection:'column',gap:2}}><div style={{fontSize:9,color:WC.g4}}>{name}</div><div style={{fontSize:13,fontWeight:700}}>{score}</div></div>))}
      </div>
    </Box>
    <Btn x={20} y={540} w={350} h={44} label="Back to Board" fill={WC.g2} stroke={WC.g3} bold={true} textSize={12}/>
  </WireScreen>
);

const ScreenI6 = () => (
  <WireScreen number="I6" title="Jeopardy — Daily Double / Wager" annotations={[
    {title:'Daily Double', body:'Hidden on board until revealed. Only person who selected it can wager.'},
    {title:'Wager', body:'Slider or numeric input. Min $5, max = current score (or $1000 if score < $1000).'},
    {title:'Final Jeopardy', body:'Same wager UI but all players wager simultaneously before category is revealed.'},
    {title:'Assumption', body:'1 Daily Double per game at launch. Placement randomised server-side.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Jeopardy</Txt>
      <Box x={100} y={12} w={190} h={28} r={8} fill={WC.g4} stroke={WC.g5}><Txt x={0} y={7} size={10} weight={700} color={WC.bg} style={{position:'static'}}>⭐ Daily Double!</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={20} y={182} w={350} h={340} r={16} fill={WC.g1} stroke={WC.g3}>
      <Txt x={80} y={20} size={22} weight={700} color={WC.black}>Daily Double!</Txt>
      <Txt x={20} y={60} size={11} color={WC.g4} w={310}>You found the Daily Double. Choose how much to wager.</Txt>
      <Txt x={20} y={100} size={11} weight={600} color={WC.g5}>YOUR WAGER</Txt>
      <Input x={20} y={118} w={310} h={48} placeholder="Enter amount ($5 – $2,000)"/>
      <Txt x={20} y={178} size={9} color={WC.g4}>Your current score: $2,000 · max wager: $2,000</Txt>
      {/* Quick options */}
      <div style={{position:'absolute',left:20,top:200,display:'flex',gap:8}}>
        {['$500','$1,000','All in!'].map(opt=>(<Box key={opt} x={0} y={0} w={opt==='All in!'?60:70} h={32} r={8} fill={WC.g2} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:10,fontWeight:600}}>{opt}</span></Box>))}
      </div>
      <Btn x={20} y={258} w={310} h={48} label="Lock in Wager" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
    </Box>
  </WireScreen>
);

const ScreenI7 = () => (
  <WireScreen number="I7" title="Jeopardy — End of Round Scores" annotations={[
    {title:'Rounds', body:'Jeopardy → Double Jeopardy → Final Jeopardy. Scores carried over.'},
    {title:'Negative', body:'Negative scores allowed. Shown with minus sign.'},
    {title:'Advance', body:'"Start Double Jeopardy" button. Host only.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={70} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={100} y={10} size={17} weight={700}>Round 1 Complete!</Txt>
        <Txt x={130} y={36} size={11} color={WC.g4}>Jeopardy Round</Txt>
      </Box>
      {[['🥇 You','$2,000',true],['🥈 Jake','$1,800',false],['🥉 Mom','-$200',false]].map(([name,score,win],i)=>(
        <Box key={i} x={30} y={82+i*72} w={330} h={62} r={12} fill={i===0?WC.g3:WC.g1} stroke={WC.g3}>
          <Txt x={16} y={8} size={14} weight={600}>{name}</Txt>
          <Txt x={16} y={28} size={22} weight={700}>{score}</Txt>
          {win&&<Tag x={240} y={18} label="Leading" fill={WC.g4}/>}
        </Box>
      ))}
      <Divider x={30} y={302} w={330}/>
      <Btn x={30} y={318} w={330} h={52} label="Start Double Jeopardy →" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Txt x={60} y={382} size={9} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>Host only — others see "Waiting for You to continue…"</Txt>
      <Btn x={30} y={402} w={330} h={44} label="Skip to Final Jeopardy" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW J: CROSSWORD PUZZLE (6 screens)
// ═══════════════════════════════════════════

const CrosswordGrid = ({size=8, filled=[], selected=null, typing=null}) => {
  const cells=[];
  for(let r=0;r<size;r++){
    for(let c=0;c<size;c++){
      const isBlack=filled.includes(`${r}-${c}`);
      const isSel=selected&&selected[0]===r&&selected[1]===c;
      const isTyping=typing&&typing[0]===r&&typing[1]===c;
      cells.push(
        <div key={`${r}-${c}`} style={{
          width:34,height:34,
          background:isBlack?WC.black:isSel?WC.g3:isTyping?WC.g4:WC.bg,
          border:`0.5px solid ${isBlack?WC.black:WC.g3}`,
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:13,fontWeight:700,color:isSel?WC.black:WC.g5,
          position:'relative',
        }}>
          {!isBlack&&<span style={{position:'absolute',top:1,left:2,fontSize:6,color:WC.g4,fontWeight:400}}>
            {(r*size+c)%7===0?Math.floor((r*size+c)/7)+1:''}
          </span>}
          {isSel&&'A'}{isTyping&&'_'}
        </div>
      );
    }
  }
  return <div style={{position:'absolute',left:10,top:10,display:'grid',gridTemplateColumns:`repeat(${size},34px)`,gridTemplateRows:`repeat(${size},34px)`,gap:0,border:`1px solid ${WC.g3}`}}>{cells}</div>;
};

const ScreenJ1 = () => (
  <WireScreen number="J1" title="Crossword — Puzzle Selection" annotations={[
    {title:'Difficulty', body:'Easy (smaller grid, common words) / Medium / Hard. Collaborative — all players same puzzle.'},
    {title:'Daily', body:'"Daily Crossword" option — same puzzle for everyone that day. Auto-selected by default.'},
    {title:'Language', body:'Puzzle language matches user\'s selected language. Hebrew crossword uses Hebrew words.'},
    {title:'Host only', body:'Host selects and starts. Others see "Waiting for host to pick a puzzle."'},
  ]}>
    <StatusBar/>
    <TopBar title="Crossword Puzzles" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Box x={20} y={10} w={350} h={72} r={14} fill={WC.g2} stroke={WC.g3}>
        <Txt x={16} y={10} size={13} weight={700}>⭐ Today's Daily Crossword</Txt>
        <Txt x={16} y={30} size={10} color={WC.g4}>15×15 · Medium · Updated daily</Txt>
        <Btn x={220} y={18} w={110} h={34} label="Play Today's" fill={WC.g3} stroke={WC.g4} bold={true} textSize={10}/>
      </Box>
      <Txt x={20} y={98} size={10} weight={600} color={WC.g5}>CHOOSE DIFFICULTY</Txt>
      {[['Easy','Smaller grid · Common words · 9×9'],['Medium','Standard grid · Varied clues · 13×13'],['Hard','Full size · Tricky clues · 15×15']].map(([d,desc],i)=>(
        <Box key={i} x={20} y={116+i*60} w={350} h={52} r={12} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Txt x={16} y={10} size={13} weight={600}>{d}</Txt>
          <Txt x={16} y={28} size={9} color={WC.g4}>{desc}</Txt>
          <Txt x={320} y={18} size={14} color={WC.g3}>›</Txt>
        </Box>
      ))}
      <Txt x={20} y={308} size={10} weight={600} color={WC.g5}>LANGUAGE</Txt>
      <Box x={20} y={326} w={350} h={44} r={10} fill={WC.g2} stroke={WC.g3}>
        <Txt x={16} y={13} size={12}>English</Txt>
        <Txt x={296} y={13} size={12} color={WC.g4}>Change ›</Txt>
      </Box>
    </Box>
  </WireScreen>
);

const ScreenJ2 = () => (
  <WireScreen number="J2" title="Crossword — Grid View" annotations={[
    {title:'PointerOverlay', body:'State A (solid crosshair, "You") + State B (dashed bloom, "Mom\'s pointer") when pointer mode active. Broadcast via Supabase Realtime at ~60ms.'},
    {title:'Collaboration', body:'All players see grid simultaneously. Any player can select a cell. No turn-based — fully collaborative.'},
    {title:'Across/Down', body:'Double-tap cell toggles Across ↔ Down direction. Direction shown in clue bar.'},
    {title:'Clue bar', body:'Sticky bar above keyboard shows active clue.'},
    {title:'Sync', body:'Filled letters appear on all screens in real-time as typed.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Crossword</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>12/78 filled</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={310} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CrosswordGrid size={8} filled={['0-3','0-4','1-7','2-0','3-5','4-2','5-6','6-1','7-4']} selected={[2,3]}/>
      {/* Pointer overlay hint */}
      <div style={{position:'absolute',left:230,top:180}}>
        <div style={{width:30,height:30,position:'relative'}}>
          <div style={{position:'absolute',top:14,left:0,width:10,height:1.5,background:WC.black}}/>
          <div style={{position:'absolute',top:14,left:18,width:10,height:1.5,background:WC.black}}/>
          <div style={{position:'absolute',left:14,top:0,width:1.5,height:12,background:WC.black}}/>
          <div style={{position:'absolute',left:14,top:16,width:1.5,height:12,background:WC.black}}/>
        </div>
        <div style={{fontSize:8,color:WC.g5,marginTop:2}}>You</div>
      </div>
    </Box>
    {/* Clue bar */}
    <Box x={0} y={478} w={390} h={44} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none'}}>
      <Tag x={12} y={12} label="14 ACROSS" fill={WC.g3}/>
      <Txt x={90} y={14} size={10} color={WC.black} w={280}>Capital city of France (5 letters)</Txt>
    </Box>
    <Box x={0} y={522} w={390} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      {['👆 Pointer','💡 Hint','Check','Reveal'].map((label,i)=>(<Box key={i} x={i*97} y={0} w={97} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderRadius:0}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
    {/* Keyboard placeholder */}
    <Box x={0} y={566} w={390} h={122} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <Txt x={140} y={52} size={10} color={WC.g4}>[ System keyboard ]</Txt>
    </Box>
  </WireScreen>
);

const ScreenJ3 = () => (
  <WireScreen number="J3" title="Crossword — Clue Focused" annotations={[
    {title:'Focus mode', body:'Tapping a cell selects the word (highlights entire word span). Clue enlarges in sticky bar.'},
    {title:'Direction toggle', body:'Tap highlighted clue bar to toggle Across ↔ Down for that cell.'},
    {title:'Scroll', body:'Clue list below grid scrollable. Tap any clue to jump to that cell.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Crossword</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Cell 3,4 selected</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={270} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CrosswordGrid size={8} filled={['0-3','1-7','3-5','5-6','7-4']} selected={[2,3]}/>
      {/* Highlighted word span */}
      <div style={{position:'absolute',left:10,top:78,width:170,height:34,background:WC.g3,opacity:0.4,borderRadius:0}}/>
    </Box>
    {/* Clue bar — enlarged */}
    <Box x={0} y={438} w={390} h={60} r={0} fill={WC.g3} stroke={WC.g4} style={{borderLeft:'none',borderRight:'none'}}>
      <Tag x={12} y={10} label="5 ACROSS" fill={WC.g4}/>
      <Txt x={12} y={32} size={12} weight={600} color={WC.black} w={360}>Capital city of France (5 letters)</Txt>
    </Box>
    {/* Clue list */}
    <Box x={0} y={498} w={390} h={190} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Txt x={16} y={8} size={10} weight={600} color={WC.g5}>ACROSS</Txt>
      {['1. River through London (6)','5. Capital of France (5)','8. Opposite of night (3)'].map((clue,i)=>(
        <Box key={i} x={16} y={26+i*36} w={358} h={30} r={6} fill={i===1?WC.g2:WC.bg} stroke={i===1?WC.g3:'none'} dash={i===1}>
          <Txt x={8} y={8} size={10} color={i===1?WC.black:WC.g4}>{clue}</Txt>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenJ4 = () => (
  <WireScreen number="J4" title="Crossword — Keyboard Input" annotations={[
    {title:'Keyboard', body:'System keyboard (soft). Language-aware — Hebrew keyboard for Hebrew users.'},
    {title:'Auto-advance', body:'After typing a letter, cursor advances to next empty cell in word.'},
    {title:'Per-user language', body:'Each user types in their own keyboard language. Hebrew user types right-to-left within cell, but grid layout stays LTR.'},
    {title:'Adaptive', body:'In Larger & Calmer: grid cells 34→42px. Keyboard unchanged (system).'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Crossword</Txt>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={220} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CrosswordGrid size={8} filled={['0-3','1-7','3-5','5-6','7-4']} selected={[2,4]}/>
    </Box>
    <Box x={0} y={388} w={390} h={60} r={0} fill={WC.g3} stroke={WC.g4} style={{borderLeft:'none',borderRight:'none'}}>
      <Tag x={12} y={10} label="5 ACROSS" fill={WC.g4}/>
      <Txt x={12} y={32} size={12} weight={600} color={WC.black} w={360}>Capital of France (5) · P A _ _ _</Txt>
    </Box>
    {/* System keyboard placeholder */}
    <Box x={0} y={448} w={390} h={240} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      {/* Simplified keyboard rows */}
      {[['Q','W','E','R','T','Y','U','I','O','P'],['A','S','D','F','G','H','J','K','L'],['Z','X','C','V','B','N','M','⌫']].map((row,ri)=>(
        <div key={ri} style={{position:'absolute',top:10+ri*60,left:'50%',transform:'translateX(-50%)',display:'flex',gap:3}}>
          {row.map(k=>(<Box key={k} x={0} y={0} w={k==='⌫'?46:32} h={48} r={6} fill={k==='⌫'?WC.g3:WC.bg} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:12,fontWeight:500}}>{k}</span></Box>))}
        </div>
      ))}
    </Box>
  </WireScreen>
);

const ScreenJ5 = () => (
  <WireScreen number="J5" title="Crossword — Collaboration Indicator" annotations={[
    {title:'Typing indicator', body:'When another player is typing in a cell, that cell pulses/dims. Label "Mom typing…" shown near cell.'},
    {title:'Non-blocking', body:'You can still type in a different cell simultaneously. No lock-out.'},
    {title:'Letter reveal', body:'Letter appears on all screens as soon as submitted (on letter key tap). Erased = erased for all.'},
    {title:'Conflict', body:'If two users type in same cell, last write wins. Optimistic update, server reconciles.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Crossword</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'speaking'},{name:'Jake',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={310} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <CrosswordGrid size={8} filled={['0-3','1-7','3-5','5-6','7-4']} selected={[1,2]} typing={[4,6]}/>
      {/* Mom typing indicator */}
      <div style={{position:'absolute',left:218,top:148,background:WC.g4,borderRadius:6,padding:'2px 6px'}}>
        <span style={{fontSize:8,color:WC.bg,fontWeight:600}}>Mom typing…</span>
      </div>
      <div style={{position:'absolute',left:226,top:161,width:0,height:0,borderLeft:'4px solid transparent',borderRight:'4px solid transparent',borderTop:`6px solid ${WC.g4}`}}/>
    </Box>
    <Box x={0} y={478} w={390} h={44} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none'}}>
      <Tag x={12} y={12} label="3 ACROSS" fill={WC.g3}/>
      <Txt x={90} y={14} size={10} color={WC.black} w={280}>Opposite of cold (3 letters)</Txt>
    </Box>
    <Box x={0} y={522} w={390} h={166} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <Txt x={140} y={70} size={10} color={WC.g4}>[ Keyboard ]</Txt>
    </Box>
  </WireScreen>
);

const ScreenJ6 = () => (
  <WireScreen number="J6" title="Crossword — Completion" annotations={[
    {title:'Trigger', body:'All cells correctly filled → celebration overlay auto-appears.'},
    {title:'Celebration', body:'Confetti animation (reduced motion: static). Duration, completion time shown.'},
    {title:'Review', body:'"Review Puzzle" lets players scroll completed grid.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      {/* Confetti placeholder */}
      <Box x={0} y={0} w={390} h={200} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',borderStyle:'dashed'}}>
        <Txt x={130} y={88} size={10} color={WC.g4}>[ Confetti animation ]</Txt>
      </Box>
      <Txt x={60} y={224} size={24} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Puzzle Solved! 🎉</Txt>
      <Txt x={60} y={260} size={12} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>You finished together in 18m 42s</Txt>
      <Box x={30} y={300} w={330} h={80} r={14} fill={WC.g1} stroke={WC.g2}>
        <Txt x={16} y={10} size={11} weight={600}>Team stats</Txt>
        <Txt x={16} y={30} size={10} color={WC.g4}>You: 34 letters  ·  Mom: 28 letters  ·  Jake: 16 letters</Txt>
        <Txt x={16} y={50} size={10} color={WC.g4}>Hints used: 2  ·  Errors corrected: 5</Txt>
      </Box>
      <Btn x={30} y={400} w={330} h={52} label="Play Another Puzzle" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={462} w={330} h={44} label="Review Completed Grid" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={516} w={330} h={44} label="🎡  Next Activity" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW K: SUDOKU (5 screens)
// ═══════════════════════════════════════════

const SudokuGrid = ({size=9, conflicts=[], selected=null}) => {
  const boxSize=size===9?3:size===6?2:2;
  const cells=[];
  // Seed some numbers
  const preset={
    '0-0':'5','0-4':'3','1-2':'9','2-1':'8','3-3':'6','4-4':'7','5-5':'4','6-6':'2','7-7':'1','8-8':'9'
  };
  for(let r=0;r<size;r++){
    for(let c=0;c<size;c++){
      const key=`${r}-${c}`;
      const isConflict=conflicts.includes(key);
      const isSel=selected&&selected[0]===r&&selected[1]===c;
      const cellSize=size===4?56:size===6?42:34;
      const showBorderR=(c+1)%boxSize===0&&c<size-1;
      const showBorderB=(r+1)%boxSize===0&&r<size-1;
      cells.push(
        <div key={key} style={{
          width:cellSize,height:cellSize,
          background:isConflict?WC.g4:isSel?WC.g3:WC.bg,
          border:`0.5px solid ${WC.g3}`,
          borderRight:showBorderR?`2px solid ${WC.g5}`:undefined,
          borderBottom:showBorderB?`2px solid ${WC.g5}`:undefined,
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:size===4?20:size===6?15:13,
          fontWeight:preset[key]?700:400,
          color:isConflict?WC.bg:preset[key]?WC.black:WC.g4,
        }}>
          {preset[key]||(isSel?'?':'')}
        </div>
      );
    }
  }
  return <div style={{position:'absolute',left:size===4?90:size===6?40:10,top:10,display:'grid',gridTemplateColumns:`repeat(${size},${size===4?56:size===6?42:34}px)`,gridTemplateRows:`repeat(${size},${size===4?56:size===6?42:34}px)`,gap:0,border:`2px solid ${WC.g5}`}}>{cells}</div>;
};

const ScreenK1 = () => (
  <WireScreen number="K1" title="Sudoku — Difficulty Selection" annotations={[
    {title:'Grid sizes', body:'4×4 (easiest, good for mixed-age groups), 6×6 (medium), 9×9 (standard). Size selection = difficulty proxy.'},
    {title:'Collaborative', body:'All players work on same grid simultaneously. Any player can fill any cell.'},
    {title:'Host picks', body:'Host selects difficulty. Others see "Waiting for host…"'},
  ]}>
    <StatusBar/>
    <TopBar title="Sudoku" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Txt x={30} y={20} size={17} weight={700} w={330} style={{textAlign:'center',position:'absolute'}}>Choose difficulty</Txt>
      <Txt x={50} y={50} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>All players work on the same puzzle together.</Txt>
      {[['Easy','4×4 grid · Perfect for beginners','~5 min'],['Medium','6×6 grid · Some challenge','~10 min'],['Hard','9×9 grid · Classic Sudoku','~20 min']].map(([d,desc,time],i)=>(
        <Box key={i} x={20} y={86+i*90} w={350} h={80} r={14} fill={WC.g1} stroke={WC.g2} dash={true}>
          <Txt x={16} y={10} size={15} weight={700}>{d}</Txt>
          <Txt x={16} y={34} size={10} color={WC.g4} w={260}>{desc}</Txt>
          <Tag x={16} y={54} label={time} fill={WC.g2}/>
          <Txt x={320} y={28} size={18} color={WC.g3}>›</Txt>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenK2 = () => (
  <WireScreen number="K2" title="Sudoku — Grid View (9×9)" annotations={[
    {title:'PointerOverlay', body:'State A (solid crosshair, "You") + State B (dashed bloom, remote participant). Pointer broadcast via Supabase Realtime ~60ms. Active when pointer mode on.'},
    {title:'Preset numbers', body:'Pre-filled cells shown bold, cannot be edited. User-entered cells shown lighter.'},
    {title:'Box borders', body:'3×3 box borders shown thicker to help navigation.'},
    {title:'Sync', body:'Number placements sync across all devices in real-time.'},
    {title:'Adaptive', body:'9×9 cells 34px→42px on tablet. 4×4 cells 56px→70px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Sudoku</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={0} y={7} size={10} style={{position:'static'}}>Hard · 9×9</Txt></Box>
      <Txt x={358} y={16} size={12}>⏸</Txt>
    </Box>
    <ParticipantsRow y={96} participants={[{name:'You',state:'speaking'},{name:'Mom',state:'muted'},{name:'Jake',state:'muted'}]}/>
    <Box x={0} y={168} w={390} h={336} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <SudokuGrid size={9} selected={[3,4]}/>
    </Box>
    <Box x={0} y={504} w={390} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      {['👆 Pointer','✏ Notes','💡 Hint','Check'].map((label,i)=>(<Box key={i} x={i*97} y={0} w={97} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderRadius:0}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
    {/* Number pad */}
    <Box x={0} y={548} w={390} h={140} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <div style={{position:'absolute',top:16,left:'50%',transform:'translateX(-50%)',display:'flex',gap:6}}>
        {[1,2,3,4,5,6,7,8,9].map(n=>(<Box key={n} x={0} y={0} w={34} h={50} r={8} fill={WC.bg} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:16,fontWeight:700}}>{n}</span></Box>))}
      </div>
      <div style={{position:'absolute',top:80,left:'50%',transform:'translateX(-50%)',display:'flex',gap:6}}>
        <Box x={0} y={0} w={100} h={44} r={8} fill={WC.g2} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:11}}>⌫ Delete</span></Box>
        <Box x={0} y={0} w={180} h={44} r={8} fill={WC.g1} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:11}}>✏ Toggle Notes</span></Box>
      </div>
    </Box>
  </WireScreen>
);

const ScreenK3 = () => (
  <WireScreen number="K3" title="Sudoku — Cell Selected + Number Pad" annotations={[
    {title:'Selection', body:'Tap cell → highlights. Same row/column/box cells subtly highlighted.'},
    {title:'Number pad', body:'1-9 pad replaces keyboard. Tap number to fill cell. Tap again to clear.'},
    {title:'Notes mode', body:'Toggle Notes: tap numbers to fill small pencil-marks in cell (candidates).'},
    {title:'Conflict check', body:'Instant client-side validation. Conflicting cells highlighted immediately.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Sudoku</Txt>
      <Box x={130} y={12} w={130} h={28} r={8} fill={WC.g3} stroke={WC.g4}><Txt x={0} y={7} size={10} weight={600} style={{position:'static'}}>Cell selected</Txt></Box>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={336} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <SudokuGrid size={9} selected={[4,4]}/>
      {/* Row/col/box highlights */}
      <div style={{position:'absolute',left:10,top:146,width:306,height:34,background:WC.g2,opacity:0.5,pointerEvents:'none'}}/>
      <div style={{position:'absolute',left:146,top:10,width:34,height:306,background:WC.g2,opacity:0.5,pointerEvents:'none'}}/>
    </Box>
    <Box x={0} y={504} w={390} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      {['👆 Pointer','✏ Notes OFF','💡 Hint','—'].map((label,i)=>(<Box key={i} x={i*97} y={0} w={97} h={44} r={0} fill={i===1?WC.g2:WC.g1} stroke={WC.g2} style={{borderRadius:0}}><span style={{fontSize:9}}>{label}</span></Box>))}
    </Box>
    <Box x={0} y={548} w={390} h={140} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <div style={{position:'absolute',top:16,left:'50%',transform:'translateX(-50%)',display:'flex',gap:6}}>
        {[1,2,3,4,5,6,7,8,9].map(n=>(<Box key={n} x={0} y={0} w={34} h={50} r={8} fill={WC.bg} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:16,fontWeight:700}}>{n}</span></Box>))}
      </div>
      <div style={{position:'absolute',top:80,left:'50%',transform:'translateX(-50%)',display:'flex',gap:6}}>
        <Box x={0} y={0} w={100} h={44} r={8} fill={WC.g2} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:11}}>⌫ Delete</span></Box>
        <Box x={0} y={0} w={180} h={44} r={8} fill={WC.g1} stroke={WC.g3} style={{position:'relative'}}><span style={{fontSize:11}}>✏ Toggle Notes</span></Box>
      </div>
    </Box>
  </WireScreen>
);

const ScreenK4 = () => (
  <WireScreen number="K4" title="Sudoku — Conflict Detected" annotations={[
    {title:'Conflict', body:'Conflicting cells highlighted in darker gray. Non-blocking — just a soft warning.'},
    {title:'Soft warning', body:'Banner at top of number pad: "5 appears twice in this row". No haptic shock.'},
    {title:'Collaborative conflict', body:'If two players place conflicting numbers, both cells flagged. Last write wins — players discuss via voice.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={16} y={16} size={13} weight={600}>Sudoku</Txt>
    </Box>
    <ParticipantsRow y={96}/>
    <Box x={0} y={168} w={390} h={336} r={0} fill={WC.bg} stroke="none" style={{overflow:'hidden'}}>
      <SudokuGrid size={9} conflicts={['4-4','4-2']} selected={[4,4]}/>
    </Box>
    {/* Soft warning banner */}
    <Box x={0} y={504} w={390} h={40} r={0} fill={WC.g3} stroke={WC.g4} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={16} y={12} size={10} weight={600} color={WC.black}>⚠ 5 appears twice in row 5 — check your placement</Txt>
    </Box>
    <Box x={0} y={544} w={390} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none'}}>
      {['👆 Pointer','✏ Notes','💡 Hint','Check'].map((label,i)=>(<Box key={i} x={i*97} y={0} w={97} h={44} r={0} fill={WC.g1} stroke={WC.g2} style={{borderRadius:0}}><span style={{fontSize:10}}>{label}</span></Box>))}
    </Box>
    <Box x={0} y={588} w={390} h={100} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <div style={{position:'absolute',top:10,left:'50%',transform:'translateX(-50%)',display:'flex',gap:6}}>
        {[1,2,3,4,5,6,7,8,9].map(n=>(<Box key={n} x={0} y={0} w={34} h={50} r={8} fill={n===5?WC.g4:WC.bg} stroke={n===5?WC.g5:WC.g3} style={{position:'relative'}}><span style={{fontSize:16,fontWeight:700,color:n===5?WC.bg:WC.black}}>{n}</span></Box>))}
      </div>
    </Box>
  </WireScreen>
);

const ScreenK5 = () => (
  <WireScreen number="K5" title="Sudoku — Completion" annotations={[
    {title:'Trigger', body:'All 81 cells correctly filled.'},
    {title:'Validation', body:'Server validates the complete grid. Client shows result immediately (optimistic).'},
    {title:'Stats', body:'Time taken, hints used, errors corrected shown per player.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={180} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',borderStyle:'dashed'}}>
        <Txt x={140} y={80} size={10} color={WC.g4}>[ Celebration animation ]</Txt>
      </Box>
      <Txt x={60} y={204} size={22} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Sudoku Complete! 🎯</Txt>
      <Txt x={50} y={240} size={12} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Solved in 23m 14s — Hard mode!</Txt>
      <Box x={30} y={280} w={330} h={90} r={14} fill={WC.g1} stroke={WC.g2}>
        <Txt x={16} y={10} size={11} weight={600}>Contributions</Txt>
        {[['You','42 cells · 1 hint'],['Mom','27 cells · 2 hints'],['Jake','12 cells · 0 hints']].map(([name,cont],i)=>(
          <Txt key={i} x={16} y={28+i*16} size={10} color={WC.g4}>{name}: {cont}</Txt>
        ))}
      </Box>
      <Btn x={30} y={390} w={330} h={52} label="Play Another Sudoku" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={452} w={330} h={44} label="🎡  Next Activity" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={506} w={330} h={44} label="Back to Lobby" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW L: SESSION END (2 screens)
// ═══════════════════════════════════════════

const ScreenL1 = () => (
  <WireScreen number="L1" title="Session Summary" annotations={[
    {title:'Summary', body:'Total session time, activities played, who participated shown.'},
    {title:'Reflection prompt', body:'Optional text prompt e.g. "What was your favourite moment?" Voice recording optional (v2).'},
    {title:'Shared', body:'Same summary shown to all participants simultaneously.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={0} y={0} w={390} h={90} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
        <Txt x={100} y={14} size={18} weight={700}>Session Complete! 🎊</Txt>
        <Txt x={130} y={42} size={11} color={WC.g4}>Tuesday, April 22 · 47 min</Txt>
      </Box>
      {/* Stats row */}
      <div style={{position:'absolute',left:20,top:102,display:'flex',gap:10}}>
        {[['3','Activities'],['47m','Together'],['You+2','Players']].map(([val,label])=>(
          <Box key={label} x={0} y={0} w={108} h={70} r={12} fill={WC.g1} stroke={WC.g2} style={{position:'relative',flexDirection:'column'}}>
            <div style={{fontSize:22,fontWeight:700,marginTop:8}}>{val}</div>
            <div style={{fontSize:9,color:WC.g4}}>{label}</div>
          </Box>
        ))}
      </div>
      <Txt x={20} y={186} size={10} weight={600} color={WC.g5}>ACTIVITIES PLAYED</Txt>
      {[['Scrabble','You won · 142 pts'],['Jeopardy','Jake won'],['Sudoku','Team effort · Hard']].map(([game,result],i)=>(
        <Box key={i} x={20} y={202+i*52} w={350} h={44} r={10} fill={WC.g1} stroke={WC.g2}>
          <Circle x={10} y={6} size={32} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={52} y={6} size={12} weight={600}>{game}</Txt>
          <Txt x={52} y={24} size={9} color={WC.g4}>{result}</Txt>
        </Box>
      ))}
      <Box x={20} y={364} w={350} h={72} r={12} fill={WC.g1} stroke={WC.g2} style={{borderStyle:'dashed'}}>
        <Txt x={16} y={10} size={11} weight={600} color={WC.g5}>How did it feel today?</Txt>
        <Txt x={16} y={28} size={9} color={WC.g4}>Type a note or skip — just for you.</Txt>
        <Input x={16} y={44} w={318} h={20} placeholder="Optional reflection…"/>
      </Box>
      <Btn x={20} y={450} w={350} h={52} label="Play Again!" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={20} y={512} w={350} h={44} label="Go Home" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const ScreenL2 = () => (
  <WireScreen number="L2" title="Post-Session: Play Again / Home" annotations={[
    {title:'Same group', body:'"Play again with same people" keeps the room alive and spins the wheel.'},
    {title:'Schedule', body:'"Schedule next session" opens date picker → sends push to all participants.'},
    {title:'Share', body:'"Share session recap" → native share sheet with summary card image.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Box x={145} y={60} w={100} h={70} r={14} fill={WC.g2} stroke={WC.g3}>
        <Txt x={28} y={26} size={9} color={WC.g5}>LOGO</Txt>
      </Box>
      <Txt x={60} y={152} size={18} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>See you next time! 👋</Txt>
      <Txt x={50} y={184} size={11} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Great session with Mom and Jake.</Txt>
      <Btn x={30} y={230} w={330} h={52} label="▶  Play Again with Same Group" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Btn x={30} y={292} w={330} h={44} label="📅  Schedule Next Session" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={346} w={330} h={44} label="↗  Share Session Recap" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Divider x={30} y={402} w={330}/>
      <Btn x={30} y={416} w={330} h={44} label="Go Home" fill={WC.bg} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const FlowIJKL = () => (
  <div style={{display:'flex',flexDirection:'column',gap:40}}>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW I — JEOPARDY (7 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenI1/><ScreenI2/><ScreenI3/><ScreenI4/></div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,marginTop:24}}><ScreenI5/><ScreenI6/><ScreenI7/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW J — CROSSWORD PUZZLE (6 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenJ1/><ScreenJ2/><ScreenJ3/><ScreenJ4/></div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24,marginTop:24}}><ScreenJ5/><ScreenJ6/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW K — SUDOKU (5 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenK1/><ScreenK2/><ScreenK3/><ScreenK4/><ScreenK5/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW L — SESSION END (2 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenL1/><ScreenL2/></div>
    </div>
  </div>
);

Object.assign(window, {FlowIJKL});
