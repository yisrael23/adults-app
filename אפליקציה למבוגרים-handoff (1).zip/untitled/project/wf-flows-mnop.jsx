
// Senior Brains Wireframes — Flows M, N, O, P + Component Library + Nav Architecture
// Requires wf-primitives.jsx loaded first

// ═══════════════════════════════════════════
// FLOW M: SETTINGS (5 screens)
// ═══════════════════════════════════════════

const SettingsRow = ({label, value='', arrow=true, y=0}) => (
  <>
    <Box x={20} y={y} w={350} h={48} r={0} fill={WC.bg} stroke="none" style={{borderBottom:`1px solid ${WC.g2}`}}>
      <Txt x={0} y={15} size={12}>{label}</Txt>
      {value && <Txt x={240} y={15} size={11} color={WC.g4} style={{position:'absolute',right:arrow?32:8}}>{value}</Txt>}
      {arrow && <Txt x={336} y={15} size={14} color={WC.g3}>›</Txt>}
    </Box>
  </>
);

const Toggle = ({x=0, y=0, on=false}) => (
  <Box x={x} y={y} w={44} h={24} r={12} fill={on?WC.g4:WC.g2} stroke={WC.g3}>
    <div style={{position:'absolute',left:on?22:2,top:2,width:20,height:20,borderRadius:'50%',background:WC.bg,border:`1px solid ${WC.g3}`}}/>
  </Box>
);

const ScreenM1 = () => (
  <WireScreen number="M1" title="Settings — Main" annotations={[
    {title:'Sections', body:'Profile / Display / Audio / Subscription. Scrollable list.'},
    {title:'RTL', body:'Settings list mirrors in Hebrew — arrow chevrons point left, labels right-aligned.'},
    {title:'Adaptive', body:'Row height 48→60px. Font 12→16px. Arrow tap targets always ≥44px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none'}}>
      <Txt x={160} y={16} size={14} weight={700}>Settings</Txt>
    </Box>
    {/* Profile mini-card */}
    <Box x={20} y={108} w={350} h={72} r={14} fill={WC.g1} stroke={WC.g2} dash={true}>
      <Circle x={12} y={16} size={40} fill={WC.g2} stroke={WC.g3}/>
      <Txt x={64} y={16} size={13} weight={600}>Your Name</Txt>
      <Txt x={64} y={36} size={10} color={WC.g4}>English · Standard mode</Txt>
      <Txt x={310} y={28} size={12} color={WC.g4}>Edit ›</Txt>
    </Box>
    <Txt x={20} y={194} size={10} weight={600} color={WC.g5}>DISPLAY</Txt>
    <SettingsRow label="UI Mode" value="Standard" y={212}/>
    <SettingsRow label="Language" value="English" y={260}/>
    <SettingsRow label="Reduce Motion" value="" y={308} arrow={false}/>
    <Toggle x={320} y={320} on={false}/>
    <Txt x={20} y={370} size={10} weight={600} color={WC.g5}>AUDIO</Txt>
    <SettingsRow label="Microphone" value="Built-in" y={388}/>
    <SettingsRow label="Test Microphone" value="" y={436}/>
    <Txt x={20} y={498} size={10} weight={600} color={WC.g5}>ACCOUNT</Txt>
    <SettingsRow label="Subscription" value="Free" y={516}/>
    <SettingsRow label="Privacy Policy" value="" y={564}/>
    <SettingsRow label="Terms of Service" value="" y={612}/>
    <SettingsRow label="Contact Us" value="" y={660}/>
    <BottomBar tabs={['Home','Rooms','Settings']} active={2}/>
  </WireScreen>
);

const ScreenM2 = () => (
  <WireScreen number="M2" title="Profile Edit" annotations={[
    {title:'Photo', body:'Optional avatar photo. Tapping opens system image picker or camera. Cropped to circle.'},
    {title:'Name', body:'1–20 chars. Shown to all room participants.'},
    {title:'Language', body:'Changes UI language immediately on save. App re-renders in new locale.'},
  ]}>
    <StatusBar/>
    <TopBar title="Edit Profile" back={true} action="Save"/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      {/* Avatar */}
      <Circle x={155} y={30} size={80} fill={WC.g2} stroke={WC.g3} dash={true}>
        <Txt x={12} y={28} size={9} color={WC.g4}>Tap to</Txt>
        <Txt x={14} y={40} size={9} color={WC.g4}>change</Txt>
      </Circle>
      <Txt x={20} y={130} size={11} weight={600} color={WC.g5}>YOUR NAME</Txt>
      <Input x={20} y={148} w={350} h={48} placeholder="Your name"/>
      <Txt x={20} y={210} size={11} weight={600} color={WC.g5}>LANGUAGE</Txt>
      {['English','עברית (Hebrew)','Русский (Russian)'].map((lang,i)=>(
        <Box key={i} x={20} y={228+i*54} w={350} h={46} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3}>
          <Txt x={16} y={14} size={12}>{lang}</Txt>
          {i===0 && <Tag x={270} y={12} label="Current" fill={WC.g3}/>}
        </Box>
      ))}
      <Btn x={20} y={428} w={350} h={52} label="Save Changes" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
    </Box>
  </WireScreen>
);

const ScreenM3 = () => (
  <WireScreen number="M3" title="Display Settings" annotations={[
    {title:'UI Mode', body:'Standard ↔ Larger & Calmer toggle. Takes effect immediately, no restart required.'},
    {title:'Reduce motion', body:'Overrides OS setting. Disables transitions, auto-advancing animations.'},
    {title:'Theme', body:'Light/Dark/System. Dark mode: same grayscale palette, inverted. (v1: light only)'},
    {title:'Assumption', body:'Dark mode planned for v2. Annotated.'},
  ]}>
    <StatusBar/>
    <TopBar title="Display Settings" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Txt x={20} y={20} size={11} weight={600} color={WC.g5}>UI MODE</Txt>
      <div style={{position:'absolute',left:20,top:38,display:'flex',gap:10}}>
        {['Standard','Larger & Calmer'].map((mode,i)=>(
          <Box key={i} x={0} y={0} w={i===0?120:190} h={52} r={12} fill={i===0?WC.g3:WC.g1} stroke={i===0?WC.g4:WC.g3} style={{position:'relative'}}>
            <span style={{fontSize:11,fontWeight:i===0?600:400}}>{mode}</span>
          </Box>
        ))}
      </div>
      <Txt x={20} y={104} size={9} color={WC.g4}>Takes effect immediately. You can switch any time.</Txt>

      <Txt x={20} y={130} size={11} weight={600} color={WC.g5}>THEME</Txt>
      {['Light (default)','Dark','System default'].map((theme,i)=>(
        <Box key={i} x={20} y={148+i*52} w={350} h={44} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3}>
          <Txt x={16} y={13} size={12}>{theme}</Txt>
          {i!==0&&<Tag x={220} y={12} label={i===2?'v1 only light':'v2 planned'} fill={WC.g2}/>}
        </Box>
      ))}

      <Txt x={20} y={310} size={11} weight={600} color={WC.g5}>MOTION</Txt>
      <Box x={20} y={328} w={350} h={48} r={0} fill={WC.bg} stroke="none" style={{borderBottom:`1px solid ${WC.g2}`}}>
        <Txt x={0} y={15} size={12}>Reduce Motion</Txt>
        <Toggle x={298} y={12} on={false}/>
      </Box>
      <Box x={20} y={376} w={350} h={48} r={0} fill={WC.bg} stroke="none" style={{borderBottom:`1px solid ${WC.g2}`}}>
        <Txt x={0} y={15} size={12}>Slower Animations</Txt>
        <Toggle x={298} y={12} on={true}/>
      </Box>
      <Txt x={20} y={434} size={9} color={WC.g4} w={350}>Slower animations: all transitions run at 0.7× speed.</Txt>
    </Box>
  </WireScreen>
);

const ScreenM4 = () => (
  <WireScreen number="M4" title="Audio Settings" annotations={[
    {title:'Mic device', body:'Lists available input devices (built-in, AirPods, wired). iOS: AVAudioSession. Android: AudioManager.'},
    {title:'Test', body:'"Test Microphone" opens a 5s recording playback loop so user can verify audio quality.'},
    {title:'Volume', body:'Output volume slider. In-app only — does not override system volume.'},
  ]}>
    <StatusBar/>
    <TopBar title="Audio Settings" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Txt x={20} y={20} size={11} weight={600} color={WC.g5}>MICROPHONE</Txt>
      {['Built-in Microphone','AirPods Pro','Wired Headset'].map((dev,i)=>(
        <Box key={i} x={20} y={38+i*54} w={350} h={46} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3}>
          <Circle x={10} y={7} size={32} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={54} y={14} size={12}>{dev}</Txt>
          {i===0 && <Tag x={260} y={12} label="Active" fill={WC.g3}/>}
        </Box>
      ))}
      <Btn x={20} y={212} w={350} h={48} label="🎤  Test Microphone (5s)" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Txt x={20} y={274} size={9} color={WC.g4}>Tap to record 5 seconds, then listen back to check your audio.</Txt>

      <Txt x={20} y={302} size={11} weight={600} color={WC.g5}>VOICE CHAT VOLUME</Txt>
      {/* Slider */}
      <Box x={20} y={320} w={350} h={40} r={0} fill={WC.bg} stroke="none">
        <div style={{position:'absolute',top:18,left:0,width:350,height:4,background:WC.g2,borderRadius:2}}/>
        <div style={{position:'absolute',top:18,left:0,width:210,height:4,background:WC.g4,borderRadius:2}}/>
        <div style={{position:'absolute',top:10,left:202,width:20,height:20,borderRadius:'50%',background:WC.g5,border:`2px solid ${WC.g3}`}}/>
        <Txt x={0} y={28} size={8} color={WC.g4}>Min</Txt>
        <Txt x={328} y={28} size={8} color={WC.g4}>Max</Txt>
      </Box>

      <Txt x={20} y={378} size={11} weight={600} color={WC.g5}>VOICE OPTIONS</Txt>
      {['Noise Suppression','Echo Cancellation'].map((opt,i)=>(
        <Box key={i} x={20} y={396+i*52} w={350} h={48} r={0} fill={WC.bg} stroke="none" style={{borderBottom:`1px solid ${WC.g2}`}}>
          <Txt x={0} y={15} size={12}>{opt}</Txt>
          <Toggle x={298} y={12} on={true}/>
        </Box>
      ))}
    </Box>
  </WireScreen>
);

const ScreenM5 = () => (
  <WireScreen number="M5" title="Subscription Management" annotations={[
    {title:'Free tier', body:'Free users can join rooms but cannot host unlimited games. Limits TBD.'},
    {title:'Plus', body:'$4.99/mo. Unlimited hosting, custom wallpapers, game history.'},
    {title:'Platform', body:'In-app purchase via App Store / Google Play. Apple/Google take 30%.'},
    {title:'Manage', body:'"Manage in App Store" → opens OS subscription manager.'},
  ]}>
    <StatusBar/>
    <TopBar title="Subscription" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none">
      <Box x={20} y={20} w={350} h={72} r={14} fill={WC.g2} stroke={WC.g3}>
        <Txt x={16} y={12} size={13} weight={700}>Senior Brains Free</Txt>
        <Txt x={16} y={32} size={10} color={WC.g5}>Current plan · Active</Txt>
        <Btn x={220} y={20} w={114} h={32} label="Upgrade →" fill={WC.g4} stroke={WC.g5} bold={true} textSize={10}/>
      </Box>
      <Txt x={20} y={108} size={10} weight={600} color={WC.g5}>YOUR PLAN INCLUDES</Txt>
      {['Join any room','Play all 5 activities','Voice chat','Solo puzzles'].map((f,i)=>(
        <Txt key={i} x={20} y={126+i*20} size={11} color={WC.g5}>✓ {f}</Txt>
      ))}
      <Divider x={20} y={220} w={350}/>
      <Txt x={20} y={236} size={10} weight={600} color={WC.g5}>NOT INCLUDED (FREE)</Txt>
      {['Host unlimited rooms','Custom room wallpapers','Game history & replays','Priority support'].map((f,i)=>(
        <Txt key={i} x={20} y={254+i*20} size={11} color={WC.g4}>✗ {f}</Txt>
      ))}
      <Btn x={20} y={360} w={350} h={52} label="Upgrade to Plus — $4.99/mo" fill={WC.g3} stroke={WC.g4} bold={true} textSize={13}/>
      <Txt x={60} y={424} size={9} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>Billed monthly · Cancel any time · Manage in App Store</Txt>
      <Btn x={20} y={450} w={350} h={40} label="Restore Purchases" fill={WC.bg} stroke={WC.g3} textSize={11}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW N: PAYWALL (1 screen)
// ═══════════════════════════════════════════

const ScreenN1 = () => (
  <WireScreen number="N1" title="Paywall — Upgrade to Plus" annotations={[
    {title:'Trigger', body:'Shown when free user tries to host a room (or other Plus-only action).'},
    {title:'Soft paywall', body:'"Continue free" always visible — never a hard block.'},
    {title:'IAP', body:'Purchase handled by StoreKit (iOS) / Billing (Android). No card details in app.'},
    {title:'Adaptive', body:'Benefits list items: 14→18px. CTA button 52→64px.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      {/* Hero */}
      <Box x={0} y={0} w={390} h={140} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderTop:'none',borderStyle:'dashed'}}>
        <Txt x={120} y={60} size={10} color={WC.g4}>[ Upgrade illustration ]</Txt>
      </Box>
      <Txt x={60} y={164} size={22} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Senior Brains Plus</Txt>
      <Txt x={120} y={198} size={13} color={WC.g4} w={150} style={{textAlign:'center',position:'absolute'}}>$4.99 / month</Txt>

      <Txt x={20} y={232} size={10} weight={600} color={WC.g5}>WHAT YOU GET</Txt>
      {[
        ['Host unlimited rooms','Invite family any time, no limits'],
        ['Custom room wallpapers','Personalise your shared space'],
        ['Game history & replays','Look back on your sessions'],
        ['Priority support','We respond within 24h'],
      ].map(([title,desc],i)=>(
        <Box key={i} x={20} y={250+i*62} w={350} h={54} r={10} fill={WC.g1} stroke={WC.g2}>
          <Circle x={12} y={10} size={34} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={58} y={8} size={12} weight={600}>{title}</Txt>
          <Txt x={58} y={26} size={9} color={WC.g4} w={270}>{desc}</Txt>
        </Box>
      ))}
      <Btn x={20} y={508} w={350} h={56} label="Subscribe — $4.99/month" fill={WC.g3} stroke={WC.g4} bold={true} textSize={14}/>
      <Txt x={60} y={574} size={9} color={WC.g4} w={270} style={{textAlign:'center',position:'absolute'}}>Cancel any time · Managed by App Store · Renews monthly</Txt>
      <Btn x={20} y={596} w={350} h={44} label="Continue with Free" fill={WC.bg} stroke={WC.g3} textSize={12}/>
      <Txt x={50} y={652} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>Restore Purchases · Terms · Privacy</Txt>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW O: ERROR STATES (4 screens)
// ═══════════════════════════════════════════

const ScreenO1 = () => (
  <WireScreen number="O1" title="Network Disconnected Banner" annotations={[
    {title:'Banner', body:'Persistent top banner when offline. Does not block scroll or interaction with cached content.'},
    {title:'Auto-dismiss', body:'Banner dismisses automatically when connection restored. Shows "Reconnected ✓" for 2s.'},
    {title:'In-game', body:'If disconnect happens mid-game: game freezes, "reconnecting…" overlay. Auto-resume on restore.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={36} r={0} fill={WC.g4} stroke={WC.g5} style={{borderLeft:'none',borderRight:'none'}}>
      <Txt x={20} y={10} size={10} weight={600} color={WC.bg}>⚡ No connection · Rooms unavailable · Retrying…</Txt>
    </Box>
    {/* Normal home content dimmed */}
    <Box x={0} y={80} w={390} h={52} r={0} fill={WC.g1} stroke={WC.g2} style={{borderLeft:'none',borderRight:'none',borderTop:'none',opacity:0.7}}>
      <Txt x={20} y={16} size={14} weight={700}>Senior Brains</Txt>
    </Box>
    <Box x={0} y={132} w={390} h={656} r={0} fill={WC.bg} stroke="none" style={{opacity:0.5}}>
      <Btn x={20} y={16} w={350} h={52} label="+ Start New Room" fill={WC.g2} stroke={WC.g3} textSize={14}/>
      <Txt x={90} y={80} size={10} color={WC.g4} w={210} style={{textAlign:'center',position:'absolute'}}>⚠ Disabled while offline</Txt>
      <Txt x={20} y={120} size={10} weight={600} color={WC.g5}>SOLO ACTIVITIES (offline-ready)</Txt>
      <Box x={20} y={138} w={350} h={60} r={12} fill={WC.g1} stroke={WC.g2}><Txt x={16} y={22} size={12}>Crossword — Daily (cached)</Txt></Box>
    </Box>
    <BottomBar tabs={['Home','Rooms','Settings']} active={0}/>
  </WireScreen>
);

const ScreenO2 = () => (
  <WireScreen number="O2" title="Microphone Permission Denied" annotations={[
    {title:'Recovery', body:'Deep link to iOS/Android settings to grant mic permission.'},
    {title:'No mic', body:'User can still join rooms in "listen only" mode — cannot speak. Annotated as assumption.'},
    {title:'Assumption', body:'Listen-only mode planned for v2. v1: mic required to participate in voice.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Circle x={155} y={160} size={80} fill={WC.g2} stroke={WC.g3}>
        <Txt x={18} y={22} size={30}>🎤</Txt>
      </Circle>
      <div style={{position:'absolute',left:148,top:152,width:94,height:94}}>
        <div style={{position:'absolute',top:0,left:40,width:14,height:94,background:WC.bg,transform:'rotate(-45deg)',transformOrigin:'center'}}/>
        <div style={{position:'absolute',top:0,left:0,width:94,height:14,background:WC.g4,transform:'rotate(-45deg)',transformOrigin:'40px 7px',borderRadius:2}}/>
      </div>
      <Txt x={60} y={268} size={18} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Microphone access denied</Txt>
      <Txt x={40} y={300} size={11} color={WC.g4} w={310} style={{textAlign:'center',position:'absolute'}}>Senior Brains needs microphone access to connect you with family. Please enable it in your device settings.</Txt>
      <Btn x={30} y={370} w={330} h={52} label="Open Settings" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={30} y={432} w={330} h={44} label="Join as listener (no mic)" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Txt x={50} y={490} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>* Listen-only mode coming in v2. You'll be able to read chat and see the game but not speak.</Txt>
    </Box>
  </WireScreen>
);

const ScreenO3 = () => (
  <WireScreen number="O3" title="Room Not Found / Invalid Invite" annotations={[
    {title:'Trigger', body:'Deep link with expired/invalid code, or room was closed before joining.'},
    {title:'Suggestions', body:'Contact the person who sent the invite, or start your own room.'},
    {title:'Code input', body:'Manual code entry as fallback in case link parsing failed.'},
  ]}>
    <StatusBar/>
    <Box x={0} y={44} w={390} h={800} r={0} fill={WC.bg} stroke="none">
      <Circle x={155} y={160} size={80} fill={WC.g2} stroke={WC.g3}>
        <Txt x={18} y={22} size={30}>🚪</Txt>
      </Circle>
      <Txt x={60} y={266} size={18} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Room not found</Txt>
      <Txt x={40} y={298} size={11} color={WC.g4} w={310} style={{textAlign:'center',position:'absolute'}}>This invite link may have expired, or the room has already ended. Ask for a fresh link.</Txt>
      <Txt x={30} y={360} size={11} weight={600} color={WC.g5}>TRY A ROOM CODE INSTEAD</Txt>
      <Input x={30} y={378} w={330} h={52} placeholder="Enter 6-digit room code"/>
      <Btn x={30} y={440} w={330} h={48} label="Join Room" fill={WC.g2} stroke={WC.g3} bold={true} textSize={13}/>
      <Divider x={30} y={504} w={330}/>
      <Btn x={30} y={518} w={330} h={48} label="Start My Own Room" fill={WC.g1} stroke={WC.g3} textSize={12}/>
      <Btn x={30} y={576} w={330} h={44} label="Go Home" fill={WC.bg} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

const ScreenO4 = () => (
  <WireScreen number="O4" title="Account Recovery" annotations={[
    {title:'Recovery', body:'Name-based — no email/password login. Recovery via device or past room codes.'},
    {title:'v1 assumption', body:'No account system at launch. Profile stored locally. Loss of device = loss of profile. Annotated.'},
    {title:'v2 plan', body:'Cloud backup via Apple/Google sign-in planned for v2.'},
  ]}>
    <StatusBar/>
    <TopBar title="Account Recovery" back={true}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none">
      <Circle x={155} y={50} size={80} fill={WC.g2} stroke={WC.g3}>
        <Txt x={20} y={24} size={28}>🔑</Txt>
      </Circle>
      <Txt x={60} y={152} size={16} weight={700} color={WC.black} w={270} style={{textAlign:'center',position:'absolute'}}>Recover your profile</Txt>
      <Txt x={30} y={182} size={10} color={WC.g4} w={330} style={{textAlign:'center',position:'absolute'}}>Senior Brains stores your profile on this device. If you've reinstalled the app, you'll need to set up a new profile.</Txt>
      <Box x={20} y={236} w={350} h={60} r={12} fill={WC.g1} stroke={WC.g2} style={{borderStyle:'dashed'}}>
        <Txt x={16} y={10} size={10} weight={600} color={WC.g5}>⚠ v1 Limitation</Txt>
        <Txt x={16} y={28} size={9} color={WC.g4} w={310}>Profile is device-local only. Cloud backup (Apple/Google sign-in) coming in v2.</Txt>
      </Box>
      <Btn x={20} y={316} w={350} h={52} label="Set Up New Profile" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Btn x={20} y={378} w={350} h={44} label="Join an existing room instead" fill={WC.g1} stroke={WC.g3} textSize={12}/>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// FLOW P: LEGAL & SUPPORT (3 screens)
// ═══════════════════════════════════════════

const ScreenP1 = () => (
  <WireScreen number="P1" title="Privacy Policy Viewer" annotations={[
    {title:'Content', body:'Fetched from CDN (markdown rendered). Always latest version.'},
    {title:'Search', body:'In-page text search via native find. No custom search UI.'},
    {title:'Adaptive', body:'Font size matches UI mode setting. Legal text minimum 14px (Standard) → 18px (Larger & Calmer).'},
  ]}>
    <StatusBar/>
    <TopBar title="Privacy Policy" back={true}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Txt x={20} y={16} size={13} weight={700}>Privacy Policy</Txt>
      <Txt x={20} y={36} size={9} color={WC.g4}>Last updated: April 2025</Txt>
      <Divider x={20} y={54} w={350}/>
      {['1. What we collect','2. How we use it','3. Data sharing','4. Your rights','5. Contact us'].map((section,i)=>(
        <div key={i}>
          <Txt x={20} y={72+i*110} size={12} weight={700}>{section}</Txt>
          <Box x={20} y={90+i*110} w={350} h={80} r={6} fill={WC.g1} stroke={WC.g2}>
            <Txt x={10} y={10} size={9} color={WC.g4} w={330}>Lorem ipsum legal text placeholder. Actual content will be drafted by legal team and fetched from CDN. Min font size enforced by UI mode setting.</Txt>
          </Box>
        </div>
      ))}
    </Box>
  </WireScreen>
);

const ScreenP2 = () => (
  <WireScreen number="P2" title="Terms of Service Viewer" annotations={[
    {title:'Same pattern', body:'Identical layout to P1 (Privacy Policy). Different content.'},
    {title:'Accept', body:'First-time: user must scroll to bottom before Accept button activates. Subsequent views: read-only.'},
  ]}>
    <StatusBar/>
    <TopBar title="Terms of Service" back={true}/>
    <Box x={0} y={96} w={390} h={692} r={0} fill={WC.bg} stroke="none" style={{overflowY:'auto'}}>
      <Txt x={20} y={16} size={13} weight={700}>Terms of Service</Txt>
      <Txt x={20} y={36} size={9} color={WC.g4}>Last updated: April 2025</Txt>
      <Divider x={20} y={54} w={350}/>
      {['1. Acceptance','2. Permitted use','3. Prohibited conduct','4. Intellectual property','5. Termination'].map((section,i)=>(
        <div key={i}>
          <Txt x={20} y={72+i*100} size={12} weight={700}>{section}</Txt>
          <Box x={20} y={90+i*100} w={350} h={72} r={6} fill={WC.g1} stroke={WC.g2}>
            <Txt x={10} y={10} size={9} color={WC.g4} w={330}>Legal placeholder text — fetched from CDN.</Txt>
          </Box>
        </div>
      ))}
    </Box>
    <Box x={0} y={748} w={390} h={44} r={0} fill={WC.g2} stroke={WC.g3} style={{borderLeft:'none',borderRight:'none',borderBottom:'none'}}>
      <Btn x={20} y={6} w={350} h={32} label="I Accept (scroll to unlock)" fill={WC.g3} stroke={WC.g4} bold={true} textSize={11}/>
    </Box>
  </WireScreen>
);

const ScreenP3 = () => (
  <WireScreen number="P3" title="Contact Us / Report Issue" annotations={[
    {title:'Categories', body:'Bug report / Feedback / Billing / Other. Pre-populates context.'},
    {title:'Auto-info', body:'App version, device model, OS version auto-attached. User can remove.'},
    {title:'Submit', body:'Sends to support@seniorbrains.app. Confirmation screen shown.'},
  ]}>
    <StatusBar/>
    <TopBar title="Contact Us" back={true}/>
    <Box x={0} y={96} w={390} h={748} r={0} fill={WC.bg} stroke="none">
      <Txt x={20} y={20} size={11} weight={600} color={WC.g5}>CATEGORY</Txt>
      {['Bug Report','Feature Request','Billing Issue','Other'].map((cat,i)=>(
        <Box key={i} x={i%2===0?20:200} y={38+(Math.floor(i/2))*52} w={162} h={44} r={10} fill={i===0?WC.g2:WC.g1} stroke={WC.g3} dash={i!==0}>
          <span style={{fontSize:11,fontWeight:i===0?600:400}}>{cat}</span>
        </Box>
      ))}
      <Txt x={20} y={154} size={11} weight={600} color={WC.g5}>DESCRIBE THE ISSUE</Txt>
      <Box x={20} y={172} w={350} h={120} r={10} fill={WC.g1} stroke={WC.g3} dash={true}>
        <Txt x={14} y={14} size={10} color={WC.g4}>Describe what happened…</Txt>
      </Box>
      <Txt x={20} y={306} size={11} weight={600} color={WC.g5}>AUTO-ATTACHED INFO</Txt>
      <Box x={20} y={324} w={350} h={60} r={10} fill={WC.g1} stroke={WC.g2}>
        <Txt x={14} y={10} size={9} color={WC.g4}>App v1.0.0 · iPhone 15 Pro · iOS 17.4 · EN</Txt>
        <Txt x={14} y={28} size={9} color={WC.g4}>Remove this info?</Txt>
        <Toggle x={296} y={26} on={false}/>
      </Box>
      <Btn x={20} y={406} w={350} h={52} label="Send Report" fill={WC.g2} stroke={WC.g3} bold={true} textSize={14}/>
      <Txt x={50} y={470} size={9} color={WC.g4} w={290} style={{textAlign:'center',position:'absolute'}}>We aim to respond within 24 hours.</Txt>
    </Box>
  </WireScreen>
);

// ═══════════════════════════════════════════
// COMPONENT LIBRARY
// ═══════════════════════════════════════════

const ComponentLibrary = () => (
  <div style={{fontFamily:'system-ui',display:'flex',flexDirection:'column',gap:32,padding:20,background:WC.bg}}>
    <div style={{fontWeight:700,fontSize:16,color:WC.black,borderBottom:`2px solid ${WC.g3}`,paddingBottom:8}}>Component Library — Low-Fidelity</div>

    {/* Buttons */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>BUTTON</div>
      <div style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'center'}}>
        <div style={{display:'flex',flexDirection:'column',gap:4,alignItems:'center'}}>
          <Btn x={0} y={0} w={140} h={44} label="Primary" fill={WC.g3} stroke={WC.g4} bold={true} textSize={13}/>
          <div style={{fontSize:8,color:WC.g4}}>Primary · 44px · 12px r</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:4,alignItems:'center'}}>
          <Btn x={0} y={0} w={140} h={44} label="Secondary" fill={WC.g1} stroke={WC.g3} textSize={13}/>
          <div style={{fontSize:8,color:WC.g4}}>Secondary</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:4,alignItems:'center'}}>
          <Btn x={0} y={0} w={140} h={44} label="Ghost" fill={WC.bg} stroke={WC.g3} textSize={13}/>
          <div style={{fontSize:8,color:WC.g4}}>Ghost</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:4,alignItems:'center'}}>
          <Btn x={0} y={0} w={140} h={56} label="Primary LC" fill={WC.g3} stroke={WC.g4} bold={true} textSize={15}/>
          <div style={{fontSize:8,color:WC.g4}}>Larger & Calmer · 56px</div>
        </div>
      </div>
    </div>

    {/* Inputs */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>INPUT</div>
      <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
        <div style={{display:'flex',flexDirection:'column',gap:4}}>
          <Input x={0} y={0} w={240} h={44} placeholder="Placeholder text" />
          <div style={{fontSize:8,color:WC.g4}}>Standard · 44px</div>
        </div>
        <div style={{display:'flex',flexDirection:'column',gap:4}}>
          <Input x={0} y={0} w={240} h={56} placeholder="Larger & Calmer input" />
          <div style={{fontSize:8,color:WC.g4}}>Larger & Calmer · 56px</div>
        </div>
      </div>
    </div>

    {/* Cards */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>CARD / ACTIVITY CARD</div>
      <div style={{display:'flex',gap:12}}>
        <Box x={0} y={0} w={180} h={100} r={14} fill={WC.g1} stroke={WC.g2} dash={true} style={{position:'relative'}}>
          <Box x={12} y={12} w={44} h={44} r={8} fill={WC.g2} stroke={WC.g3}><Txt x={8} y={14} size={16}>🎮</Txt></Box>
          <Txt x={66} y={12} size={12} weight={600}>Scrabble</Txt>
          <Txt x={66} y={30} size={9} color={WC.g4}>2-4 players</Txt>
          <Txt x={66} y={46} size={9} color={WC.g4}>15-45 min</Txt>
          <div style={{position:'absolute',bottom:6,right:6,fontSize:8,color:WC.g4}}>ActivityCard</div>
        </Box>
        <Box x={0} y={0} w={180} h={80} r={12} fill={WC.g1} stroke={WC.g2} dash={true} style={{position:'relative'}}>
          <Circle x={10} y={18} size={44} fill={WC.g2} stroke={WC.g3}/>
          <Txt x={66} y={16} size={12} weight={600}>Room Name</Txt>
          <Txt x={66} y={34} size={9} color={WC.g4}>2 in room · Active</Txt>
          <div style={{position:'absolute',bottom:6,right:6,fontSize:8,color:WC.g4}}>RoomCard</div>
        </Box>
      </div>
    </div>

    {/* Dialog */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>DIALOG</div>
      <Box x={0} y={0} w={320} h={140} r={16} fill={WC.bg} stroke={WC.g3} style={{position:'relative',boxShadow:'0 4px 20px rgba(0,0,0,0.12)'}}>
        <Txt x={20} y={16} size={13} weight={700} color={WC.black}>Dialog Title</Txt>
        <Txt x={20} y={38} size={10} color={WC.g4} w={280}>Descriptive message text. Keep it short and friendly.</Txt>
        <Divider x={0} y={96} w={320}/>
        <div style={{position:'absolute',bottom:12,right:12,display:'flex',gap:8}}>
          <Btn x={0} y={0} w={90} h={32} label="Cancel" fill={WC.g1} stroke={WC.g3} textSize={10}/>
          <Btn x={0} y={0} w={90} h={32} label="Confirm" fill={WC.g3} stroke={WC.g4} bold={true} textSize={10}/>
        </div>
      </Box>
    </div>

    {/* ParticipantOrb all 3 states */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>PARTICIPANT ORB — All 3 States</div>
      <div style={{display:'flex',gap:40,alignItems:'flex-start'}}>
        {/* Muted */}
        <div style={{display:'flex',flexDirection:'column',gap:6,alignItems:'center'}}>
          <div style={{width:52,height:52,borderRadius:'50%',background:WC.g2,border:`1.5px solid ${WC.g3}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20}}>✕</div>
          <div style={{fontSize:9,color:WC.g5,textAlign:'center',maxWidth:80}}>State 1: Muted<br/>Flat circle · mic-slash · no animation</div>
          <div style={{fontSize:8,color:WC.g4}}>Standard: 44×44px</div>
          <div style={{fontSize:8,color:WC.g4}}>Larger & Calmer: 56×56px</div>
        </div>
        {/* Speaking */}
        <div style={{display:'flex',flexDirection:'column',gap:6,alignItems:'center'}}>
          <div style={{position:'relative',width:68,height:68,display:'flex',alignItems:'center',justifyContent:'center'}}>
            <div style={{position:'absolute',width:68,height:68,borderRadius:'50%',border:`2px dashed ${WC.g3}`}}/>
            <div style={{width:52,height:52,borderRadius:'50%',background:WC.g3,border:`1.5px solid ${WC.g4}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,fontWeight:600}}>LIVE</div>
          </div>
          <div style={{fontSize:9,color:WC.g5,textAlign:'center',maxWidth:100}}>State 2: Speaking<br/>Pulsing ring · expands 1.2× · 800ms loop · "live" label</div>
          <div style={{fontSize:8,color:WC.g4}}>⟳ Annotated: "ring expands 1.2× then fades, 800ms loop"</div>
        </div>
        {/* Disconnected */}
        <div style={{display:'flex',flexDirection:'column',gap:6,alignItems:'center'}}>
          <div style={{width:52,height:52,borderRadius:'50%',background:WC.g2,border:`1.5px solid ${WC.g3}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,opacity:0.45}}>⚠</div>
          <div style={{fontSize:9,color:WC.g5,textAlign:'center',maxWidth:100}}>State 3: Disconnected<br/>Dimmed · broken-link icon · greyed out</div>
          <div style={{fontSize:8,color:WC.g4}}>Annotation: "greyed out — reconnection in progress"</div>
        </div>
      </div>
    </div>

    {/* TopBar */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>TOP BAR</div>
      <div style={{position:'relative',width:390,height:52,border:`1.5px solid ${WC.g3}`,background:WC.g1}}>
        <div style={{position:'absolute',left:16,top:15,fontSize:12,color:WC.black}}>‹ Back</div>
        <div style={{position:'absolute',left:0,right:0,top:16,textAlign:'center',fontSize:13,fontWeight:600}}>Screen Title</div>
        <div style={{position:'absolute',right:16,top:16,fontSize:11,color:WC.g4}}>Action</div>
      </div>
    </div>

    {/* Bottom toolbar */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>BOTTOM TOOLBAR (in-game)</div>
      <div style={{position:'relative',width:390,height:50,border:`1.5px solid ${WC.g3}`,background:WC.g2,display:'flex'}}>
        {['👆 Pointer','💡 Hint','⏭ Pass','✓ Submit'].map((label,i)=>(
          <div key={i} style={{flex:1,height:50,borderRight:i<3?`1px solid ${WC.g3}`:'none',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,background:i===3?WC.g3:WC.g2,fontWeight:i===3?600:400}}>{label}</div>
        ))}
      </div>
      <div style={{fontSize:8,color:WC.g4,marginTop:4}}>Standard: 44px height · Larger & Calmer: 56px height · Tap targets always full-width cell</div>
    </div>

    {/* Bottom sheet */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>BOTTOM SHEET</div>
      <Box x={0} y={0} w={390} h={180} r={0} fill={WC.bg} stroke={WC.g3} style={{borderTopLeftRadius:20,borderTopRightRadius:20,borderBottom:'none',borderLeft:'none',borderRight:'none',position:'relative'}}>
        <div style={{position:'absolute',top:8,left:175,width:40,height:4,borderRadius:2,background:WC.g3}}/>
        <Txt x={130} y={28} size={13} weight={700}>Bottom Sheet Title</Txt>
        <Txt x={20} y={52} size={10} color={WC.g4} w={350}>Content area. Swipe down to dismiss. Tapping backdrop also dismisses.</Txt>
        <Btn x={20} y={94} w={350} h={44} label="Primary Action" fill={WC.g2} stroke={WC.g3} bold={true} textSize={12}/>
        <Btn x={20} y={148} w={350} h={32} label="Cancel" fill={WC.bg} stroke={WC.g3} textSize={10}/>
      </Box>
    </div>

    {/* Wheel of Fortune */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>WHEEL OF FORTUNE (component)</div>
      <div style={{position:'relative',width:200,height:200}}>
        <div style={{width:200,height:200,borderRadius:'50%',border:`2px solid ${WC.g3}`,background:WC.g1,position:'relative',overflow:'hidden'}}>
          {[0,72,144,216,288].map((deg,i)=>(
            <div key={i} style={{position:'absolute',top:'50%',left:'50%',width:'50%',height:1.5,background:WC.g3,transformOrigin:'left center',transform:`rotate(${deg}deg)`}}/>
          ))}
          {[['Scrabble',36],['Checkers',108],['Jeopardy',180],['Crossword',252],['Sudoku',324]].map(([label,deg])=>(
            <div key={label} style={{position:'absolute',top:'50%',left:'50%',transform:`rotate(${deg}deg) translateX(52px) rotate(-${deg}deg)`,fontSize:8,fontWeight:600,color:WC.g5,marginTop:-5,marginLeft:-20}}>{label}</div>
          ))}
          <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',width:24,height:24,borderRadius:'50%',background:WC.g3,border:`1.5px solid ${WC.g4}`}}/>
        </div>
        <div style={{position:'absolute',top:-6,left:92,width:0,height:0,borderLeft:'8px solid transparent',borderRight:'8px solid transparent',borderBottom:`16px solid ${WC.black}`}}/>
      </div>
      <div style={{fontSize:8,color:WC.g4,marginTop:4}}>Host: Spin button active · Non-host: greyed out, "Waiting for [Host]…"</div>
    </div>

    {/* Pointer Overlay */}
    <div>
      <div style={{fontSize:11,fontWeight:600,color:WC.g5,marginBottom:12}}>POINTER OVERLAY — State A + State B</div>
      <div style={{display:'flex',gap:40}}>
        <div>
          <div style={{fontSize:9,fontWeight:600,color:WC.g5,marginBottom:6}}>State A: Own pointer (solid)</div>
          <div style={{position:'relative',width:80,height:80,background:WC.g1,border:`1px solid ${WC.g2}`}}>
            <div style={{position:'absolute',top:38,left:10,width:24,height:2,background:WC.black}}/>
            <div style={{position:'absolute',top:38,left:46,width:24,height:2,background:WC.black}}/>
            <div style={{position:'absolute',left:39,top:10,width:2,height:24,background:WC.black}}/>
            <div style={{position:'absolute',left:39,top:46,width:2,height:24,background:WC.black}}/>
            <div style={{position:'absolute',top:52,left:28,background:WC.g5,borderRadius:3,padding:'1px 4px',fontSize:8,color:WC.bg}}>You</div>
          </div>
          <div style={{fontSize:8,color:WC.g4,marginTop:4}}>Solid crosshair · labeled "You" · follows finger drag</div>
        </div>
        <div>
          <div style={{fontSize:9,fontWeight:600,color:WC.g5,marginBottom:6}}>State B: Remote pointer (dashed bloom)</div>
          <div style={{position:'relative',width:100,height:100,background:WC.g1,border:`1px solid ${WC.g2}`}}>
            <div style={{position:'absolute',top:42,left:42,width:16,height:16,borderRadius:'50%',border:`2px dashed ${WC.g4}`}}/>
            <div style={{position:'absolute',top:49,left:20,width:14,height:1.5,background:WC.g4,borderRadius:1}}/>
            <div style={{position:'absolute',top:49,left:66,width:14,height:1.5,background:WC.g4,borderRadius:1}}/>
            <div style={{position:'absolute',left:50,top:20,width:1.5,height:14,background:WC.g4,borderRadius:1}}/>
            <div style={{position:'absolute',left:50,top:66,width:1.5,height:14,background:WC.g4,borderRadius:1}}/>
            <div style={{position:'absolute',top:66,left:28,background:WC.g3,borderRadius:3,padding:'1px 4px',fontSize:7,color:WC.g5}}>Mom</div>
          </div>
          <div style={{fontSize:8,color:WC.g4,marginTop:4}}>Dashed bloom · labeled "[Name]" · synced ~60ms Supabase Realtime</div>
        </div>
      </div>
    </div>
  </div>
);

// ═══════════════════════════════════════════
// NAVIGATION ARCHITECTURE
// ═══════════════════════════════════════════

const NavNode = ({x,y,code,label,w=80,h=36}) => (
  <div style={{position:'absolute',left:x,top:y,width:w,height:h,border:`1.5px solid ${WC.g4}`,borderRadius:6,background:WC.g1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',fontSize:8}}>
    <div style={{fontWeight:700,color:WC.black,fontSize:9}}>{code}</div>
    <div style={{color:WC.g5,fontSize:7,textAlign:'center',padding:'0 2px'}}>{label}</div>
  </div>
);

const NavArrow = ({x1,y1,x2,y2,label='',type='solid'}) => {
  const dx=x2-x1, dy=y2-y1;
  const angle=Math.atan2(dy,dx)*180/Math.PI;
  const length=Math.sqrt(dx*dx+dy*dy);
  return (
    <div style={{position:'absolute',left:x1,top:y1,width:length,height:20,transformOrigin:'0 50%',transform:`rotate(${angle}deg)`,display:'flex',alignItems:'center'}}>
      <div style={{width:'100%',height:1.5,background:WC.g4,borderTop:`1.5px ${type==='solid'?'solid':type==='dashed'?'dashed':'dotted'} ${WC.g4}`}}/>
      {label && <div style={{position:'absolute',left:'40%',top:-12,fontSize:7,color:WC.g5,whiteSpace:'nowrap',background:WC.bg,padding:'0 2px'}}>{label}</div>}
      <div style={{position:'absolute',right:0,width:0,height:0,borderTop:'4px solid transparent',borderBottom:'4px solid transparent',borderLeft:`6px solid ${WC.g4}`}}/>
    </div>
  );
};

const NavigationArchitecture = () => (
  <div style={{position:'relative',width:1400,height:1000,background:WC.bg,fontFamily:'system-ui',overflow:'hidden'}}>
    {/* Title */}
    <div style={{position:'absolute',top:10,left:20,fontSize:14,fontWeight:700,color:WC.black}}>Navigation Architecture — Senior Brains</div>

    {/* Legend */}
    <div style={{position:'absolute',top:10,left:1100,display:'flex',flexDirection:'column',gap:6}}>
      <div style={{fontSize:8,fontWeight:600,color:WC.g5}}>LEGEND</div>
      <div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:30,height:1.5,background:WC.g4}}/><div style={{fontSize:7,color:WC.g5}}>Full-page navigation</div></div>
      <div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:30,borderTop:`1.5px dashed ${WC.g4}`}}/><div style={{fontSize:7,color:WC.g5}}>Bottom sheet / modal</div></div>
      <div style={{display:'flex',gap:6,alignItems:'center'}}><div style={{width:30,borderTop:`1.5px dotted ${WC.g4}`}}/><span style={{fontSize:9}}>⚡</span><div style={{fontSize:7,color:WC.g5}}>Real-time server push</div></div>
    </div>

    {/* ── SPLASH / ONBOARDING ── */}
    <NavNode x={40} y={50} code="A1" label="Splash"/>
    <NavNode x={140} y={50} code="A2" label="Language"/>
    <NavNode x={240} y={50} code="A3" label="Name Input"/>
    <NavNode x={340} y={50} code="A4" label="UI Mode"/>
    <NavNode x={440} y={50} code="A5" label="Mic Perm"/>
    <NavNode x={540} y={50} code="A6" label="Push Perm"/>
    <NavNode x={640} y={50} code="A7" label="Join/Start?"/>
    <NavNode x={740} y={50} code="A8" label="Room Setup" w={85}/>

    {[[[120,68],[140,68]],[[220,68],[240,68]],[[320,68],[340,68]],[[420,68],[440,68]],[[520,68],[540,68]],[[620,68],[640,68]],[[720,68],[740,68]]].map(([[x1,y1],[x2,y2]],i)=>(
      <NavArrow key={i} x1={x1} y1={y1} x2={x2} y2={y2} label={i===6?'tap Start':'tap Next'}/>
    ))}

    {/* A7 → C path */}
    <NavNode x={640} y={130} code="C1" label="Invite Link" w={80}/>
    <NavArrow x1={680} y1={86} x2={680} y2={130} label="tap Join"/>

    {/* ── HOME ── */}
    <NavNode x={40} y={200} code="B1" label="Home" w={80}/>
    <NavNode x={140} y={200} code="B2" label="Empty State"/>
    <NavNode x={240} y={200} code="B3" label="Offline"/>
    <NavArrow x1={720} y1={86} x2={80} y2={200} label="onboarding complete"/>
    <NavArrow x1={80} y1={200} x2={140} y2={218} label="no rooms"/>
    <NavArrow x1={80} y1={200} x2={240} y2={218} label="offline"/>

    {/* ── INVITE FLOW ── */}
    <NavNode x={140} y={130} code="C2" label="Quick Onboard"/>
    <NavNode x={240} y={130} code="C3" label="Loading→Room" w={100}/>
    <NavArrow x1={640} y1={148} x2={640+80} y2={148}/>
    <NavArrow x1={220} y1={148} x2={240} y2={148} label="name saved"/>

    {/* ── LOBBY ── */}
    <NavNode x={40} y={300} code="D1" label="Lobby Solo"/>
    <NavNode x={140} y={300} code="D2" label="Lobby Active"/>
    <NavNode x={240} y={300} code="D3" label="Invite Sheet" w={80}/>
    <NavNode x={340} y={300} code="D4" label="Lobby Opts" w={80}/>

    <NavArrow x1={80} y1={236} x2={80} y2={300} label="start room"/>
    <NavArrow x1={340} y1={148} x2={80} y2={300} type="dotted" label="⚡ room joined"/>
    <NavArrow x1={120} y1={318} x2={140} y2={318} label="2nd player joins"/>
    <NavArrow x1={220} y1={318} x2={240} y2={318} type="dashed" label="tap Invite"/>
    <NavArrow x1={320} y1={318} x2={340} y2={318} type="dashed" label="tap ⚙"/>

    {/* ── ACTIVITY SELECTION ── */}
    <NavNode x={40} y={400} code="E1" label="Wheel Idle"/>
    <NavNode x={140} y={400} code="E2" label="Spinning"/>
    <NavNode x={240} y={400} code="E3" label="Result"/>
    <NavNode x={340} y={400} code="E4" label="Browse All"/>
    <NavNode x={440} y={400} code="E5" label="Activity Detail" w={90}/>

    <NavArrow x1={80} y1={336} x2={80} y2={400} label="tap Spin"/>
    <NavArrow x1={120} y1={418} x2={140} y2={418} label="tap Spin (host)"/>
    <NavArrow x1={220} y1={418} x2={240} y2={418} type="dotted" label="⚡ result push"/>
    <NavArrow x1={320} y1={418} x2={340} y2={418} label="tap Browse"/>
    <NavArrow x1={420} y1={418} x2={440} y2={418} label="tap activity"/>

    {/* ── GAME SHELLS ── */}
    <NavNode x={40} y={500} code="F1" label="Activity Shell"/>
    <NavNode x={140} y={500} code="F2" label="Pointer Mode"/>
    <NavArrow x1={320} y1={436} x2={80} y2={500} type="dotted" label="⚡ all navigate"/>
    <NavArrow x1={120} y1={518} x2={140} y2={518} type="dashed" label="tap Pointer"/>

    {/* ── SCRABBLE ── */}
    <NavNode x={280} y={500} code="G1" label="Scrabble Setup" w={90}/>
    <NavNode x={380} y={500} code="G2" label="Board (Your Turn)" w={100}/>
    <NavNode x={490} y={500} code="G3" label="Watching"/>
    <NavNode x={590} y={500} code="G4" label="Drag Tile"/>
    <NavNode x={690} y={500} code="G5" label="Submit"/>
    <NavNode x={790} y={500} code="G6" label="Invalid Word" w={85}/>
    <NavNode x={885} y={500} code="G7" label="Game Over"/>
    <NavNode x={980} y={500} code="G8" label="Pause/Exit" w={80}/>
    <NavArrow x1={370} y1={518} x2={380} y2={518}/>
    <NavArrow x1={480} y1={518} x2={490} y2={518} label="other's turn"/>
    <NavArrow x1={580} y1={518} x2={590} y2={518} label="your turn"/>
    <NavArrow x1={680} y1={518} x2={690} y2={518} label="tile placed"/>
    <NavArrow x1={780} y1={518} x2={790} y2={518} label="invalid"/>
    <NavArrow x1={875} y1={518} x2={885} y2={518} label="game ends"/>
    <NavArrow x1={975} y1={518} x2={980} y2={518} type="dashed" label="tap ⏸"/>

    {/* ── CHECKERS ── */}
    <NavNode x={280} y={590} code="H1" label="Checkers Setup" w={90}/>
    <NavNode x={380} y={590} code="H2" label="Board"/>
    <NavNode x={460} y={590} code="H3" label="Selected"/>
    <NavNode x={540} y={590} code="H4" label="Opp Turn"/>
    <NavNode x={630} y={590} code="H5" label="Win/Draw"/>
    <NavArrow x1={370} y1={608} x2={380} y2={608}/>
    <NavArrow x1={458} y1={608} x2={460} y2={608} label="tap piece"/>
    <NavArrow x1={538} y1={608} x2={540} y2={608} label="move made"/>
    <NavArrow x1={620} y1={608} x2={630} y2={608} type="dotted" label="⚡ win detected"/>

    {/* ── JEOPARDY ── */}
    <NavNode x={280} y={680} code="I1" label="Category Board" w={90}/>
    <NavNode x={380} y={680} code="I2" label="Question"/>
    <NavNode x={460} y={680} code="I3" label="Buzzer"/>
    <NavNode x={540} y={680} code="I4" label="Answering"/>
    <NavNode x={620} y={680} code="I5" label="Result"/>
    <NavNode x={700} y={680} code="I6" label="Daily Double" w={85}/>
    <NavNode x={795} y={680} code="I7" label="Round Scores" w={85}/>
    <NavArrow x1={370} y1={698} x2={380} y2={698} label="tap cell"/>
    <NavArrow x1={458} y1={698} x2={460} y2={698} label="2s delay"/>
    <NavArrow x1={538} y1={698} x2={540} y2={698} label="buzz in"/>
    <NavArrow x1={618} y1={698} x2={620} y2={698} label="judged"/>
    <NavArrow x1={698} y1={698} x2={700} y2={698} label="daily double"/>
    <NavArrow x1={793} y1={698} x2={795} y2={698} label="round ends"/>

    {/* ── CROSSWORD ── */}
    <NavNode x={280} y={770} code="J1" label="Puzzle Select" w={90}/>
    <NavNode x={380} y={770} code="J2" label="Grid View"/>
    <NavNode x={460} y={770} code="J3" label="Clue Focus"/>
    <NavNode x={540} y={770} code="J4" label="Keyboard"/>
    <NavNode x={620} y={770} code="J5" label="Collab Indicator" w={95}/>
    <NavNode x={725} y={770} code="J6" label="Complete"/>
    <NavArrow x1={370} y1={788} x2={380} y2={788}/>
    <NavArrow x1={458} y1={788} x2={460} y2={788} label="tap cell"/>
    <NavArrow x1={538} y1={788} x2={540} y2={788} label="type"/>
    <NavArrow x1={618} y1={788} x2={620} y2={788} type="dotted" label="⚡ other typing"/>
    <NavArrow x1={723} y1={788} x2={725} y2={788} type="dotted" label="⚡ complete"/>

    {/* ── SUDOKU ── */}
    <NavNode x={280} y={850} code="K1" label="Difficulty"/>
    <NavNode x={360} y={850} code="K2" label="Grid View"/>
    <NavNode x={440} y={850} code="K3" label="Cell+NumPad" w={90}/>
    <NavNode x={540} y={850} code="K4" label="Conflict"/>
    <NavNode x={620} y={850} code="K5" label="Complete"/>
    <NavArrow x1={360} y1={868} x2={360} y2={868}/>
    <NavArrow x1={440} y1={868} x2={440} y2={868} label="tap cell"/>
    <NavArrow x1={530} y1={868} x2={540} y2={868} label="conflict"/>
    <NavArrow x1={618} y1={868} x2={620} y2={868} type="dotted" label="⚡ solved"/>

    {/* ── SESSION + SETTINGS ── */}
    <NavNode x={900} y={600} code="L1" label="Summary"/>
    <NavNode x={990} y={600} code="L2" label="Post-Session"/>
    <NavArrow x1={980} y1={618} x2={990} y2={618}/>

    <NavNode x={900} y={680} code="M1" label="Settings"/>
    <NavNode x={990} y={680} code="M2" label="Profile Edit"/>
    <NavNode x={1080} y={680} code="M3" label="Display"/>
    <NavNode x={1170} y={680} code="M4" label="Audio"/>
    <NavNode x={1260} y={680} code="M5" label="Subscription" w={90}/>
    <NavArrow x1={980} y1={698} x2={990} y2={698} type="dashed"/>
    <NavArrow x1={1078} y1={698} x2={1080} y2={698} type="dashed"/>
    <NavArrow x1={1168} y1={698} x2={1170} y2={698} type="dashed"/>
    <NavArrow x1={1258} y1={698} x2={1260} y2={698} type="dashed"/>

    {/* ── PAYWALL / ERRORS / LEGAL ── */}
    <NavNode x={900} y={770} code="N1" label="Paywall"/>
    <NavNode x={990} y={770} code="O1" label="Offline Banner" w={90}/>
    <NavNode x={1090} y={770} code="O2" label="Mic Denied" w={80}/>
    <NavNode x={1180} y={770} code="O3" label="Room 404" w={80}/>
    <NavNode x={1270} y={770} code="O4" label="Account Recovery" w={100}/>

    <NavNode x={900} y={850} code="P1" label="Privacy Policy" w={90}/>
    <NavNode x={1000} y={850} code="P2" label="Terms"/>
    <NavNode x={1090} y={850} code="P3" label="Contact Us" w={80}/>
  </div>
);

const FlowMNOP = () => (
  <div style={{display:'flex',flexDirection:'column',gap:40}}>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW M — SETTINGS (5 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenM1/><ScreenM2/><ScreenM3/><ScreenM4/><ScreenM5/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW N — PAYWALL (1 screen)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenN1/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW O — ERROR STATES (4 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenO1/><ScreenO2/><ScreenO3/><ScreenO4/></div>
    </div>
    <div>
      <div style={{fontFamily:'system-ui',fontWeight:700,fontSize:13,color:WC.g5,marginBottom:16,paddingLeft:8,borderLeft:`3px solid ${WC.g4}`,paddingTop:2,paddingBottom:2}}>FLOW P — LEGAL & SUPPORT (3 screens)</div>
      <div style={{display:'flex',flexWrap:'wrap',gap:24}}><ScreenP1/><ScreenP2/><ScreenP3/></div>
    </div>
  </div>
);

Object.assign(window, {FlowMNOP, ComponentLibrary, NavigationArchitecture});
