// Senior Brains — Hi-Fi Component Library
// Requires hifi-tokens.js loaded first

// ─── Button ────────────────────────────────────────────────────
function SBButton({ label, variant='primary', size='md', onClick, disabled, fullWidth, icon, style={} }) {
  const [pressed, setPressed] = React.useState(false);
  const { color, radius, motion, shadow } = DS;

  const variants = {
    primary:     { bg: color.primary500, text: '#fff', border: 'none', shadow: shadow.md },
    secondary:   { bg: color.sec500,     text: '#fff', border: 'none', shadow: shadow.md },
    ghost:       { bg: 'transparent',    text: color.primary600, border: `1.5px solid ${color.primary500}`, shadow: 'none' },
    destructive: { bg: color.error,      text: '#fff', border: 'none', shadow: shadow.sm },
    soft:        { bg: color.primary100, text: color.primary700, border: 'none', shadow: 'none' },
    softSec:     { bg: color.sec100,     text: color.sec700,     border: 'none', shadow: 'none' },
    white:       { bg: '#fff',           text: color.n800,       border: 'none', shadow: shadow.sm },
  };

  const sizes = {
    sm: { h: 40, px: 16, fontSize: 14, radius: radius.md },
    md: { h: 52, px: 24, fontSize: 16, radius: radius['2xl'] },
    lg: { h: 60, px: 32, fontSize: 18, radius: radius['2xl'] },
    xl: { h: 68, px: 40, fontSize: 20, radius: radius['2xl'] },
  };

  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        height: s.h, borderRadius: s.radius,
        paddingLeft: s.px, paddingRight: s.px,
        fontSize: s.fontSize, fontWeight: 700,
        fontFamily: DS.font.display,
        background: disabled ? color.n200 : v.bg,
        color: disabled ? color.n400 : v.text,
        border: v.border || 'none',
        boxShadow: disabled ? 'none' : v.shadow,
        cursor: disabled ? 'not-allowed' : 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        width: fullWidth ? '100%' : 'auto',
        transform: pressed ? 'scale(0.97)' : 'scale(1)',
        transition: `transform ${motion.fast} ${motion.easeOut}, box-shadow ${motion.normal} ${motion.easeOut}`,
        outline: 'none', letterSpacing: '-0.01em',
        ...style,
      }}
    >
      {icon && <span style={{ fontSize: s.fontSize + 2, lineHeight: 1 }}>{icon}</span>}
      {label}
    </button>
  );
}

// ─── Card ─────────────────────────────────────────────────────
function SBCard({ children, style={}, onClick, variant='default', padding=24 }) {
  const [hover, setHover] = React.useState(false);
  const { color, radius, shadow, motion } = DS;

  const variants = {
    default:     { bg: '#fff', border: `1px solid ${color.n100}`, shadow: shadow.sm },
    interactive: { bg: '#fff', border: `1px solid ${color.n100}`, shadow: hover ? shadow.lg : shadow.sm },
    highlighted: { bg: color.primary50, border: `1.5px solid ${color.primary200}`, shadow: shadow.md },
    activity:    { bg: '#fff', border: `1px solid ${color.n100}`, shadow: shadow.md },
    glass:       { bg: 'rgba(255,255,255,0.7)', border: `1px solid rgba(255,255,255,0.9)`, shadow: shadow.md },
  };
  const v = variants[variant] || variants.default;

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: v.bg, border: v.border,
        borderRadius: radius.lg, boxShadow: v.shadow,
        padding, cursor: onClick ? 'pointer' : 'default',
        transform: (onClick && hover) ? 'translateY(-2px)' : 'translateY(0)',
        transition: `transform ${motion.normal} ${motion.easeOut}, box-shadow ${motion.normal} ${motion.easeOut}`,
        backdropFilter: variant === 'glass' ? 'blur(12px)' : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── TopBar ────────────────────────────────────────────────────
function SBTopBar({ title, subtitle, onBack, action, transparent, rtl, dark }) {
  const { color, font, shadow } = DS;
  const textColor = dark ? color.darkText : color.n900;
  const subColor  = dark ? color.darkText2 : color.n500;

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 20px', height: 56,
      background: transparent ? 'transparent' : (dark ? color.darkBg : 'rgba(251,250,247,0.92)'),
      backdropFilter: transparent ? undefined : 'blur(16px)',
      borderBottom: transparent ? 'none' : `1px solid ${dark ? 'rgba(255,255,255,0.06)' : color.n100}`,
      flexDirection: rtl ? 'row-reverse' : 'row',
      flexShrink: 0,
    }}>
      <div style={{ width: 40, display: 'flex', alignItems: 'center', justifyContent: rtl ? 'flex-end' : 'flex-start' }}>
        {onBack && (
          <button onClick={onBack} style={{
            background: 'none', border: 'none', cursor: 'pointer', padding: 8, margin: -8,
            fontSize: 22, color: color.primary500, display: 'flex', alignItems: 'center',
          }}>
            {rtl ? '›' : '‹'}
          </button>
        )}
      </div>
      <div style={{ textAlign: 'center', flex: 1 }}>
        <div style={{ fontFamily: font.display, fontWeight: 700, fontSize: 17, color: textColor, letterSpacing: '-0.01em' }}>
          {title}
        </div>
        {subtitle && <div style={{ fontSize: 12, color: subColor, fontFamily: font.body, marginTop: 1 }}>{subtitle}</div>}
      </div>
      <div style={{ width: 40, display: 'flex', alignItems: 'center', justifyContent: rtl ? 'flex-start' : 'flex-end' }}>
        {action}
      </div>
    </div>
  );
}

// ─── StatusBar ─────────────────────────────────────────────────
function SBStatusBar({ dark }) {
  const { color } = DS;
  const fg = dark ? color.darkText : color.n900;
  return (
    <div style={{
      height: 44, display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', padding: '0 24px',
      flexShrink: 0,
    }}>
      <span style={{ fontFamily: DS.font.body, fontWeight: 700, fontSize: 15, color: fg }}>9:41</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="12" viewBox="0 0 17 12" fill={fg}><rect x="0" y="3" width="3" height="9" rx="1"/><rect x="4.5" y="2" width="3" height="10" rx="1"/><rect x="9" y="0" width="3" height="12" rx="1"/><rect x="13.5" y="0" width="3" height="12" rx="1" opacity="0.3"/></svg>
        <svg width="16" height="12" viewBox="0 0 16 12" fill={fg}><path d="M8 2.4C10.8 2.4 13.3 3.6 15 5.5L16 4.4C14 2.2 11.2 1 8 1 4.8 1 2 2.2 0 4.4L1 5.5C2.7 3.6 5.2 2.4 8 2.4Z" opacity="0.3"/><path d="M8 5.2C10 5.2 11.8 6 13.1 7.4L14.1 6.3C12.5 4.7 10.3 3.8 8 3.8S3.5 4.7 1.9 6.3L2.9 7.4C4.2 6 6 5.2 8 5.2Z" opacity="0.6"/><path d="M8 8C9.2 8 10.3 8.5 11.1 9.3L12.1 8.2C11 7.1 9.6 6.4 8 6.4S5 7.1 3.9 8.2L4.9 9.3C5.7 8.5 6.8 8 8 8Z"/><circle cx="8" cy="11" r="1.2"/></svg>
        <svg width="25" height="12" viewBox="0 0 25 12" fill="none"><rect x="0.5" y="0.5" width="22" height="11" rx="3.5" stroke={fg}/><rect x="2" y="2" width="17" height="8" rx="2" fill={fg}/><path d="M23.5 4.5v3a1.5 1.5 0 0 1 0-3Z" fill={fg}/></svg>
      </div>
    </div>
  );
}

// ─── ParticipantOrb ────────────────────────────────────────────
function SBOrb({ name, colorIdx=0, state='idle', size=64, self=false }) {
  const { color, font, shadow, motion } = DS;
  const pColor = DS.pColor(colorIdx);
  const initials = (name || '?').slice(0, 2).toUpperCase();
  const speaking = state === 'speaking';
  const muted    = state === 'muted';
  const disconnected = state === 'disconnected';

  const gradients = [
    `linear-gradient(135deg, ${color.primary300}, ${color.primary500})`,
    `linear-gradient(135deg, ${color.sec300}, ${color.sec500})`,
    `linear-gradient(135deg, #7DC9A8, ${color.success})`,
    `linear-gradient(135deg, #7DAFC9, ${color.info})`,
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, opacity: disconnected ? 0.4 : 1 }}>
      <div style={{ position: 'relative', width: size, height: size }}>
        {/* Speaking rings */}
        {speaking && (
          <>
            <div style={{
              position: 'absolute', inset: -8, borderRadius: '50%',
              border: `2px solid ${pColor}`, opacity: 0.4,
              animation: 'orbPulse 1.2s ease-out infinite',
            }}/>
            <div style={{
              position: 'absolute', inset: -4, borderRadius: '50%',
              border: `2px solid ${pColor}`, opacity: 0.6,
              animation: 'orbPulse 1.2s ease-out infinite 0.3s',
            }}/>
          </>
        )}
        {/* Main orb */}
        <div style={{
          width: size, height: size, borderRadius: '50%',
          background: disconnected ? color.n200 : gradients[colorIdx % 4],
          boxShadow: speaking
            ? `0 0 0 3px ${pColor}, ${shadow.lg}`
            : self ? shadow.glowLavender : shadow.md,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative',
          transition: `box-shadow ${motion.normal} ${motion.easeOut}`,
        }}>
          <span style={{
            fontFamily: font.display, fontWeight: 800, fontSize: size * 0.32,
            color: '#fff', letterSpacing: '-0.02em',
          }}>{initials}</span>
          {/* Mute badge */}
          {muted && (
            <div style={{
              position: 'absolute', bottom: -2, right: -2,
              width: size * 0.36, height: size * 0.36,
              borderRadius: '50%', background: color.n700,
              border: '2px solid #fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width={size*0.18} height={size*0.18} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5">
                <line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/>
                <path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/>
                <line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>
              </svg>
            </div>
          )}
          {/* Self badge */}
          {self && (
            <div style={{
              position: 'absolute', bottom: -2, right: -2,
              width: size * 0.34, height: size * 0.34,
              borderRadius: '50%', background: color.sec500,
              border: '2px solid #fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: size * 0.16, color: '#fff', fontWeight: 700,
            }}>You</div>
          )}
        </div>
      </div>
      <div style={{
        fontSize: 12, fontWeight: 600, fontFamily: font.body,
        color: color.n700, maxWidth: size + 16,
        textAlign: 'center', lineHeight: 1.2, overflow: 'hidden',
        textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>{name}</div>
    </div>
  );
}

// ─── LanguageTab ───────────────────────────────────────────────
function LangTab({ lang, active, onClick }) {
  const { color, font, radius, motion } = DS;
  return (
    <button onClick={onClick} style={{
      padding: '6px 16px', borderRadius: radius.full,
      background: active ? color.primary500 : 'transparent',
      color: active ? '#fff' : color.n500,
      border: 'none', cursor: 'pointer',
      fontFamily: font.body, fontWeight: 600, fontSize: 13,
      transition: `all ${motion.normal} ${motion.easeOut}`,
    }}>{lang}</button>
  );
}

// ─── ProgressDots ──────────────────────────────────────────────
function ProgressDots({ total=5, current=0 }) {
  const { color } = DS;
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', justifyContent: 'center' }}>
      {Array.from({length: total}).map((_,i) => (
        <div key={i} style={{
          width: i === current ? 24 : 8, height: 8, borderRadius: 4,
          background: i === current ? color.primary500 : color.n200,
          transition: 'all 300ms',
        }}/>
      ))}
    </div>
  );
}

// ─── PhoneShell ────────────────────────────────────────────────
function PhoneShell({ children, dark }) {
  const { color } = DS;
  return (
    <div style={{
      width: 390, height: 844, borderRadius: 48,
      background: dark ? color.darkBg : color.n0,
      overflow: 'hidden', position: 'relative',
      display: 'flex', flexDirection: 'column',
      boxShadow: '0 40px 80px rgba(0,0,0,0.3), 0 0 0 2px rgba(0,0,0,0.1)',
      flexShrink: 0,
    }}>
      {children}
    </div>
  );
}

// ─── ActivityCard ──────────────────────────────────────────────
function ActivityCard({ title, subtitle, icon, gradient, duration, players, onClick }) {
  const { color, font, radius, shadow, motion } = DS;
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        borderRadius: radius.lg, overflow: 'hidden', cursor: 'pointer',
        boxShadow: hover ? shadow.lg : shadow.md,
        transform: hover ? 'translateY(-3px)' : 'translateY(0)',
        transition: `all ${motion.normal} ${motion.easeOut}`,
        background: gradient || DS.grad.sunrise,
        position: 'relative',
      }}
    >
      <div style={{ padding: 20 }}>
        <div style={{ fontSize: 36, marginBottom: 10 }}>{icon}</div>
        <div style={{ fontFamily: font.display, fontWeight: 800, fontSize: 18, color: color.n900, letterSpacing: '-0.02em' }}>{title}</div>
        <div style={{ fontFamily: font.body, fontSize: 13, color: color.n600, marginTop: 4 }}>{subtitle}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          {duration && (
            <span style={{
              background: 'rgba(255,255,255,0.7)', borderRadius: radius.full,
              padding: '3px 10px', fontSize: 12, fontWeight: 600, color: color.n700,
            }}>{duration}</span>
          )}
          {players && (
            <span style={{
              background: 'rgba(255,255,255,0.7)', borderRadius: radius.full,
              padding: '3px 10px', fontSize: 12, fontWeight: 600, color: color.n700,
            }}>{players}</span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── BottomToolbar ──────────────────────────────────────────────
function BottomToolbar({ muted, onMute, onPointer, onSettings, pointer, dark }) {
  const { color, font, radius, shadow } = DS;
  const bg    = dark ? 'rgba(35,32,26,0.95)' : 'rgba(251,250,247,0.95)';
  const iconC = dark ? color.darkText2 : color.n600;

  const Btn2 = ({ icon, label, active, danger, onClick: oc }) => (
    <button onClick={oc} style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
      background: active ? (danger ? color.error : color.primary500) : 'transparent',
      border: 'none', cursor: 'pointer', borderRadius: radius.md,
      padding: '8px 16px', color: active ? '#fff' : iconC,
      fontFamily: font.body, fontSize: 11, fontWeight: 600,
    }}>
      <span style={{ fontSize: 20 }}>{icon}</span>
      <span>{label}</span>
    </button>
  );

  return (
    <div style={{
      background: bg, backdropFilter: 'blur(20px)',
      borderTop: `1px solid ${dark ? 'rgba(255,255,255,0.06)' : color.n100}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      padding: '8px 0 20px', flexShrink: 0,
      boxShadow: `0 -4px 20px rgba(0,0,0,0.06)`,
    }}>
      <Btn2 icon={muted ? '🔇' : '🎤'} label={muted ? 'Unmute' : 'Mute'} active={muted} danger onClick={onMute}/>
      <Btn2 icon="👆" label="Pointer" active={pointer} onClick={onPointer}/>
      <Btn2 icon="🔊" label="Volume"/>
      <Btn2 icon="⚙️" label="Settings" onClick={onSettings}/>
    </div>
  );
}

// ─── Toast ─────────────────────────────────────────────────────
function Toast({ message, variant='success', visible }) {
  const { color, radius, shadow, font, motion } = DS;
  const variants = {
    success: { bg: color.success, icon: '✓' },
    error:   { bg: color.error,   icon: '✕' },
    info:    { bg: color.info,    icon: 'ℹ' },
    warning: { bg: color.warning, icon: '!' },
  };
  const v = variants[variant] || variants.success;

  return (
    <div style={{
      position: 'absolute', top: 60, left: 20, right: 20, zIndex: 100,
      background: v.bg, borderRadius: radius.md,
      padding: '14px 18px', display: 'flex', gap: 12, alignItems: 'center',
      boxShadow: shadow.lg,
      transform: visible ? 'translateY(0)' : 'translateY(-80px)',
      opacity: visible ? 1 : 0,
      transition: `all ${motion.medium} ${motion.easeOut}`,
    }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%',
        background: 'rgba(255,255,255,0.25)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 14, color: '#fff', fontWeight: 700, flexShrink: 0,
      }}>{v.icon}</div>
      <div style={{ fontFamily: font.body, fontSize: 14, fontWeight: 600, color: '#fff' }}>{message}</div>
    </div>
  );
}

// ─── Export ────────────────────────────────────────────────────
Object.assign(window, {
  SBButton, SBCard, SBTopBar, SBStatusBar, SBOrb,
  LangTab, ProgressDots, PhoneShell, ActivityCard,
  BottomToolbar, Toast,
});
