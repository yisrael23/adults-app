// Senior Brains — Onboarding Screens (A1–A5, B1)
// Requires hifi-tokens.js + hifi-components.jsx

// ─── A1: Splash ────────────────────────────────────────────────
function ScreenHifiA1({ onNext }) {
  const { color, font, grad } = DS;
  const [pulse, setPulse] = React.useState(false);
  React.useEffect(() => {
    setPulse(true);
    const t = setTimeout(onNext, 2800);
    return () => clearTimeout(t);
  }, []);

  return (
    <PhoneShell>
      <SBStatusBar/>
      <div style={{
        flex: 1, background: grad.heroBlob,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 0,
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Background blobs */}
        <div style={{ position:'absolute', width:320, height:320, borderRadius:'50%', background:'radial-gradient(circle, rgba(236,122,47,0.12) 0%, transparent 70%)', top:'10%', left:'50%', transform:'translateX(-50%)' }}/>
        <div style={{ position:'absolute', width:240, height:240, borderRadius:'50%', background:'radial-gradient(circle, rgba(125,93,232,0.10) 0%, transparent 70%)', bottom:'20%', right:'-5%' }}/>
        <div style={{ position:'absolute', width:180, height:180, borderRadius:'50%', background:'radial-gradient(circle, rgba(89,168,120,0.08) 0%, transparent 70%)', bottom:'15%', left:'-5%' }}/>

        {/* Outer glow rings */}
        <div style={{
          position: 'absolute',
          width: pulse ? 260 : 180, height: pulse ? 260 : 180,
          borderRadius: '50%',
          border: `1.5px solid rgba(236,122,47,0.18)`,
          transition: 'all 1.5s cubic-bezier(0.25,0.46,0.45,0.94)',
          top: '50%', left: '50%', transform: 'translate(-50%, -60%)',
        }}/>
        <div style={{
          position: 'absolute',
          width: pulse ? 320 : 200, height: pulse ? 320 : 200,
          borderRadius: '50%',
          border: `1px solid rgba(236,122,47,0.10)`,
          transition: 'all 2s cubic-bezier(0.25,0.46,0.45,0.94) 0.2s',
          top: '50%', left: '50%', transform: 'translate(-50%, -60%)',
        }}/>

        {/* Logo */}
        <div style={{ position: 'relative', marginBottom: 28 }}>
          <div style={{
            width: 96, height: 96, borderRadius: 28,
            background: `linear-gradient(140deg, ${color.primary400}, ${color.primary600})`,
            boxShadow: `0 16px 48px rgba(236,122,47,0.35), 0 0 0 8px rgba(236,122,47,0.12)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            animation: 'breatheLogo 2.5s ease-in-out infinite',
          }}>
            <span style={{ fontSize: 42 }}>🧠</span>
          </div>
        </div>

        {/* Wordmark */}
        <div style={{ textAlign: 'center' }}>
          <div style={{
            fontFamily: font.display, fontWeight: 800, fontSize: 32,
            color: color.n900, letterSpacing: '-0.03em',
            animation: 'fadeSlideUp 0.6s ease-out 0.3s both',
          }}>Senior Brains</div>
          <div style={{
            fontFamily: font.body, fontSize: 16, color: color.n500,
            marginTop: 8, fontWeight: 500,
            animation: 'fadeSlideUp 0.6s ease-out 0.5s both',
          }}>Connect · Play · Belong</div>
        </div>

        {/* Tap hint */}
        <div style={{
          position: 'absolute', bottom: 48,
          fontFamily: font.body, fontSize: 13, color: color.n400,
          animation: 'fadeSlideUp 0.6s ease-out 1s both',
        }}>Tap anywhere to continue</div>

        {/* Click overlay */}
        <div onClick={onNext} style={{ position:'absolute', inset:0 }}/>
      </div>
      <style>{`
        @keyframes breatheLogo { 0%,100%{transform:scale(1)} 50%{transform:scale(1.05)} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        @keyframes orbPulse { 0%{transform:scale(1);opacity:0.6} 100%{transform:scale(1.5);opacity:0} }
        @keyframes spinWheel { from{transform:rotate(0deg)} to{transform:rotate(var(--spin-deg,1440deg))} }
      `}</style>
    </PhoneShell>
  );
}

// ─── A2: Language Picker ────────────────────────────────────────
function ScreenHifiA2({ onNext }) {
  const { color, font, radius, grad, shadow } = DS;
  const [selected, setSelected] = React.useState('en');

  const langs = [
    { code: 'en', label: 'English', native: 'English', flag: '🇺🇸' },
    { code: 'he', label: 'Hebrew',  native: 'עברית',   flag: '🇮🇱' },
    { code: 'ru', label: 'Russian', native: 'Русский',  flag: '🇷🇺' },
  ];

  return (
    <PhoneShell>
      <SBStatusBar/>
      <div style={{ flex:1, background: grad.heroBlob, display:'flex', flexDirection:'column', padding:'20px 24px 40px', overflow:'hidden' }}>
        {/* Decorative blob */}
        <div style={{ position:'absolute', width:280, height:280, borderRadius:'50%', background:'radial-gradient(circle, rgba(125,93,232,0.10) 0%, transparent 70%)', top:-60, right:-40, pointerEvents:'none' }}/>

        <div style={{ textAlign:'center', marginBottom:36, marginTop:24 }}>
          <div style={{
            width:72, height:72, borderRadius:22,
            background:`linear-gradient(140deg, ${color.primary400}, ${color.primary600})`,
            boxShadow:`0 12px 32px rgba(236,122,47,0.28)`,
            display:'flex', alignItems:'center', justifyContent:'center',
            margin:'0 auto 20px', fontSize:32,
          }}>🧠</div>
          <div style={{ fontFamily:font.display, fontWeight:800, fontSize:28, color:color.n900, letterSpacing:'-0.03em' }}>Welcome!</div>
          <div style={{ fontFamily:font.body, fontSize:16, color:color.n500, marginTop:8, lineHeight:1.5 }}>Choose your language to get started</div>
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:12, marginBottom:32 }}>
          {langs.map(l => (
            <button key={l.code} onClick={() => setSelected(l.code)} style={{
              display:'flex', alignItems:'center', gap:16,
              background: selected===l.code ? color.primary50 : '#fff',
              border: `2px solid ${selected===l.code ? color.primary500 : color.n100}`,
              borderRadius: radius.lg, padding:'18px 20px', cursor:'pointer',
              boxShadow: selected===l.code ? shadow.glowPrimary : shadow.xs,
              transition:'all 200ms',
            }}>
              <span style={{ fontSize:28 }}>{l.flag}</span>
              <div style={{ textAlign:'left' }}>
                <div style={{ fontFamily:font.display, fontWeight:700, fontSize:18, color:color.n900 }}>{l.native}</div>
                <div style={{ fontFamily:font.body, fontSize:13, color:color.n500 }}>{l.label}</div>
              </div>
              {selected===l.code && (
                <div style={{ marginLeft:'auto', width:24, height:24, borderRadius:'50%', background:color.primary500, display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <svg width="12" height="9" viewBox="0 0 12 9" fill="none"><path d="M1 4L4.5 7.5L11 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
              )}
            </button>
          ))}
        </div>

        <SBButton label="Continue" fullWidth onClick={onNext}/>
        <div style={{ textAlign:'center', marginTop:16, fontFamily:font.body, fontSize:12, color:color.n400 }}>
          You can change this anytime in Settings
        </div>
      </div>
    </PhoneShell>
  );
}

// ─── A3: Name Input ─────────────────────────────────────────────
function ScreenHifiA3({ onNext, onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [name, setName] = React.useState('');
  const [focused, setFocused] = React.useState(false);

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar onBack={onBack}/>
      <div style={{ flex:1, background: grad.heroBlob, padding:'32px 24px 40px', display:'flex', flexDirection:'column' }}>
        <div style={{ marginBottom:40 }}>
          <div style={{ fontFamily:font.display, fontWeight:800, fontSize:30, color:color.n900, letterSpacing:'-0.03em', lineHeight:1.2, marginBottom:12 }}>
            What's your name?
          </div>
          <div style={{ fontFamily:font.body, fontSize:16, color:color.n500, lineHeight:1.5 }}>
            This is what other players will see while you play together.
          </div>
        </div>

        <input
          value={name}
          onChange={e => setName(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder="Your name…"
          style={{
            height:56, borderRadius:radius.lg,
            border:`2px solid ${focused ? color.primary500 : color.n200}`,
            background:'#fff', padding:'0 20px',
            fontFamily:font.display, fontWeight:600, fontSize:20, color:color.n900,
            outline:'none',
            boxShadow: focused ? shadow.glowPrimary : shadow.xs,
            transition:'all 200ms',
          }}
        />
        <div style={{ fontFamily:font.body, fontSize:12, color:color.n400, marginTop:8 }}>
          2–20 characters · Emoji welcome 🎉
        </div>

        <div style={{ flex:1 }}/>

        <ProgressDots total={5} current={1}/>
        <div style={{ height:20 }}/>
        <SBButton label="Continue →" fullWidth onClick={onNext} disabled={name.trim().length < 2}/>
      </div>
    </PhoneShell>
  );
}

// ─── A4: UI Mode ────────────────────────────────────────────────
function ScreenHifiA4({ onNext, onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [mode, setMode] = React.useState('standard');

  const ModeCard = ({ id, title, desc, features, preview }) => {
    const active = mode === id;
    return (
      <button onClick={() => setMode(id)} style={{
        flex:1, border:`2px solid ${active ? color.primary500 : color.n200}`,
        borderRadius:radius.xl, background: active ? color.primary50 : '#fff',
        boxShadow: active ? shadow.glowPrimary : shadow.sm,
        padding:20, cursor:'pointer', textAlign:'left',
        transition:'all 200ms',
      }}>
        {/* Mini preview */}
        <div style={{
          background: active ? `linear-gradient(135deg, ${color.primary100}, ${color.sec100})` : color.n50,
          borderRadius:radius.md, padding:12, marginBottom:14,
          display:'flex', flexDirection:'column', gap:6,
        }}>
          {preview}
        </div>
        <div style={{ fontFamily:font.display, fontWeight:800, fontSize:16, color:color.n900, marginBottom:6 }}>{title}</div>
        <div style={{ fontFamily:font.body, fontSize:12, color:color.n500, marginBottom:10 }}>{desc}</div>
        {features.map((f,i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background: active ? color.primary500 : color.n300, flexShrink:0 }}/>
            <span style={{ fontFamily:font.body, fontSize:11, color:color.n600 }}>{f}</span>
          </div>
        ))}
        {active && (
          <div style={{ marginTop:12, display:'flex', alignItems:'center', gap:6 }}>
            <div style={{ width:18, height:18, borderRadius:'50%', background:color.primary500, display:'flex', alignItems:'center', justifyContent:'center' }}>
              <svg width="9" height="7" viewBox="0 0 9 7" fill="none"><path d="M1 3L3.5 5.5L8 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </div>
            <span style={{ fontFamily:font.body, fontSize:12, fontWeight:700, color:color.primary600 }}>Selected</span>
          </div>
        )}
      </button>
    );
  };

  const miniBar = (h) => (
    <div style={{ height:h, borderRadius:4, background:`linear-gradient(90deg, ${color.primary400}, ${color.primary500})`, width:'100%' }}/>
  );

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar onBack={onBack}/>
      <div style={{ flex:1, background:grad.heroBlob, padding:'24px 20px 40px', display:'flex', flexDirection:'column', overflow:'auto' }}>
        <div style={{ marginBottom:24 }}>
          <div style={{ fontFamily:font.display, fontWeight:800, fontSize:26, color:color.n900, letterSpacing:'-0.03em', lineHeight:1.2, marginBottom:10 }}>
            Choose your display
          </div>
          <div style={{ fontFamily:font.body, fontSize:15, color:color.n500 }}>
            Both work beautifully. Pick what feels right.
          </div>
        </div>

        <div style={{ display:'flex', gap:12, flex:1, marginBottom:32 }}>
          <ModeCard
            id="standard"
            title="Standard"
            desc="Compact and efficient"
            features={['16px base font','44px tap targets','Full content density']}
            preview={<>{miniBar(10)}<div style={{display:'flex',gap:4}}>{[1,2,3].map(i=><div key={i} style={{flex:1,height:30,background:color.n100,borderRadius:6}}/>)}</div></>}
          />
          <ModeCard
            id="larger"
            title="Larger & Calmer"
            desc="Spacious and relaxed"
            features={['20px base font','56px tap targets','Gentle motion']}
            preview={<>{miniBar(14)}<div style={{display:'flex',gap:6}}>{[1,2].map(i=><div key={i} style={{flex:1,height:40,background:color.n100,borderRadius:8}}/>)}</div></>}
          />
        </div>

        <ProgressDots total={5} current={2}/>
        <div style={{ height:20 }}/>
        <SBButton label="Continue →" fullWidth onClick={onNext}/>
      </div>
    </PhoneShell>
  );
}

// ─── A5: Mic Permission ─────────────────────────────────────────
function ScreenHifiA5({ onNext, onBack }) {
  const { color, font, radius, shadow, grad } = DS;
  const [asking, setAsking] = React.useState(false);

  return (
    <PhoneShell>
      <SBStatusBar/>
      <SBTopBar onBack={onBack}/>
      <div style={{ flex:1, background:grad.heroBlob, padding:'0 24px 48px', display:'flex', flexDirection:'column', alignItems:'center' }}>
        {/* Illustration */}
        <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:32 }}>
          <div style={{ position:'relative' }}>
            <div style={{ width:120, height:120, borderRadius:'50%', background:`linear-gradient(135deg, ${color.primary100}, ${color.primary200})`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:shadow.lg }}>
              <div style={{ width:88, height:88, borderRadius:'50%', background:`linear-gradient(135deg, ${color.primary300}, ${color.primary500})`, display:'flex', alignItems:'center', justifyContent:'center', boxShadow:`0 8px 24px rgba(236,122,47,0.3)` }}>
                <span style={{ fontSize:40 }}>🎤</span>
              </div>
            </div>
            {/* Pulse ring */}
            <div style={{ position:'absolute', inset:-12, borderRadius:'50%', border:`2px solid rgba(236,122,47,0.2)`, animation:'breatheLogo 2s ease-in-out infinite' }}/>
            <div style={{ position:'absolute', inset:-24, borderRadius:'50%', border:`1.5px solid rgba(236,122,47,0.10)`, animation:'breatheLogo 2s ease-in-out infinite 0.4s' }}/>
          </div>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:28, color:color.n900, letterSpacing:'-0.03em', marginBottom:12 }}>
              Hear each other clearly
            </div>
            <div style={{ fontFamily:font.body, fontSize:16, color:color.n500, lineHeight:1.6 }}>
              Senior Brains is voice-first. Talk naturally while you play — no typing needed.
            </div>
          </div>
        </div>

        <ProgressDots total={5} current={3}/>
        <div style={{ height:24 }}/>
        <SBButton label="Allow Microphone" fullWidth onClick={onNext} icon="🎤"/>
        <div style={{ height:12 }}/>
        <SBButton label="Not now" fullWidth variant="ghost" onClick={onNext}/>
        <div style={{ fontFamily:font.body, fontSize:12, color:color.n400, textAlign:'center', marginTop:16, lineHeight:1.5 }}>
          You can enable this later in Settings
        </div>
      </div>
    </PhoneShell>
  );
}

// ─── B1: Home Dashboard ─────────────────────────────────────────
function ScreenHifiB1({ onCreateRoom, onJoinRoom, onSettings, onActivity }) {
  const { color, font, radius, shadow, grad } = DS;

  const greeting = 'Good morning, Sarah 👋';

  const activities = [
    { id:'scrabble',   title:'Scrabble',   icon:'🔤', gradient:`linear-gradient(135deg, ${color.primary100}, ${color.primary200})`, duration:'20–40 min', players:'2–4' },
    { id:'jeopardy',   title:'Jeopardy',   icon:'❓', gradient:`linear-gradient(135deg, #dceeff, #b8d8ff)`, duration:'30 min', players:'2–6' },
    { id:'checkers',   title:'Checkers',   icon:'⬛', gradient:`linear-gradient(135deg, ${color.sec100}, ${color.sec200})`, duration:'15–30 min', players:'2' },
    { id:'crossword',  title:'Crossword',  icon:'📝', gradient:`linear-gradient(135deg, #d4f5e2, #b2e8c9)`, duration:'20–45 min', players:'1–4' },
    { id:'sudoku',     title:'Sudoku',     icon:'🔢', gradient:`linear-gradient(135deg, #fff0d4, #ffe0b0)`, duration:'15–30 min', players:'1–4' },
  ];

  return (
    <PhoneShell>
      <SBStatusBar/>
      {/* Header */}
      <div style={{ padding:'0 24px 0', background:color.n0, flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', paddingBottom:16, borderBottom:`1px solid ${color.n100}` }}>
          <div>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:22, color:color.n900, letterSpacing:'-0.02em' }}>{greeting}</div>
            <div style={{ fontFamily:font.body, fontSize:13, color:color.n500, marginTop:2 }}>Ready to play?</div>
          </div>
          <button onClick={onSettings} style={{ width:44, height:44, borderRadius:'50%', background:color.n100, border:'none', cursor:'pointer', fontSize:20, display:'flex', alignItems:'center', justifyContent:'center' }}>
            ⚙️
          </button>
        </div>
      </div>

      {/* Scrollable content */}
      <div style={{ flex:1, overflowY:'auto', padding:'20px 24px 24px' }}>
        {/* Quick actions */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:28 }}>
          <button onClick={onCreateRoom} style={{
            borderRadius:radius.lg, padding:'20px 16px',
            background:`linear-gradient(135deg, ${color.primary500}, ${color.primary600})`,
            border:'none', cursor:'pointer', textAlign:'left',
            boxShadow:`0 8px 24px rgba(236,122,47,0.28)`,
          }}>
            <div style={{ fontSize:28, marginBottom:8 }}>🏠</div>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:16, color:'#fff', letterSpacing:'-0.01em' }}>Create Room</div>
            <div style={{ fontFamily:font.body, fontSize:12, color:'rgba(255,255,255,0.75)', marginTop:4 }}>Start a new game</div>
          </button>

          <button onClick={onJoinRoom} style={{
            borderRadius:radius.lg, padding:'20px 16px',
            background:`linear-gradient(135deg, ${color.sec500}, ${color.sec600})`,
            border:'none', cursor:'pointer', textAlign:'left',
            boxShadow:`0 8px 24px rgba(125,93,232,0.28)`,
          }}>
            <div style={{ fontSize:28, marginBottom:8 }}>🚪</div>
            <div style={{ fontFamily:font.display, fontWeight:800, fontSize:16, color:'#fff', letterSpacing:'-0.01em' }}>Join Room</div>
            <div style={{ fontFamily:font.body, fontSize:12, color:'rgba(255,255,255,0.75)', marginTop:4 }}>Enter invite code</div>
          </button>
        </div>

        {/* Activity grid */}
        <div style={{ marginBottom:20 }}>
          <div style={{ fontFamily:font.display, fontWeight:700, fontSize:18, color:color.n800, marginBottom:14, letterSpacing:'-0.01em' }}>
            Games
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            {activities.map(a => (
              <ActivityCard key={a.id} {...a} subtitle={`${a.players} players`} onClick={() => onActivity && onActivity(a.id)}/>
            ))}
          </div>
        </div>

        {/* Recent sessions */}
        <div>
          <div style={{ fontFamily:font.display, fontWeight:700, fontSize:18, color:color.n800, marginBottom:14, letterSpacing:'-0.01em' }}>
            Recent
          </div>
          {[
            { game:'Scrabble', with:'Mom & Jake', when:'Yesterday', score:'312 pts' },
            { game:'Jeopardy', with:'Family', when:'3 days ago', score:'2nd place' },
          ].map((s,i) => (
            <div key={i} style={{
              display:'flex', alignItems:'center', gap:14, padding:'14px 0',
              borderBottom:`1px solid ${color.n100}`,
            }}>
              <div style={{ width:44, height:44, borderRadius:12, background:i===0?color.primary100:color.sec100, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, flexShrink:0 }}>
                {i===0?'🔤':'❓'}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:font.display, fontWeight:700, fontSize:15, color:color.n900 }}>{s.game}</div>
                <div style={{ fontFamily:font.body, fontSize:12, color:color.n500 }}>with {s.with} · {s.when}</div>
              </div>
              <div style={{ fontFamily:font.mono, fontWeight:700, fontSize:13, color:color.primary600 }}>{s.score}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom tab bar */}
      <div style={{
        display:'flex', borderTop:`1px solid ${color.n100}`, background:'rgba(251,250,247,0.95)',
        backdropFilter:'blur(20px)', flexShrink:0,
      }}>
        {[['🏠','Home',true],['🎮','Rooms',false],['⚙️','Settings',false]].map(([ic,lb,ac],i) => (
          <button key={lb} onClick={lb==='Settings'?onSettings:undefined} style={{
            flex:1, height:64, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
            gap:4, border:'none', background:'transparent', cursor:'pointer',
          }}>
            <span style={{ fontSize:22 }}>{ic}</span>
            <span style={{ fontFamily:font.body, fontSize:11, fontWeight:ac?700:500, color:ac?color.primary500:color.n400 }}>{lb}</span>
          </button>
        ))}
      </div>
    </PhoneShell>
  );
}

Object.assign(window, {
  ScreenHifiA1, ScreenHifiA2, ScreenHifiA3, ScreenHifiA4, ScreenHifiA5,
  ScreenHifiB1,
});
