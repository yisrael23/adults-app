// Senior Brains — Design Tokens
// Exported to window.DS for cross-file use

const DS = {
  // ─── Colors ────────────────────────────────────────
  color: {
    // Primary Warm Sunset
    primary50:  '#FFF8F3', primary100: '#FFE9D9', primary200: '#FFD3B0',
    primary300: '#FDB784', primary400: '#F69955', primary500: '#EC7A2F',
    primary600: '#D65E14', primary700: '#A94608', primary800: '#7C3207', primary900: '#4E1F04',

    // Secondary Calm Lavender
    sec50: '#F7F4FF', sec100: '#ECE5FF', sec200: '#D6C7FE',
    sec300: '#B9A2FB', sec400: '#9B7EF5', sec500: '#7D5DE8',
    sec600: '#6341D0', sec700: '#4B2FA4', sec800: '#352078', sec900: '#1E124C',

    // Warm Neutrals
    n0:   '#FBFAF7', n50:  '#F6F4EF', n100: '#ECE8DF',
    n200: '#D8D0C1', n300: '#B5A993', n400: '#8C8068',
    n500: '#6B614E', n600: '#4F4738', n700: '#383225',
    n800: '#23201A', n900: '#1A1814',

    // Semantic
    success: '#59A878', warning: '#E8A33C', error: '#D46A6A', info: '#5A8FAF',

    // Participant colors
    p1: '#EC7A2F', p2: '#7D5DE8', p3: '#59A878', p4: '#5A8FAF',

    // Dark mode
    darkBg:    '#1A1814', darkBg2: '#23201A', darkCard: '#2D2A22',
    darkText:  '#FBFAF7', darkText2: '#D8D0C1', darkAccent: '#FDB784',
  },

  // ─── Gradients ─────────────────────────────────────
  grad: {
    sunrise: 'linear-gradient(135deg, #FFE9D9 0%, #FFD3B0 50%, #F7F4FF 100%)',
    meadow:  'linear-gradient(135deg, #F7F4FF 0%, #ECE5FF 50%, #FFF8F3 100%)',
    ember:   'linear-gradient(135deg, #FFF8F3 0%, #FDB784 100%)',
    dusk:    'linear-gradient(160deg, #7D5DE8 0%, #EC7A2F 100%)',
    heroBlob:'radial-gradient(ellipse 120% 80% at 50% 0%, #FFE9D9 0%, #FFF8F3 60%, #F7F4FF 100%)',
  },

  // ─── Typography ────────────────────────────────────
  font: {
    display: "'Nunito', 'Rubik', sans-serif",
    body:    "'Inter', 'Rubik', sans-serif",
    mono:    "'JetBrains Mono', monospace",
  },

  // Standard type scale
  text: {
    xs: 12, sm: 14, base: 16, lg: 18, xl: 20,
    '2xl': 24, '3xl': 32, '4xl': 40, '5xl': 48,
  },

  // ─── Spacing (8pt grid) ────────────────────────────
  space: { 0:0, 1:4, 2:8, 3:12, 4:16, 5:20, 6:24, 8:32, 10:40, 12:48, 16:64, 20:80, 24:96, 32:128 },

  // ─── Border Radius ─────────────────────────────────
  radius: { sm:8, md:16, lg:24, xl:32, '2xl':48, full:9999 },

  // ─── Shadows (warm) ────────────────────────────────
  shadow: {
    xs:  '0 1px 2px rgba(127,75,21,0.04)',
    sm:  '0 2px 8px rgba(127,75,21,0.06)',
    md:  '0 4px 16px rgba(127,75,21,0.08)',
    lg:  '0 8px 32px rgba(127,75,21,0.10)',
    xl:  '0 16px 48px rgba(127,75,21,0.12)',
    glowPrimary:  '0 0 0 4px rgba(236,122,47,0.24)',
    glowSpeaking: '0 0 0 6px rgba(236,122,47,0.32)',
    glowLavender: '0 0 0 4px rgba(125,93,232,0.24)',
  },

  // ─── Motion ────────────────────────────────────────
  motion: {
    fast: '150ms', normal: '250ms', medium: '400ms', slow: '600ms', xslow: '1000ms',
    easeOut:    'cubic-bezier(0.22, 1, 0.36, 1)',
    easeGentle: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
    easeBounce: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
  },

  // ─── Participant names & colors helper ─────────────
  pColor(idx) {
    return [this.color.p1, this.color.p2, this.color.p3, this.color.p4][idx % 4];
  },
};

window.DS = DS;
